import React, { useEffect } from 'react';
import { LessonCard } from '../types/game';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { LessonVisualStage } from './illustrations/ConceptVisuals';
import { audioEngine } from '../utils/audioEngine';

interface LessonStageProps {
  lesson: LessonCard;
  lessonIndex: number;
  totalLessons: number;
  speakingWho: string | null;
}

export const LessonStage: React.FC<LessonStageProps> = ({
  lesson,
  lessonIndex,
  totalLessons,
  speakingWho,
}) => {
  const trackId = `lesson_${lesson.id}`;

  useEffect(() => {
    audioEngine.prefetchTrack(trackId);
  }, [trackId]);

  return (
    <div className="rounded-3xl bg-white border-3 border-emerald-200 p-5 md:p-7 shadow-sm space-y-5">
      {/* Clean Top Bar: Character + Step Title + ONE Speaker Button */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <CharacterAvatar
            character={lesson.speaker}
            size="lg"
            isSpeaking={speakingWho !== null}
          />
          <div>
            <span className="block text-sm font-extrabold text-emerald-700 tabular-nums">
              {lessonIndex + 1} من {totalLessons}
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              {lesson.title}
            </h3>
          </div>
        </div>

        <SpeakerButton
          trackId={trackId}
          speaker={lesson.speaker}
          label="اسمع الشرح"
          variant="emerald"
        />
      </div>

      {/* Main Focus: ONE Large, Clear Illustration / Animation */}
      <LessonVisualStage lesson={lesson} />

      {/* ONLY ONE Short, Simple Arabic Sentence Under the Picture */}
      <div className="rounded-2xl bg-[#FAF8F2] border-2 border-amber-200 px-5 py-4 text-center">
        <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
          {lesson.shortSentence}
        </p>
      </div>
    </div>
  );
};
