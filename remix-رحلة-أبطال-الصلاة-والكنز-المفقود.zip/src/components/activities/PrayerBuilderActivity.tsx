import React, { useEffect, useState } from 'react';
import { CheckCircle2, ArrowLeft } from 'lucide-react';
import { PrayerPoseId, TimeVisualId } from '../../types/game';
import { PrayerPostureIllustration } from '../illustrations/PrayerPostureIllustration';
import { ActivityThumbnail } from '../illustrations/SceneIllustrations';
import { audioEngine } from '../../utils/audioEngine';

interface PrayerStepNode {
  pose: PrayerPoseId;
  title: string;
  dhikr: string;
  shortNote: string;
}

const RAKAAT_MOVES: PrayerStepNode[] = [
  {
    pose: 'ruku',
    title: 'الركوع',
    dhikr: 'سُبْحَانَ رَبِّيَ الْعَظِيمِ',
    shortNote: 'ننحني بظهر مفرود ونقول: سبحان ربي العظيم.',
  },
  {
    pose: 'itidal',
    title: 'الاعتدال من الركوع',
    dhikr: 'سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ، رَبَّنَا وَلَكَ الْحَمْدُ',
    shortNote: 'نقف معتدلين ونقول: سمع الله لمن حمده.',
  },
  {
    pose: 'sujood',
    title: 'السجدة الأولى',
    dhikr: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
    shortNote: 'نسجد على الأرض ونقول: سبحان ربي الأعلى.',
  },
  {
    pose: 'juloos',
    title: 'الجلوس بين السجدتين',
    dhikr: 'رَبِّ اغْفِرْ لِي',
    shortNote: 'نجلس بهدوء ونقول: رب اغفر لي.',
  },
  {
    pose: 'sujood',
    title: 'السجدة الثانية',
    dhikr: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
    shortNote: 'نسجد السجدة التانية ونقول: سبحان ربي الأعلى.',
  },
];

interface PrayerBuilderActivityProps {
  prayerId: TimeVisualId;
  prayerName: string;
  targetRakaat: number;
  targetSajdahs: number;
  isLoudFirstTwo: boolean;
  onComplete: () => void;
  onAudioTrackChange?: (trackId: string) => void;
}

export const PrayerBuilderActivity: React.FC<PrayerBuilderActivityProps> = ({
  prayerId,
  prayerName,
  targetRakaat,
  targetSajdahs,
  isLoudFirstTwo,
  onComplete,
  onAudioTrackChange,
}) => {
  const [currentRakaah, setCurrentRakaah] = useState(1);
  const [sajdahDone, setSajdahDone] = useState(0);
  const [stage, setStage] = useState<
    'takbeer' | 'recite_choice' | 'moves' | 'tashahhud_choice' | 'done'
  >('takbeer');
  const [moveIdx, setMoveIdx] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const isFirstTwo = currentRakaah <= 2;

  useEffect(() => {
    if (!onAudioTrackChange) return;
    if (stage === 'done') {
      onAudioTrackChange(`pb_${prayerId}_done`);
    } else if (stage === 'takbeer') {
      onAudioTrackChange(`pb_${prayerId}_takbeer`);
      audioEngine.prefetchTrack(`pb_${prayerId}_recite_r1`);
    } else if (stage === 'recite_choice') {
      onAudioTrackChange(`pb_${prayerId}_recite_r${currentRakaah}`);
      audioEngine.prefetchTrack(`pb_${prayerId}_move_0`);
    } else if (stage === 'moves') {
      onAudioTrackChange(`pb_${prayerId}_move_${moveIdx}`);
      if (moveIdx + 1 < RAKAAT_MOVES.length) {
        audioEngine.prefetchTrack(`pb_${prayerId}_move_${moveIdx + 1}`);
      } else {
        audioEngine.prefetchTrack(`pb_${prayerId}_tashahhud_r${currentRakaah}`);
      }
    } else if (stage === 'tashahhud_choice') {
      onAudioTrackChange(`pb_${prayerId}_tashahhud_r${currentRakaah}`);
    }
  }, [currentRakaah, moveIdx, onAudioTrackChange, prayerId, stage]);

  const activePose: PrayerPoseId =
    stage === 'takbeer'
      ? 'takbeer'
      : stage === 'recite_choice'
      ? 'qiyam'
      : stage === 'moves'
      ? RAKAAT_MOVES[moveIdx].pose
      : stage === 'tashahhud_choice'
      ? 'tashahhud'
      : 'tasleem';

  const activeDhikr =
    stage === 'takbeer'
      ? 'اللَّهُ أَكْبَرُ'
      : stage === 'moves'
      ? RAKAAT_MOVES[moveIdx].dhikr
      : stage === 'done'
      ? 'السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ'
      : undefined;

  const handleTakbeer = () => {
    audioEngine.playCorrect();
    setStage('recite_choice');
    setFeedback(null);
  };

  const handleReciteChoice = (withShortSurah: boolean, loudChoice: boolean) => {
    const expectedShortSurah = isFirstTwo;
    const expectedLoud = isFirstTwo ? isLoudFirstTwo : false;

    if (withShortSurah === expectedShortSurah && loudChoice === expectedLoud) {
      audioEngine.playCorrect();
      audioEngine.speakShortFeedback('bravo');
      setFeedback(null);
      setMoveIdx(0);
      setStage('moves');
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      if (withShortSurah !== expectedShortSurah) {
        setFeedback(
          expectedShortSurah
            ? 'يلا نحاول تاني! في أول ركعتين بنقرأ الفاتحة وسورة قصيرة.'
            : 'يلا نحاول تاني! في التالتة والرابعة بنقرأ الفاتحة بس!'
        );
      } else {
        setFeedback(
          expectedLoud
            ? `يلا نحاول تاني! في ${prayerName} أول ركعتين بصوت مسموع جهرًا.`
            : 'يلا نحاول تاني! هنا القراءة سرية بصوت هادي.'
        );
      }
    }
  };

  const handleNextMove = () => {
    const currentMove = RAKAAT_MOVES[moveIdx];
    audioEngine.playClick();
    if (currentMove.pose === 'sujood') {
      setSajdahDone((prev) => prev + 1);
    }

    if (moveIdx + 1 < RAKAAT_MOVES.length) {
      setMoveIdx((prev) => prev + 1);
    } else {
      if (currentRakaah === targetRakaat) {
        setStage('tashahhud_choice');
      } else if (currentRakaah === 2 && targetRakaat > 2) {
        setStage('tashahhud_choice');
      } else {
        setCurrentRakaah((prev) => prev + 1);
        setStage('recite_choice');
      }
    }
  };

  const handleTashahhudChoice = (isFinalWithTasleem: boolean) => {
    const shouldBeFinal = currentRakaah === targetRakaat;
    if (isFinalWithTasleem === shouldBeFinal) {
      audioEngine.playCorrect();
      audioEngine.speakShortFeedback('bravo');
      setFeedback(null);
      if (shouldBeFinal) {
        setStage('done');
        onComplete();
      } else {
        setCurrentRakaah((prev) => prev + 1);
        setStage('recite_choice');
      }
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setFeedback(
        shouldBeFinal
          ? 'يلا نحاول تاني! دي آخر ركعة، نقرأ التشهد الأخير ونسلم يمين وشمال.'
          : 'يلا نحاول تاني! بعد الركعة ٢ نقرأ التشهد الأول بس ونقوم!'
      );
    }
  };

  return (
    <div className="space-y-5">
      {/* Visual Rakaah & Sajdah HUD */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-slate-900 text-white px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <span className="text-sm font-bold text-slate-300">الركعة:</span>
          {Array.from({ length: targetRakaat }).map((_, idx) => {
            const num = idx + 1;
            const active = num === currentRakaah && stage !== 'done';
            const done = num < currentRakaah || stage === 'done';
            return (
              <span
                key={num}
                className={`w-9 h-9 rounded-full font-extrabold text-base flex items-center justify-center tabular-nums ${
                  done
                    ? 'bg-emerald-500 text-white'
                    : active
                    ? 'bg-amber-400 text-slate-950 ring-2 ring-white'
                    : 'bg-slate-700 text-slate-300'
                }`}
              >
                {done ? '✓' : num}
              </span>
            );
          })}
        </div>

        <div className="flex items-center gap-3 text-base font-extrabold">
          <span>
            السجدات:{' '}
            <strong className="text-emerald-300 tabular-nums">
              {sajdahDone}/{targetSajdahs}
            </strong>
          </span>
        </div>
      </div>

      {stage === 'done' ? (
        <div className="rounded-3xl bg-emerald-50 border-2 border-emerald-300 p-6 md:p-8 text-center space-y-4">
          <PrayerPostureIllustration
            poseId="tasleem"
            dhikrPhrase="السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ"
            className="w-full h-64 max-w-md mx-auto"
          />
          <div className="flex items-center justify-center gap-2 text-emerald-900">
            <CheckCircle2 className="w-8 h-8" />
            <h4 className="text-2xl font-extrabold">
              برافو عليك! تقبل الله {prayerName}!
            </h4>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-5">
            <PrayerPostureIllustration
              poseId={activePose}
              dhikrPhrase={activeDhikr}
              className="w-full h-72 sm:h-80"
            />
          </div>

          <div className="md:col-span-7 space-y-4">
            {stage === 'takbeer' && (
              <div className="rounded-3xl bg-amber-50 border-2 border-amber-200 p-6 space-y-4 text-center">
                <h4 className="text-2xl font-extrabold text-amber-950">
                  يلا نبدأ {prayerName}!
                </h4>
                <p className="text-lg text-slate-800 font-bold">
                  ارفع إيديك وقول:
                </p>
                <p className="font-quran text-3xl font-bold text-emerald-900">
                  «اللَّهُ أَكْبَرُ»
                </p>
                <button
                  type="button"
                  onClick={handleTakbeer}
                  className="btn-3d w-full min-h-[64px] px-6 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
                >
                  الله أكبر — ابدأ الصلاة
                </button>
              </div>
            )}

            {stage === 'recite_choice' && (
              <div className="rounded-3xl bg-white border-2 border-slate-200 p-5 space-y-3.5">
                <h4 className="text-xl font-extrabold text-slate-900">
                  الركعة {currentRakaah}: نقرأ إيه وبأنهي صوت؟
                </h4>
                <div className="grid grid-cols-1 gap-3">
                  <button
                    type="button"
                    onClick={() => handleReciteChoice(true, true)}
                    className="flex items-center gap-3.5 text-right p-3 rounded-2xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-emerald-50 font-extrabold text-slate-900 cursor-pointer"
                  >
                    <ActivityThumbnail
                      visualKey="loud_voice"
                      className="w-20 h-16 shrink-0"
                    />
                    <span className="text-lg">
                      الفاتحة + سورة (بصوت مسموع جهرًا)
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReciteChoice(true, false)}
                    className="flex items-center gap-3.5 text-right p-3 rounded-2xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-emerald-50 font-extrabold text-slate-900 cursor-pointer"
                  >
                    <ActivityThumbnail
                      visualKey="fatiha_surah"
                      className="w-20 h-16 shrink-0"
                    />
                    <span className="text-lg">
                      الفاتحة + سورة (بصوت هادي سرًا)
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReciteChoice(false, false)}
                    className="flex items-center gap-3.5 text-right p-3 rounded-2xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-emerald-50 font-extrabold text-slate-900 cursor-pointer"
                  >
                    <ActivityThumbnail
                      visualKey="fatiha_only"
                      className="w-20 h-16 shrink-0"
                    />
                    <span className="text-lg">
                      الفاتحة فقط (بصوت هادي سرًا)
                    </span>
                  </button>
                </div>
                {feedback && (
                  <p className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 text-base font-extrabold">
                    {feedback}
                  </p>
                )}
              </div>
            )}

            {stage === 'moves' && (
              <div className="rounded-3xl bg-emerald-50 border-2 border-emerald-200 p-6 space-y-4 text-center">
                <h4 className="text-2xl font-extrabold text-emerald-950">
                  {RAKAAT_MOVES[moveIdx].title}
                </h4>
                <p className="font-quran text-2xl sm:text-3xl font-bold text-emerald-900 bg-white rounded-2xl p-4 border border-emerald-200">
                  «{RAKAAT_MOVES[moveIdx].dhikr}»
                </p>
                <p className="text-lg font-bold text-slate-800">
                  {RAKAAT_MOVES[moveIdx].shortNote}
                </p>
                <button
                  type="button"
                  onClick={handleNextMove}
                  className="btn-3d w-full min-h-[64px] inline-flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
                >
                  <span>الحركة التالية</span>
                  <ArrowLeft className="w-6 h-6" />
                </button>
              </div>
            )}

            {stage === 'tashahhud_choice' && (
              <div className="rounded-3xl bg-violet-50 border-2 border-violet-200 p-5 space-y-3.5">
                <h4 className="text-xl font-extrabold text-violet-950">
                  خلصنا الركعة {currentRakaah}! نعمل إيه دلوقتي؟
                </h4>
                <div className="grid grid-cols-1 gap-3">
                  <button
                    type="button"
                    onClick={() => handleTashahhudChoice(false)}
                    className="flex items-center gap-3.5 text-right p-3.5 rounded-2xl border-2 border-violet-200 bg-white hover:border-violet-500 font-extrabold text-slate-900 cursor-pointer"
                  >
                    <ActivityThumbnail
                      visualKey="pose_tashahhud"
                      className="w-20 h-16 shrink-0"
                    />
                    <span className="text-lg">
                      التشهد الأول بس، ونقوم للركعة اللي بعدها
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTashahhudChoice(true)}
                    className="flex items-center gap-3.5 text-right p-3.5 rounded-2xl border-2 border-violet-200 bg-white hover:border-violet-500 font-extrabold text-slate-900 cursor-pointer"
                  >
                    <ActivityThumbnail
                      visualKey="pose_tasleem"
                      className="w-20 h-16 shrink-0"
                    />
                    <span className="text-lg">
                      التشهد الأخير + الصلاة الإبراهيمية + التسليم
                    </span>
                  </button>
                </div>
                {feedback && (
                  <p className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 text-base font-extrabold">
                    {feedback}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
