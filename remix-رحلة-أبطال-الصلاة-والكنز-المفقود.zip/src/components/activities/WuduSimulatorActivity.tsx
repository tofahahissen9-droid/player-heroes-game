import React, { useEffect, useMemo, useState } from 'react';
import { Droplets, CheckCircle2, Sparkles } from 'lucide-react';
import { WuduStepId } from '../../types/game';
import { WuduStepIllustration } from '../illustrations/WuduStepIllustration';
import { GAME_IMAGES } from '../../data/assets';
import { audioEngine } from '../../utils/audioEngine';

interface WuduSimStep {
  id: WuduStepId;
  title: string;
  shortNote: string;
  ruling: 'فرض' | 'سنة';
  requiredTaps: number;
}

const WUDU_SIM_STEPS: WuduSimStep[] = [
  {
    id: 'niyyah',
    title: 'النية وبسم الله',
    shortNote: 'انْوِ في قلبك وقول: بِسْمِ اللَّهِ.',
    ruling: 'فرض',
    requiredTaps: 1,
  },
  {
    id: 'hands',
    title: 'غسل الكفين',
    shortNote: 'اغسل إيديك ٣ مرات.',
    ruling: 'سنة',
    requiredTaps: 3,
  },
  {
    id: 'mouth',
    title: 'المضمضة',
    shortNote: 'تمضمض بالمية ٣ مرات.',
    ruling: 'سنة',
    requiredTaps: 3,
  },
  {
    id: 'nose',
    title: 'الاستنشاق',
    shortNote: 'اغسل أنفك بالمية براحة ٣ مرات.',
    ruling: 'سنة',
    requiredTaps: 3,
  },
  {
    id: 'face',
    title: 'غسل الوجه',
    shortNote: 'اغسل وشك كله ٣ مرات.',
    ruling: 'فرض',
    requiredTaps: 3,
  },
  {
    id: 'right_arm',
    title: 'اليد اليمنى للمرفق',
    shortNote: 'اغسل إيدك اليمين للمرفق ٣ مرات.',
    ruling: 'فرض',
    requiredTaps: 3,
  },
  {
    id: 'left_arm',
    title: 'اليد اليسرى للمرفق',
    shortNote: 'اغسل إيدك الشمال للمرفق ٣ مرات.',
    ruling: 'فرض',
    requiredTaps: 3,
  },
  {
    id: 'head',
    title: 'مسح الرأس',
    shortNote: 'امسح رأسك بالمية مرة واحدة.',
    ruling: 'فرض',
    requiredTaps: 1,
  },
  {
    id: 'ears',
    title: 'مسح الأذنين',
    shortNote: 'امسح ودانك مرة واحدة.',
    ruling: 'سنة',
    requiredTaps: 1,
  },
  {
    id: 'right_foot',
    title: 'الرجل اليمنى للكعبين',
    shortNote: 'اغسل رجلك اليمين للكعبين ٣ مرات.',
    ruling: 'فرض',
    requiredTaps: 3,
  },
  {
    id: 'left_foot',
    title: 'الرجل اليسرى للكعبين',
    shortNote: 'اغسل رجلك الشمال للكعبين ٣ مرات.',
    ruling: 'فرض',
    requiredTaps: 3,
  },
];

interface WuduSimulatorActivityProps {
  onComplete: () => void;
  onAudioTrackChange?: (trackId: string) => void;
}

export const WuduSimulatorActivity: React.FC<WuduSimulatorActivityProps> = ({
  onComplete,
  onAudioTrackChange,
}) => {
  const [stepIdx, setStepIdx] = useState(0);
  const [phase, setPhase] = useState<'pick_next' | 'wash_action' | 'done'>(
    'pick_next'
  );
  const [washCount, setWashCount] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isErrorFeedback, setIsErrorFeedback] = useState(false);

  const currentStep = WUDU_SIM_STEPS[stepIdx];

  const choices = useMemo(() => {
    if (!currentStep) return [];
    const others = WUDU_SIM_STEPS.filter((s) => s.id !== currentStep.id);
    const distractors = [
      others[(stepIdx + 2) % others.length],
      others[(stepIdx + 5) % others.length],
    ];
    const combined = [currentStep, ...distractors];
    return combined.sort(
      (a, b) =>
        ((a.id.charCodeAt(0) + stepIdx * 7) % 11) -
        ((b.id.charCodeAt(0) + stepIdx * 7) % 11)
    );
  }, [currentStep, stepIdx]);

  useEffect(() => {
    if (!onAudioTrackChange) return;
    if (phase === 'done') {
      onAudioTrackChange('wudu_sim_done');
    } else if (phase === 'pick_next') {
      onAudioTrackChange(`wudu_sim_pick_${stepIdx}`);
      audioEngine.prefetchTrack(`wudu_sim_wash_${stepIdx}`);
    } else {
      onAudioTrackChange(`wudu_sim_wash_${stepIdx}`);
      if (stepIdx + 1 < WUDU_SIM_STEPS.length) {
        audioEngine.prefetchTrack(`wudu_sim_pick_${stepIdx + 1}`);
      } else {
        audioEngine.prefetchTrack('wudu_sim_done');
      }
    }
  }, [onAudioTrackChange, phase, stepIdx]);

  const handlePickChoice = (chosen: WuduSimStep) => {
    if (chosen.id === currentStep.id) {
      audioEngine.playCorrect();
      audioEngine.speakShortFeedback('bravo');
      setFeedback('برافو عليك!');
      setIsErrorFeedback(false);
      setWashCount(0);
      setPhase('wash_action');
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setIsErrorFeedback(true);
      setFeedback('يلا نحاول تاني! اختار الخطوة اللي عليها الدور.');
    }
  };

  const handleWashTap = () => {
    audioEngine.playWaterDrop();
    const next = washCount + 1;
    setWashCount(next);

    if (next >= currentStep.requiredTaps) {
      audioEngine.playCorrect();
      if (stepIdx + 1 >= WUDU_SIM_STEPS.length) {
        audioEngine.speakShortFeedback('bravo');
        setPhase('done');
        onComplete();
      } else {
        setTimeout(() => {
          setStepIdx((prev) => prev + 1);
          setPhase('pick_next');
          setWashCount(0);
          setFeedback(null);
        }, 550);
      }
    }
  };

  return (
    <div className="space-y-5">
      {/* Simple visual header */}
      <div className="relative h-28 rounded-3xl overflow-hidden border-2 border-sky-200">
        <img
          src={GAME_IMAGES.wuduOasis}
          alt="واحة الوضوء"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/25 to-transparent flex items-end justify-between p-4 text-white">
          <p className="text-lg md:text-xl font-extrabold">
            الخطوة {stepIdx + 1} من {WUDU_SIM_STEPS.length}
          </p>
          <div className="w-40 h-3.5 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-sky-400 transition-all duration-300"
              style={{
                width: `${
                  ((phase === 'done' ? WUDU_SIM_STEPS.length : stepIdx) /
                    WUDU_SIM_STEPS.length) *
                  100
                }%`,
              }}
            />
          </div>
        </div>
      </div>

      {phase === 'done' ? (
        <div className="rounded-3xl bg-emerald-50 border-2 border-emerald-300 p-6 md:p-8 text-center space-y-4">
          <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto" />
          <h4 className="text-2xl font-extrabold text-emerald-950">
            برافو عليك! أتممت الوضوء مع آدم!
          </h4>
          <p className="font-quran text-xl sm:text-2xl text-slate-900 bg-white rounded-2xl p-4 border border-emerald-200 leading-relaxed">
            «أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ،
            وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ»
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-5">
            <WuduStepIllustration
              stepId={
                phase === 'wash_action'
                  ? currentStep.id
                  : stepIdx > 0
                  ? WUDU_SIM_STEPS[stepIdx - 1].id
                  : 'niyyah'
              }
              stepNumber={phase === 'wash_action' ? stepIdx + 1 : undefined}
              repeatCount={
                phase === 'wash_action' ? currentStep.requiredTaps : undefined
              }
              rulingBadge={phase === 'wash_action' ? currentStep.ruling : undefined}
              className="w-full h-72 sm:h-80"
            />
          </div>

          <div className="md:col-span-7 space-y-4">
            {phase === 'pick_next' ? (
              <div className="space-y-3.5">
                <h4 className="text-xl font-extrabold text-slate-900">
                  آدم هيعمل إيه دلوقتي؟ اختار الصورة الصح:
                </h4>
                <div className="grid grid-cols-1 gap-3">
                  {choices.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => handlePickChoice(c)}
                      className="w-full text-right p-3 rounded-2xl border-3 border-sky-200 bg-white hover:border-sky-500 hover:bg-sky-50 font-extrabold text-slate-900 transition-all cursor-pointer flex items-center gap-4 shadow-xs"
                    >
                      <WuduStepIllustration
                        stepId={c.id}
                        compact
                        className="w-24 h-20 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-lg sm:text-xl font-extrabold text-slate-900">
                          {c.title}
                        </p>
                        <span
                          className={`text-sm font-extrabold ${
                            c.ruling === 'فرض'
                              ? 'text-emerald-700'
                              : 'text-amber-700'
                          }`}
                        >
                          {c.ruling}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
                {feedback && isErrorFeedback && (
                  <div className="p-4 rounded-2xl text-base font-extrabold bg-amber-50 text-amber-950 border-2 border-amber-300">
                    {feedback}
                  </div>
                )}
              </div>
            ) : (
              <div className="rounded-3xl bg-sky-50 border-2 border-sky-200 p-5 sm:p-6 space-y-5 text-center">
                <div className="space-y-1">
                  <h4 className="text-2xl font-extrabold text-sky-950">
                    {currentStep.title}
                  </h4>
                  <p className="text-xl font-extrabold text-slate-800">
                    {currentStep.shortNote}
                  </p>
                </div>

                {/* Big visual droplet counters */}
                <div className="flex items-center justify-center gap-4">
                  {Array.from({ length: currentStep.requiredTaps }).map(
                    (_, i) => {
                      const filled = i < washCount;
                      return (
                        <div
                          key={i}
                          className={`w-16 h-16 rounded-2xl border-3 flex flex-col items-center justify-center font-extrabold text-lg transition-all ${
                            filled
                              ? 'bg-sky-600 border-sky-700 text-white scale-105 shadow-md'
                              : 'bg-white border-sky-200 text-sky-400'
                          }`}
                        >
                          <Droplets className="w-6 h-6" />
                          <span className="text-xs tabular-nums">{i + 1}</span>
                        </div>
                      );
                    }
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleWashTap}
                  className="btn-3d w-full min-h-[68px] py-4 px-6 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xl shadow-[0_5px_0_#0369A1] flex items-center justify-center gap-3 cursor-pointer"
                >
                  {currentStep.id === 'niyyah' ? (
                    <>
                      <Sparkles className="w-6 h-6" />
                      <span>قول «بِسْمِ اللَّهِ» ({washCount}/{currentStep.requiredTaps})</span>
                    </>
                  ) : (
                    <>
                      <Droplets className="w-6 h-6" />
                      <span>
                        {currentStep.requiredTaps === 1
                          ? 'اضغط للمسح'
                          : 'اضغط للغسل بالمية'}{' '}
                        ({washCount}/{currentStep.requiredTaps})
                      </span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
