import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  Lock,
  Unlock,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { ActivityConfig, SpeakerId } from '../../types/game';
import { ActivityThumbnail } from '../illustrations/SceneIllustrations';
import { WuduStepIllustration } from '../illustrations/WuduStepIllustration';
import { CharacterAvatar } from '../CharacterAvatar';
import { SpeakerButton } from '../SpeakerButton';
import { WuduSimulatorActivity } from './WuduSimulatorActivity';
import { PrayerBuilderActivity } from './PrayerBuilderActivity';
import { audioEngine } from '../../utils/audioEngine';

interface ActivityArenaProps {
  activity: ActivityConfig;
  onSuccess: () => void;
}

function getInitialTrackId(activity: ActivityConfig): string {
  if (activity.type === 'true_false_multi') {
    return `act_${activity.id}_s0`;
  }
  if (activity.type === 'wudu_simulator') {
    return 'wudu_sim_pick_0';
  }
  if (activity.type === 'prayer_builder') {
    return `pb_${activity.prayerId}_takbeer`;
  }
  return `act_${activity.id}`;
}

export const ActivityArena: React.FC<ActivityArenaProps> = ({
  activity,
  onSuccess,
}) => {
  const [completed, setCompleted] = useState(false);
  const [subTrackId, setSubTrackId] = useState<string>(() =>
    getInitialTrackId(activity)
  );
  const [speakingWho, setSpeakingWho] = useState<SpeakerId | null>(null);

  useEffect(() => {
    setCompleted(false);
    setSubTrackId(getInitialTrackId(activity));
  }, [activity]);

  useEffect(() => {
    audioEngine.warmUpShortFeedback();
    const unsub = audioEngine.subscribeSpeaking((who) => setSpeakingWho(who));
    return unsub;
  }, []);

  const activeTrackId = useMemo(() => {
    if (
      completed &&
      activity.type !== 'wudu_simulator' &&
      activity.type !== 'prayer_builder'
    ) {
      return `act_${activity.id}_done`;
    }
    return subTrackId;
  }, [activity.id, activity.type, completed, subTrackId]);

  useEffect(() => {
    audioEngine.prefetchTrack(activeTrackId);
  }, [activeTrackId]);

  const triggerComplete = () => {
    if (completed) return;
    setCompleted(true);
    audioEngine.playCorrect();
    audioEngine.speakShortFeedback('bravo');
    onSuccess();
  };

  return (
    <div className="space-y-6">
      {/* Header with Adam/Noor & ONE Speaker Button */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b-2 border-slate-100">
        <div className="flex items-center gap-3.5 min-w-0">
          <CharacterAvatar
            character={activity.speaker}
            size="lg"
            isSpeaking={speakingWho !== null}
          />
          <div className="min-w-0">
            <h3 className="text-xl md:text-2xl font-extrabold text-slate-900">
              {activity.title}
            </h3>
            <p className="text-base md:text-lg font-bold text-slate-600 mt-0.5">
              {activity.instruction}
            </p>
          </div>
        </div>

        <SpeakerButton
          trackId={activeTrackId}
          speaker={activity.speaker}
          label="اسمع"
          variant="sky"
        />
      </div>

      {activity.type === 'image_select' && (
        <ImageSelectGame activity={activity} onPass={triggerComplete} />
      )}

      {activity.type === 'matching' && (
        <MatchingPairsGame activity={activity} onPass={triggerComplete} />
      )}

      {activity.type === 'ordering' && (
        <OrderingGame activity={activity} onPass={triggerComplete} />
      )}

      {activity.type === 'hotspot_discovery' && (
        <HotspotDiscoveryGame
          activity={activity}
          onPass={triggerComplete}
          onAudioTrackChange={setSubTrackId}
        />
      )}

      {activity.type === 'true_false_multi' && (
        <TrueFalseMultiGame
          activity={activity}
          onPass={triggerComplete}
          onAudioTrackChange={setSubTrackId}
        />
      )}

      {activity.type === 'wudu_simulator' && (
        <WuduSimulatorActivity
          onComplete={triggerComplete}
          onAudioTrackChange={setSubTrackId}
        />
      )}

      {activity.type === 'spot_error' && (
        <SpotErrorGame activity={activity} onPass={triggerComplete} />
      )}

      {activity.type === 'memory_cards' && (
        <MemoryCardsGame activity={activity} onPass={triggerComplete} />
      )}

      {activity.type === 'prayer_builder' && (
        <PrayerBuilderActivity
          prayerId={activity.prayerId}
          prayerName={activity.prayerName}
          targetRakaat={activity.targetRakaat}
          targetSajdahs={activity.targetSajdahs}
          isLoudFirstTwo={activity.isLoudFirstTwo}
          onComplete={triggerComplete}
          onAudioTrackChange={setSubTrackId}
        />
      )}

      {activity.type === 'treasure_lock' && (
        <TreasureLockGame activity={activity} onPass={triggerComplete} />
      )}

      {completed && (
        <div className="flex items-center gap-3 rounded-2xl bg-emerald-50 border-2 border-emerald-400 p-5 text-emerald-950 font-extrabold text-xl shadow-xs">
          <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
          <span>{activity.successMessage}</span>
        </div>
      )}
    </div>
  );
};

// 1. IMAGE SELECT
const ImageSelectGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'image_select' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [hint, setHint] = useState<string | null>(null);

  const handleSelect = (opt: (typeof activity.options)[number]) => {
    setSelectedId(opt.id);
    if (opt.isCorrect) {
      setHint(null);
      onPass();
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setHint(`يلا نحاول تاني! ${activity.hint}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {activity.options.map((opt) => {
          const isPicked = selectedId === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => handleSelect(opt)}
              className={`rounded-3xl border-3 p-4 text-center transition-all cursor-pointer flex flex-col gap-3 shadow-xs ${
                isPicked && opt.isCorrect
                  ? 'border-emerald-500 bg-emerald-50 ring-4 ring-emerald-200'
                  : isPicked
                  ? 'border-amber-400 bg-amber-50'
                  : 'border-slate-200 bg-white hover:border-sky-400 hover:bg-sky-50/40'
              }`}
            >
              <ActivityThumbnail visualKey={opt.visual} className="w-full h-40" />
              <span className="font-extrabold text-slate-900 text-xl">
                {opt.label}
              </span>
            </button>
          );
        })}
      </div>
      {hint && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 font-extrabold text-base md:text-lg">
          {hint}
        </div>
      )}
    </div>
  );
};

// 2. MATCHING PAIRS
const MatchingPairsGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'matching' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const shuffledRight = useMemo(() => {
    return [...activity.pairs].sort((a, b) =>
      a.rightLabel.localeCompare(b.rightLabel, 'ar')
    );
  }, [activity.pairs]);

  const handleRightClick = (pair: (typeof activity.pairs)[number]) => {
    if (!selectedLeft || matchedIds.includes(pair.id)) return;
    const pickedLeft = activity.pairs.find((p) => p.id === selectedLeft);
    const isMatch =
      selectedLeft === pair.id ||
      (pickedLeft && pickedLeft.rightLabel === pair.rightLabel);

    if (isMatch) {
      audioEngine.playCorrect();
      const targetId = selectedLeft;
      const next = [...matchedIds, targetId];
      setMatchedIds(next);
      setSelectedLeft(null);
      setErrorMsg(null);
      if (next.length === activity.pairs.length) {
        onPass();
      } else {
        audioEngine.speakShortFeedback('bravo');
      }
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setErrorMsg(`يلا نحاول تاني! ${activity.hint}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-sky-50 border border-sky-200 px-4 py-3 text-center font-extrabold text-sky-950 text-base md:text-lg">
        {selectedLeft
          ? '٢. دلوقتي اضغط على الكارت اللي يناسبها من الشمال ←'
          : '١. اضغط على صورة من اليمين الأول →'}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-3">
          {activity.pairs.map((p) => {
            const isMatched = matchedIds.includes(p.id);
            const isActive = selectedLeft === p.id;
            return (
              <button
                key={p.id}
                type="button"
                disabled={isMatched}
                onClick={() => {
                  audioEngine.playClick();
                  setSelectedLeft(p.id);
                  setErrorMsg(null);
                }}
                className={`w-full min-h-[84px] flex items-center gap-4 p-3.5 rounded-2xl border-3 text-right transition-all cursor-pointer ${
                  isMatched
                    ? 'border-emerald-400 bg-emerald-50 opacity-80'
                    : isActive
                    ? 'border-sky-500 bg-sky-50 ring-4 ring-sky-200 scale-[1.01]'
                    : 'border-slate-200 bg-white hover:border-sky-400'
                }`}
              >
                {p.leftVisual && (
                  <ActivityThumbnail
                    visualKey={p.leftVisual}
                    className="w-24 h-20 shrink-0"
                  />
                )}
                <span className="font-extrabold text-lg text-slate-900 flex-1">
                  {isMatched ? `✓ ${p.leftLabel}` : p.leftLabel}
                </span>
              </button>
            );
          })}
        </div>

        <div className="space-y-3">
          {shuffledRight.map((p, idx) => {
            const matchingLeftCount = activity.pairs.filter(
              (lp) => lp.rightLabel === p.rightLabel
            ).length;
            const matchedSameLabelCount = activity.pairs.filter(
              (lp) => lp.rightLabel === p.rightLabel && matchedIds.includes(lp.id)
            ).length;
            const isMatched =
              matchingLeftCount === 1
                ? matchedIds.includes(p.id)
                : matchedSameLabelCount >=
                  shuffledRight
                    .slice(0, idx + 1)
                    .filter((sr) => sr.rightLabel === p.rightLabel).length;

            return (
              <button
                key={`${p.id}_${idx}`}
                type="button"
                disabled={isMatched || !selectedLeft}
                onClick={() => handleRightClick(p)}
                className={`w-full min-h-[84px] flex items-center gap-4 p-4 rounded-2xl border-3 text-right font-extrabold text-lg transition-all cursor-pointer ${
                  isMatched
                    ? 'border-emerald-400 bg-emerald-50 text-emerald-900'
                    : selectedLeft
                    ? 'border-amber-400 bg-amber-50/70 hover:border-amber-500 text-slate-900 shadow-xs'
                    : 'border-slate-200 bg-slate-50 text-slate-400'
                }`}
              >
                {p.rightVisual && (
                  <ActivityThumbnail
                    visualKey={p.rightVisual}
                    className="w-20 h-16 shrink-0"
                  />
                )}
                <span className="flex-1">
                  {isMatched ? `✓ ${p.rightLabel}` : p.rightLabel}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 font-extrabold text-base md:text-lg">
          {errorMsg}
        </div>
      )}
    </div>
  );
};

// 3. ORDERING
const OrderingGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'ordering' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const initialOrder = useMemo(() => {
    return [...activity.items].reverse();
  }, [activity.items]);

  const [items, setItems] = useState(initialOrder);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const moveItem = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= items.length) return;
    audioEngine.playClick();
    const copy = [...items];
    const [removed] = copy.splice(fromIdx, 1);
    copy.splice(toIdx, 0, removed);
    setItems(copy);
    setFeedback(null);
  };

  const handleCheck = () => {
    const allCorrect = items.every((item, idx) => item.correctIndex === idx);
    if (allCorrect) {
      setFeedback(null);
      onPass();
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setFeedback(`يلا نحاول تاني! ${activity.hint}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        {items.map((item, idx) => (
          <React.Fragment key={item.id}>
            <div
              draggable
              onDragStart={() => setDragIndex(idx)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (dragIndex !== null && dragIndex !== idx) {
                  moveItem(dragIndex, idx);
                }
                setDragIndex(null);
              }}
              className="flex items-center justify-between gap-3 rounded-2xl border-3 border-slate-200 bg-white px-4 py-3 shadow-xs cursor-grab active:cursor-grabbing"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <span className="w-11 h-11 rounded-2xl bg-emerald-600 text-white font-extrabold text-xl flex items-center justify-center shrink-0 tabular-nums">
                  {idx + 1}
                </span>
                {item.visual && (
                  <ActivityThumbnail
                    visualKey={item.visual}
                    className="w-20 h-16 shrink-0"
                  />
                )}
                <p className="font-extrabold text-lg sm:text-xl text-slate-900">
                  {item.label}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  aria-label="تحريك لأعلى"
                  disabled={idx === 0}
                  onClick={() => moveItem(idx, idx - 1)}
                  className="w-12 h-12 rounded-xl border-2 border-slate-200 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-400 disabled:opacity-30 flex items-center justify-center cursor-pointer"
                >
                  <ArrowUp className="w-6 h-6 text-slate-800" />
                </button>
                <button
                  type="button"
                  aria-label="تحريك لأسفل"
                  disabled={idx === items.length - 1}
                  onClick={() => moveItem(idx, idx + 1)}
                  className="w-12 h-12 rounded-xl border-2 border-slate-200 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-400 disabled:opacity-30 flex items-center justify-center cursor-pointer"
                >
                  <ArrowDown className="w-6 h-6 text-slate-800" />
                </button>
              </div>
            </div>

            {idx < items.length - 1 && (
              <div className="flex justify-center" aria-hidden="true">
                <ArrowDown className="w-5 h-5 text-emerald-500 animate-nudge-y" />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 font-extrabold text-base md:text-lg">
          {feedback}
        </div>
      )}

      <button
        type="button"
        onClick={handleCheck}
        className="btn-3d w-full sm:w-auto min-h-[60px] px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
      >
        تأكيد الترتيب
      </button>
    </div>
  );
};

// 4. HOTSPOT DISCOVERY
const HotspotDiscoveryGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'hotspot_discovery' }>;
  onPass: () => void;
  onAudioTrackChange: (trackId: string) => void;
}> = ({ activity, onPass, onAudioTrackChange }) => {
  const [visited, setVisited] = useState<string[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);

  const activeSpot = activity.hotspots.find((h) => h.id === activeId);

  useEffect(() => {
    onAudioTrackChange(
      activeId ? `act_${activity.id}_${activeId}` : `act_${activity.id}`
    );
  }, [activeId, activity.id, onAudioTrackChange]);

  const handleOpenSpot = (spotId: string) => {
    audioEngine.playClick();
    setActiveId(spotId);
    if (!visited.includes(spotId)) {
      const next = [...visited, spotId];
      setVisited(next);
      if (next.length === activity.hotspots.length) {
        onPass();
      }
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
      <div className="md:col-span-6 relative rounded-3xl border-3 border-sky-200 bg-gradient-to-b from-sky-50 to-emerald-50 h-80 sm:h-96 overflow-hidden">
        {activity.scene === 'wudu_body' ? (
          <WuduStepIllustration
            stepId="niyyah"
            className="w-full h-full border-0"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center p-4">
            <svg viewBox="0 0 300 200" className="w-full h-full" aria-hidden="true">
              <rect x="28" y="55" width="76" height="82" rx="10" fill="#1E293B" />
              <rect x="28" y="72" width="76" height="14" fill="#F59E0B" />
              <path
                d="M132 72 L116 86 L124 98 L134 90 L134 142 L166 142 L166 90 L176 98 L184 86 L168 72 L158 78 Q150 83 142 78 Z"
                fill="#FFFFFF"
                stroke="#059669"
                strokeWidth="3.5"
              />
              <path
                d="M235 55 C210 92 210 132 235 132 C260 132 260 92 235 55 Z"
                fill="#0EA5E9"
              />
              <ellipse cx="228" cy="104" rx="6" ry="12" fill="#BAE6FD" opacity="0.7" />
            </svg>
          </div>
        )}

        {activity.hotspots.map((spot, idx) => {
          const isDone = visited.includes(spot.id);
          const isActive = activeId === spot.id;
          return (
            <button
              key={spot.id}
              type="button"
              onClick={() => handleOpenSpot(spot.id)}
              style={{
                left: `${spot.xPercent}%`,
                top: `${spot.yPercent}%`,
              }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 w-14 h-14 rounded-full font-extrabold text-xl shadow-lg border-3 border-white flex items-center justify-center transition-transform hover:scale-110 cursor-pointer ${
                isActive
                  ? 'bg-sky-600 text-white ring-4 ring-sky-200 scale-110'
                  : isDone
                  ? 'bg-emerald-600 text-white'
                  : 'bg-amber-500 text-white animate-pulse-soft'
              }`}
              aria-label={spot.title}
            >
              {isDone ? '✓' : idx + 1}
            </button>
          );
        })}
      </div>

      <div className="md:col-span-6 space-y-4">
        <div className="flex items-center gap-2 text-base font-extrabold text-slate-700 tabular-nums">
          <span>
            اكتشفت {visited.length} من {activity.hotspots.length}
          </span>
        </div>

        {activeSpot ? (
          <div className="rounded-3xl bg-white border-3 border-emerald-300 p-5 space-y-4 shadow-sm">
            {activeSpot.visual && (
              <ActivityThumbnail
                visualKey={activeSpot.visual}
                className="w-full h-36"
              />
            )}
            <div className="flex items-center justify-between gap-2">
              <h4 className="text-xl font-extrabold text-emerald-950">
                {activeSpot.title}
              </h4>
              {activeSpot.rulingTag && (
                <span className="text-sm font-extrabold text-amber-800 bg-amber-100 px-3 py-1 rounded-xl">
                  {activeSpot.rulingTag}
                </span>
              )}
            </div>
            <p className="text-lg text-slate-800 font-bold leading-relaxed">
              {activeSpot.description}
            </p>
          </div>
        ) : (
          <div className="rounded-3xl bg-amber-50 border-2 border-amber-300 p-6 text-amber-950 font-extrabold text-lg text-center">
            اضغط على الدوائر المرقمة على الصورة!
          </div>
        )}
      </div>
    </div>
  );
};

// 5. TRUE / FALSE MULTI
const TrueFalseMultiGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'true_false_multi' }>;
  onPass: () => void;
  onAudioTrackChange: (trackId: string) => void;
}> = ({ activity, onPass, onAudioTrackChange }) => {
  const [idx, setIdx] = useState(0);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(
    null
  );

  const stmt = activity.statements[idx];

  useEffect(() => {
    onAudioTrackChange(`act_${activity.id}_s${idx}`);
  }, [activity.id, idx, onAudioTrackChange]);

  const handleAnswer = (val: boolean) => {
    if (feedback?.ok) return;
    if (val === stmt.isTrue) {
      audioEngine.playCorrect();
      if (idx + 1 >= activity.statements.length) {
        setFeedback({ ok: true, text: stmt.explanation });
        onPass();
      } else {
        audioEngine.speakShortFeedback('bravo');
        setFeedback({ ok: true, text: stmt.explanation });
      }
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setFeedback({ ok: false, text: `يلا نحاول تاني! ${stmt.explanation}` });
    }
  };

  const handleNextStmt = () => {
    audioEngine.playClick();
    setIdx((p) => p + 1);
    setFeedback(null);
  };

  return (
    <div className="rounded-3xl bg-white border-2 border-slate-200 p-5 sm:p-6 space-y-5 text-center">
      <p className="text-sm font-extrabold text-slate-500 tabular-nums">
        {idx + 1} من {activity.statements.length}
      </p>

      <ActivityThumbnail
        visualKey={stmt.visual}
        className="w-full max-w-md h-48 sm:h-56 mx-auto"
      />

      <p className="text-2xl md:text-3xl font-extrabold text-slate-900">
        {stmt.text}
      </p>

      <div className="flex flex-wrap gap-4 max-w-lg mx-auto">
        <button
          type="button"
          disabled={Boolean(feedback?.ok)}
          onClick={() => handleAnswer(true)}
          className="btn-3d flex-1 min-w-[140px] min-h-[68px] py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white font-extrabold text-2xl shadow-[0_5px_0_#047857] cursor-pointer"
        >
          صح ✓
        </button>
        <button
          type="button"
          disabled={Boolean(feedback?.ok)}
          onClick={() => handleAnswer(false)}
          className="btn-3d flex-1 min-w-[140px] min-h-[68px] py-4 px-6 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white font-extrabold text-2xl shadow-[0_5px_0_#BE123C] cursor-pointer"
        >
          غلط ✕
        </button>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-2xl font-extrabold text-lg space-y-3 ${
            feedback.ok
              ? 'bg-emerald-50 border-2 border-emerald-300 text-emerald-950'
              : 'bg-amber-50 border-2 border-amber-300 text-amber-950'
          }`}
        >
          <p>{feedback.text}</p>
          {feedback.ok && idx + 1 < activity.statements.length && (
            <button
              type="button"
              onClick={handleNextStmt}
              className="btn-3d inline-flex items-center gap-2 px-7 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-lg shadow-[0_4px_0_#047857] cursor-pointer"
            >
              <span>الصورة اللي بعدها</span>
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};

// 6. SPOT THE ERROR
const SpotErrorGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'spot_error' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const handlePick = (step: (typeof activity.steps)[number]) => {
    setSelectedId(step.id);
    if (step.isError) {
      setMsg(step.correction);
      onPass();
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setMsg(`يلا نحاول تاني! الخطوة دي صح. ${activity.hint}`);
    }
  };

  return (
    <div className="space-y-4">
      <p className="text-lg font-extrabold text-slate-700">
        {activity.scenarioTitle}
      </p>
      <div className="space-y-3">
        {activity.steps.map((step) => {
          const isPicked = selectedId === step.id;
          return (
            <button
              key={step.id}
              type="button"
              onClick={() => handlePick(step)}
              className={`w-full text-right p-4 rounded-2xl border-3 font-extrabold transition-all cursor-pointer flex items-center gap-4 ${
                isPicked && step.isError
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-950'
                  : isPicked
                  ? 'border-amber-400 bg-amber-50 text-amber-950'
                  : 'border-slate-200 bg-white hover:border-rose-400 text-slate-900'
              }`}
            >
              {step.visual && (
                <ActivityThumbnail
                  visualKey={step.visual}
                  className="w-24 h-20 shrink-0"
                />
              )}
              <span className="text-lg sm:text-xl flex-1">{step.label}</span>
            </button>
          );
        })}
      </div>
      {msg && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 font-extrabold text-base md:text-lg">
          {msg}
        </div>
      )}
    </div>
  );
};

// 7. MEMORY CARDS
const MemoryCardsGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'memory_cards' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const deck = useMemo(() => {
    return activity.cards
      .map((c, idx) => ({ ...c, uid: `${c.pairId}_${c.role}_${idx}` }))
      .sort(
        (a, b) =>
          ((a.uid.charCodeAt(0) * 13) % 17) - ((b.uid.charCodeAt(0) * 13) % 17)
      );
  }, [activity.cards]);

  const [flipped, setFlipped] = useState<string[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);

  const handleFlip = (card: (typeof deck)[number]) => {
    if (
      flipped.includes(card.uid) ||
      matchedPairs.includes(card.pairId) ||
      flipped.length >= 2
    ) {
      return;
    }
    audioEngine.playClick();
    const nextFlipped = [...flipped, card.uid];
    setFlipped(nextFlipped);

    if (nextFlipped.length === 2) {
      const first = deck.find((d) => d.uid === nextFlipped[0]);
      const second = deck.find((d) => d.uid === nextFlipped[1]);
      if (first && second && first.pairId === second.pairId) {
        audioEngine.playCorrect();
        const nextMatched = [...matchedPairs, first.pairId];
        setMatchedPairs(nextMatched);
        setFlipped([]);
        if (nextMatched.length === activity.cards.length / 2) {
          onPass();
        } else {
          audioEngine.speakShortFeedback('bravo');
        }
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-base font-extrabold text-slate-700">
        <span className="tabular-nums">
          الأزواج: {matchedPairs.length} / {activity.cards.length / 2}
        </span>
        <button
          type="button"
          onClick={() => {
            setFlipped([]);
            setMatchedPairs([]);
          }}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-50 text-sky-800 hover:bg-sky-100 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>إعادة خلط</span>
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
        {deck.map((card, idx) => {
          const isRevealed =
            flipped.includes(card.uid) || matchedPairs.includes(card.pairId);
          const isMatched = matchedPairs.includes(card.pairId);
          return (
            <button
              key={card.uid}
              type="button"
              onClick={() => handleFlip(card)}
              className={`min-h-[132px] p-3 rounded-2xl border-3 font-extrabold transition-all cursor-pointer flex flex-col items-center justify-center gap-2 text-center ${
                isMatched
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-950'
                  : isRevealed
                  ? 'border-sky-500 bg-white text-slate-900'
                  : 'border-violet-300 bg-gradient-to-br from-violet-600 to-indigo-700 text-white hover:opacity-95'
              }`}
            >
              {isRevealed ? (
                <>
                  {card.visual && (
                    <ActivityThumbnail
                      visualKey={card.visual}
                      className="w-full h-20"
                    />
                  )}
                  <span className="text-base sm:text-lg leading-snug">
                    {card.text}
                  </span>
                </>
              ) : (
                <div className="flex flex-col items-center gap-1">
                  <Sparkles className="w-7 h-7 opacity-90" />
                  <span className="text-lg tabular-nums">{idx + 1}</span>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

// 8. TREASURE LOCK PUZZLE
const TreasureLockGame: React.FC<{
  activity: Extract<ActivityConfig, { type: 'treasure_lock' }>;
  onPass: () => void;
}> = ({ activity, onPass }) => {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    activity.dials.forEach((d) => {
      init[d.id] = d.options[0];
    });
    return init;
  });
  const [unlocked, setUnlocked] = useState(false);
  const [hint, setHint] = useState<string | null>(null);

  const handleUnlock = () => {
    const allCorrect = activity.dials.every(
      (d) => values[d.id] === d.correctOption
    );
    if (allCorrect) {
      setUnlocked(true);
      setHint(null);
      onPass();
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
      setHint(`يلا نحاول تاني! ${activity.hint}`);
    }
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-amber-50 to-yellow-50/70 border-2 border-amber-300 p-5 sm:p-6 space-y-5">
      <div className="flex items-center gap-3.5">
        <div
          className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${
            unlocked ? 'bg-emerald-600 text-white' : 'bg-amber-500 text-white'
          }`}
        >
          {unlocked ? (
            <Unlock className="w-7 h-7" />
          ) : (
            <Lock className="w-7 h-7" />
          )}
        </div>
        <div>
          <h4 className="text-xl font-extrabold text-slate-900">
            أقفال الكنز الذهبية
          </h4>
          <p className="text-base font-bold text-slate-600">
            اختار الإجابة الصح لكل قفل
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {activity.dials.map((dial) => (
          <div
            key={dial.id}
            className="rounded-2xl bg-white border-2 border-amber-200 p-4 space-y-3"
          >
            {dial.visual && (
              <ActivityThumbnail
                visualKey={dial.visual}
                className="w-full h-24"
              />
            )}
            <p className="text-base font-extrabold text-slate-900 text-center">
              {dial.label}
            </p>
            <div className="space-y-2">
              {dial.options.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setValues((prev) => ({ ...prev, [dial.id]: opt }));
                  }}
                  className={`w-full min-h-[48px] py-2.5 px-3 rounded-xl text-base font-extrabold border-2 transition-colors cursor-pointer ${
                    values[dial.id] === opt
                      ? 'bg-amber-500 text-white border-amber-600'
                      : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-amber-50'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {hint && (
        <div className="p-4 rounded-2xl bg-white border-2 border-amber-300 text-amber-950 font-extrabold text-base md:text-lg">
          {hint}
        </div>
      )}

      <button
        type="button"
        onClick={handleUnlock}
        className="btn-3d w-full sm:w-auto min-h-[60px] px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xl shadow-[0_5px_0_#B45309] cursor-pointer"
      >
        افتح القفل الذهبي
      </button>
    </div>
  );
};
