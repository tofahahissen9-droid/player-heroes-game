import React, { useEffect, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { SpeakerId } from '../types/game';
import { audioEngine } from '../utils/audioEngine';

interface IntroDialogueScreenProps {
  onContinueToMap: () => void;
}

const INTRO_LINES: { speaker: 'adam' | 'noor'; name: string; text: string }[] = [
  {
    speaker: 'adam',
    name: 'آدم',
    text: 'أهلًا بيكم! يلا نبدأ رحلة جميلة مع بعض.',
  },
  {
    speaker: 'noor',
    name: 'نور',
    text: 'هنتعلم الوضوء والصلاة خطوة بخطوة عشان نفتح الكنز!',
  },
];

export const IntroDialogueScreen: React.FC<IntroDialogueScreenProps> = ({
  onContinueToMap,
}) => {
  const [step, setStep] = useState(0);
  const [speakingWho, setSpeakingWho] = useState<SpeakerId | null>(null);

  useEffect(() => {
    const unsub = audioEngine.subscribeSpeaking((sp) => setSpeakingWho(sp));
    return () => {
      unsub();
      audioEngine.stopSpeech();
    };
  }, []);

  const currentLine = INTRO_LINES[step];

  const trackId = `intro_step_${step}`;

  useEffect(() => {
    audioEngine.prefetchTracks(['intro_step_0', 'intro_step_1']);
  }, []);

  useEffect(() => {
    void audioEngine.playTrack(trackId, currentLine.speaker, trackId);
  }, [currentLine.speaker, trackId]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-[#FAF8F2] to-emerald-50 flex items-center justify-center p-4">
      <div className="max-w-3xl w-full rounded-3xl bg-white border-4 border-emerald-200 p-6 md:p-10 shadow-xl space-y-7">
        {/* Top Row: ONE Speaker Button */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            {INTRO_LINES.map((_, idx) => (
              <span
                key={idx}
                className={`h-3.5 rounded-full transition-all ${
                  idx === step ? 'w-10 bg-emerald-600' : 'w-3.5 bg-slate-300'
                }`}
              />
            ))}
          </div>
          <SpeakerButton
            trackId={trackId}
            speaker={currentLine.speaker}
            label="اسمع"
            variant={currentLine.speaker === 'adam' ? 'emerald' : 'sky'}
          />
        </div>

        {/* Large Character Focus */}
        <div className="flex items-center justify-center gap-8 sm:gap-12 py-2">
          <div className="text-center space-y-2">
            <CharacterAvatar
              character="adam"
              size="xl"
              isSpeaking={speakingWho !== null && currentLine.speaker === 'adam'}
              className={`!w-36 !h-36 sm:!w-44 sm:!h-44 transition-all ${
                currentLine.speaker === 'adam'
                  ? 'scale-105 ring-4 ring-emerald-300'
                  : 'opacity-65 scale-90'
              }`}
            />
            <p className="font-extrabold text-emerald-900 text-2xl">آدم</p>
          </div>

          <div className="text-center space-y-2">
            <CharacterAvatar
              character="noor"
              size="xl"
              isSpeaking={speakingWho !== null && currentLine.speaker === 'noor'}
              className={`!w-36 !h-36 sm:!w-44 sm:!h-44 transition-all ${
                currentLine.speaker === 'noor'
                  ? 'scale-105 ring-4 ring-sky-300'
                  : 'opacity-65 scale-90'
              }`}
            />
            <p className="font-extrabold text-sky-900 text-2xl">نور</p>
          </div>
        </div>

        {/* ONE Short Simple Sentence Under Characters */}
        <div
          className={`rounded-3xl border-2 p-6 text-center transition-colors ${
            currentLine.speaker === 'adam'
              ? 'bg-emerald-50 border-emerald-300'
              : 'bg-sky-50 border-sky-300'
          }`}
        >
          <p className="text-2xl md:text-3xl font-extrabold text-slate-900 leading-relaxed">
            «{currentLine.text}»
          </p>
        </div>

        {/* Large Action Button */}
        <div className="flex justify-center">
          {step < INTRO_LINES.length - 1 ? (
            <button
              type="button"
              onClick={() => {
                audioEngine.playClick();
                setStep(step + 1);
              }}
              className="btn-3d inline-flex items-center gap-3 px-10 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-2xl shadow-[0_5px_0_#047857] cursor-pointer"
            >
              <span>التالي</span>
              <ArrowLeft className="w-7 h-7" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                audioEngine.stopSpeech();
                audioEngine.playClick();
                onContinueToMap();
              }}
              className="btn-3d inline-flex items-center gap-3 px-10 py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-2xl shadow-[0_5px_0_#B45309] cursor-pointer"
            >
              <span>افتح الخريطة</span>
              <ArrowLeft className="w-7 h-7" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
