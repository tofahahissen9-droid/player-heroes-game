import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Star,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  Award,
  ArrowLeft,
} from 'lucide-react';
import { BadgeInfo, QuizQuestion, SpeakerId } from '../../types/game';
import { ActivityThumbnail } from '../illustrations/SceneIllustrations';
import { CharacterAvatar } from '../CharacterAvatar';
import { SpeakerButton } from '../SpeakerButton';
import { audioEngine } from '../../utils/audioEngine';

interface QuizArenaProps {
  questions: QuizQuestion[];
  badge: BadgeInfo;
  onPassLevel: (score: number) => void;
  onBackToMap: () => void;
}

export const QuizArena: React.FC<QuizArenaProps> = ({
  questions,
  badge,
  onPassLevel,
  onBackToMap,
}) => {
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [wasCorrect, setWasCorrect] = useState(false);
  const [finished, setFinished] = useState(false);
  const [speakingWho, setSpeakingWho] = useState<SpeakerId | null>(null);

  const currentQ = questions[qIdx];

  useEffect(() => {
    audioEngine.warmUpShortFeedback();
    const unsub = audioEngine.subscribeSpeaking((who) => setSpeakingWho(who));
    return unsub;
  }, []);

  const activeQuestionTrackId = useMemo(() => {
    if (!currentQ) return '';
    if (!answered) return `quiz_${currentQ.id}_ask`;
    return wasCorrect ? `quiz_${currentQ.id}_correct` : `quiz_${currentQ.id}_wrong`;
  }, [answered, currentQ, wasCorrect]);

  useEffect(() => {
    if (!finished && currentQ) {
      audioEngine.prefetchTracks([
        `quiz_${currentQ.id}_ask`,
        `quiz_${currentQ.id}_correct`,
        `quiz_${currentQ.id}_wrong`,
      ]);
      const nextQ = questions[qIdx + 1];
      if (nextQ) {
        audioEngine.prefetchTrack(`quiz_${nextQ.id}_ask`);
      }
    }
  }, [currentQ, finished, qIdx, questions]);

  const handleRecordAnswer = (correct: boolean) => {
    if (answered) return;
    setAnswered(true);
    setWasCorrect(correct);

    if (correct) {
      setScore((prev) => prev + 1);
      audioEngine.playCorrect();
      audioEngine.speakShortFeedback('bravo');
    } else {
      audioEngine.playTryAgain();
      audioEngine.speakShortFeedback('retry');
    }
  };

  const handleNext = () => {
    audioEngine.stopSpeech();
    audioEngine.playClick();
    if (qIdx + 1 < questions.length) {
      setQIdx((p) => p + 1);
      setAnswered(false);
      setWasCorrect(false);
    } else {
      const finalScore = score;
      setFinished(true);
      if (finalScore >= 3) {
        audioEngine.playBadgeFanfare();
        onPassLevel(finalScore);
      }
    }
  };

  const handleRestartQuiz = () => {
    audioEngine.stopSpeech();
    audioEngine.playClick();
    setQIdx(0);
    setScore(0);
    setAnswered(false);
    setWasCorrect(false);
    setFinished(false);
  };

  if (finished) {
    const passed = score >= 3;
    const passTrackId = `quiz_pass_${badge.levelId}`;
    const retryTrackId = `quiz_retry_${badge.levelId}`;

    return (
      <div className="rounded-3xl bg-white border-3 border-amber-300 p-6 md:p-8 text-center space-y-6 shadow-lg">
        {passed ? (
          <>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <CharacterAvatar
                  character="adam"
                  size="lg"
                  isSpeaking={speakingWho !== null}
                />
                <CharacterAvatar
                  character="noor"
                  size="lg"
                  isSpeaking={speakingWho !== null}
                />
              </div>
              <SpeakerButton
                trackId={passTrackId}
                speaker="adam"
                label="اسمع"
                variant="emerald"
              />
            </div>

            <div
              className={`w-28 h-28 mx-auto rounded-3xl bg-gradient-to-br ${badge.colorClass} text-white flex items-center justify-center shadow-lg animate-float-slow`}
            >
              <Award className="w-16 h-16" />
            </div>

            <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900">
              برافو عليك! كسبت شارة «{badge.title}»
            </h3>
            <p className="text-slate-700 font-bold text-xl">
              {badge.subtitle}
            </p>
            <div className="flex items-center justify-center gap-2 text-amber-500">
              {Array.from({ length: score }).map((_, idx) => (
                <Star key={idx} className="w-10 h-10 fill-amber-400" />
              ))}
            </div>
            <div className="pt-2">
              <button
                type="button"
                onClick={onBackToMap}
                className="btn-3d px-9 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
              >
                رجوع للخريطة
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between gap-3">
              <CharacterAvatar
                character="adam"
                size="lg"
                isSpeaking={speakingWho !== null}
              />
              <SpeakerButton
                trackId={retryTrackId}
                speaker="adam"
                label="اسمع"
                variant="amber"
              />
            </div>

            <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900">
              محاولة جميلة! نتيجتك {score} من {questions.length}
            </h3>
            <p className="text-xl text-slate-700 font-bold">
              يلا نحاول تاني! محتاجين ٣ صح على الأقل عشان نكسب الشارة.
            </p>
            <button
              type="button"
              onClick={handleRestartQuiz}
              className="btn-3d inline-flex items-center gap-3 px-9 py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xl shadow-[0_5px_0_#B45309] cursor-pointer"
            >
              <RotateCcw className="w-6 h-6" />
              <span>حاول تاني</span>
            </button>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-3xl bg-white border-3 border-amber-200 p-5 md:p-7 space-y-6 shadow-sm">
      {/* Clean Header + ONE Speaker Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b-2 border-slate-100">
        <div className="flex items-center gap-3">
          <CharacterAvatar
            character={qIdx % 2 === 0 ? 'noor' : 'adam'}
            size="md"
            isSpeaking={speakingWho !== null}
          />
          <div>
            <span className="block text-base font-extrabold text-emerald-800 tabular-nums">
              سؤال {qIdx + 1} من {questions.length}
            </span>
            <span className="text-sm font-extrabold text-amber-600 tabular-nums inline-flex items-center gap-1">
              <Star className="w-4 h-4 fill-amber-400" />
              <span>{score} صح</span>
            </span>
          </div>
        </div>

        <SpeakerButton
          trackId={activeQuestionTrackId}
          speaker="adam"
          label="اسمع"
          variant="sky"
        />
      </div>

      <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900 leading-snug text-center">
        {currentQ.prompt}
      </h3>

      {currentQ.kind === 'mcq' && (
        <QuizMcqView
          key={currentQ.id}
          question={currentQ}
          answered={answered}
          onAnswer={handleRecordAnswer}
        />
      )}

      {currentQ.kind === 'true_false' && (
        <QuizTrueFalseView
          key={currentQ.id}
          question={currentQ}
          answered={answered}
          onAnswer={handleRecordAnswer}
        />
      )}

      {currentQ.kind === 'image_choice' && (
        <QuizImageChoiceView
          key={currentQ.id}
          question={currentQ}
          answered={answered}
          onAnswer={handleRecordAnswer}
        />
      )}

      {currentQ.kind === 'order_mini' && (
        <QuizOrderMiniView
          key={currentQ.id}
          question={currentQ}
          answered={answered}
          onAnswer={handleRecordAnswer}
        />
      )}

      {currentQ.kind === 'match_mini' && (
        <QuizMatchMiniView
          key={currentQ.id}
          question={currentQ}
          answered={answered}
          onAnswer={handleRecordAnswer}
        />
      )}

      {answered && (
        <div
          className={`rounded-3xl p-5 space-y-4 border-2 ${
            wasCorrect
              ? 'bg-emerald-50 border-emerald-400 text-emerald-950'
              : 'bg-amber-50 border-amber-400 text-amber-950'
          }`}
        >
          <div className="flex items-center gap-3">
            <CharacterAvatar
              character={wasCorrect ? 'noor' : 'adam'}
              size="md"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 font-extrabold text-xl">
                <CheckCircle2
                  className={`w-6 h-6 shrink-0 ${
                    wasCorrect ? 'text-emerald-600' : 'text-amber-600'
                  }`}
                />
                <span>{wasCorrect ? 'برافو عليك!' : 'قربت يا بطل!'}</span>
              </div>
              <p className="font-bold text-base md:text-lg mt-1">
                {currentQ.explanation}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleNext}
            className="btn-3d w-full sm:w-auto min-h-[56px] inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_4px_0_#047857] cursor-pointer"
          >
            <span>
              {qIdx + 1 < questions.length
                ? 'السؤال اللي بعده'
                : 'شوف النتيجة'}
            </span>
            <ArrowLeft className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
};

const QuizMcqView: React.FC<{
  question: Extract<QuizQuestion, { kind: 'mcq' }>;
  answered: boolean;
  onAnswer: (correct: boolean) => void;
}> = ({ question, answered, onAnswer }) => {
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="space-y-5">
      {question.visual && (
        <ActivityThumbnail
          visualKey={question.visual}
          className="w-full max-w-sm h-44 mx-auto"
        />
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {question.options.map((opt, idx) => {
          const isCorrect = idx === question.correctIndex;
          const isPicked = picked === idx;
          return (
            <button
              key={opt}
              type="button"
              disabled={answered}
              onClick={() => {
                setPicked(idx);
                onAnswer(isCorrect);
              }}
              className={`min-h-[72px] p-4 rounded-2xl border-3 text-center font-extrabold text-xl transition-all cursor-pointer ${
                answered && isCorrect
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-950'
                  : answered && isPicked && !isCorrect
                  ? 'border-rose-400 bg-rose-50 text-rose-950'
                  : 'border-slate-200 bg-slate-50/70 hover:border-sky-500 hover:bg-sky-50 text-slate-900'
              }`}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
};

const QuizTrueFalseView: React.FC<{
  question: Extract<QuizQuestion, { kind: 'true_false' }>;
  answered: boolean;
  onAnswer: (correct: boolean) => void;
}> = ({ question, answered, onAnswer }) => {
  const [picked, setPicked] = useState<boolean | null>(null);
  return (
    <div className="space-y-5">
      {question.visual && (
        <ActivityThumbnail
          visualKey={question.visual}
          className="w-full max-w-sm h-48 mx-auto"
        />
      )}
      <div className="flex flex-wrap gap-4 max-w-lg mx-auto">
        {[
          { val: true, label: 'صح ✓' },
          { val: false, label: 'غلط ✕' },
        ].map((btn) => {
          const isCorrect = btn.val === question.correctAnswer;
          const isPicked = picked === btn.val;
          return (
            <button
              key={String(btn.val)}
              type="button"
              disabled={answered}
              onClick={() => {
                setPicked(btn.val);
                onAnswer(isCorrect);
              }}
              className={`flex-1 min-w-[140px] min-h-[72px] py-4 px-6 rounded-2xl border-3 font-extrabold text-2xl cursor-pointer ${
                answered && isCorrect
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-900'
                  : answered && isPicked
                  ? 'border-rose-400 bg-rose-50 text-rose-900'
                  : 'border-slate-200 bg-slate-50 hover:border-sky-500 text-slate-900'
              }`}
            >
              {btn.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};

const QuizImageChoiceView: React.FC<{
  question: Extract<QuizQuestion, { kind: 'image_choice' }>;
  answered: boolean;
  onAnswer: (correct: boolean) => void;
}> = ({ question, answered, onAnswer }) => {
  const [picked, setPicked] = useState<string | null>(null);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {question.options.map((opt) => (
        <button
          key={opt.id}
          type="button"
          disabled={answered}
          onClick={() => {
            setPicked(opt.id);
            onAnswer(opt.isCorrect);
          }}
          className={`p-4 rounded-3xl border-3 text-center space-y-3 cursor-pointer ${
            answered && opt.isCorrect
              ? 'border-emerald-500 bg-emerald-50'
              : answered && picked === opt.id
              ? 'border-rose-400 bg-rose-50'
              : 'border-slate-200 bg-white hover:border-sky-400'
          }`}
        >
          <ActivityThumbnail visualKey={opt.visual} className="w-full h-36" />
          <span className="block font-extrabold text-slate-900 text-xl">
            {opt.label}
          </span>
        </button>
      ))}
    </div>
  );
};

const QuizOrderMiniView: React.FC<{
  question: Extract<QuizQuestion, { kind: 'order_mini' }>;
  answered: boolean;
  onAnswer: (correct: boolean) => void;
}> = ({ question, answered, onAnswer }) => {
  const [items, setItems] = useState(() => [...question.items].reverse());

  const move = (from: number, to: number) => {
    if (answered || to < 0 || to >= items.length) return;
    audioEngine.playClick();
    const copy = [...items];
    const [r] = copy.splice(from, 1);
    copy.splice(to, 0, r);
    setItems(copy);
  };

  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <React.Fragment key={item.id}>
          <div className="flex items-center justify-between gap-3 rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3">
            <div className="flex items-center gap-3 min-w-0">
              <span className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-extrabold text-lg flex items-center justify-center shrink-0 tabular-nums">
                {idx + 1}
              </span>
              {item.visual && (
                <ActivityThumbnail
                  visualKey={item.visual}
                  className="w-20 h-16 shrink-0"
                />
              )}
              <span className="font-extrabold text-lg text-slate-900">
                {item.label}
              </span>
            </div>
            {!answered && (
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => move(idx, idx - 1)}
                  disabled={idx === 0}
                  className="w-11 h-11 rounded-xl bg-white border-2 border-slate-200 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  aria-label="أعلى"
                >
                  <ArrowUp className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={() => move(idx, idx + 1)}
                  disabled={idx === items.length - 1}
                  className="w-11 h-11 rounded-xl bg-white border-2 border-slate-200 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  aria-label="أسفل"
                >
                  <ArrowDown className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
          {idx < items.length - 1 && (
            <div className="flex justify-center" aria-hidden="true">
              <ArrowDown className="w-5 h-5 text-emerald-500" />
            </div>
          )}
        </React.Fragment>
      ))}
      {!answered && (
        <button
          type="button"
          onClick={() =>
            onAnswer(items.every((it, idx) => it.correctIndex === idx))
          }
          className="btn-3d w-full sm:w-auto min-h-[56px] px-8 py-3.5 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xl cursor-pointer"
        >
          تأكيد الإجابة
        </button>
      )}
    </div>
  );
};

// Tap-to-match cards instead of <select> dropdown for easy accessible tapping
const QuizMatchMiniView: React.FC<{
  question: Extract<QuizQuestion, { kind: 'match_mini' }>;
  answered: boolean;
  onAnswer: (correct: boolean) => void;
}> = ({ question, answered, onAnswer }) => {
  const rightOptions = useMemo(
    () =>
      [...question.pairs]
        .map((p) => p.right)
        .sort((a, b) => a.localeCompare(b, 'ar')),
    [question.pairs]
  );

  const [activePairId, setActivePairId] = useState<string | null>(
    question.pairs[0]?.id ?? null
  );
  const [selections, setSelections] = useState<Record<string, string>>({});

  const allSelected = question.pairs.every((p) => Boolean(selections[p.id]));

  const handleAssignRight = (rightText: string) => {
    if (answered || !activePairId) return;
    audioEngine.playClick();
    const next = { ...selections, [activePairId]: rightText };
    setSelections(next);
    // Advance selection automatically to next unpaired item if any
    const nextUnpaired = question.pairs.find((p) => !next[p.id]);
    if (nextUnpaired) {
      setActivePairId(nextUnpaired.id);
    }
  };

  return (
    <div className="space-y-4">
      {!answered && (
        <div className="rounded-2xl bg-sky-50 border border-sky-200 px-4 py-2.5 text-center font-extrabold text-sky-950 text-base">
          اضغط على الصورة في اليمين، وبعدين اضغط على الإجابة بتاعتها في الشمال
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2.5">
          {question.pairs.map((pair) => {
            const isSelected = activePairId === pair.id && !answered;
            const chosenRight = selections[pair.id];
            const isCorrect = chosenRight === pair.right;
            return (
              <button
                key={pair.id}
                type="button"
                disabled={answered}
                onClick={() => {
                  audioEngine.playClick();
                  setActivePairId(pair.id);
                }}
                className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border-3 text-right transition-all cursor-pointer ${
                  answered
                    ? isCorrect
                      ? 'border-emerald-500 bg-emerald-50'
                      : 'border-rose-400 bg-rose-50'
                    : isSelected
                    ? 'border-sky-500 bg-sky-50 ring-4 ring-sky-200'
                    : chosenRight
                    ? 'border-emerald-300 bg-emerald-50/40'
                    : 'border-slate-200 bg-white hover:border-sky-400'
                }`}
              >
                {pair.leftVisual && (
                  <ActivityThumbnail
                    visualKey={pair.leftVisual}
                    className="w-20 h-16 shrink-0"
                  />
                )}
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold text-lg text-slate-900">
                    {pair.left}
                  </p>
                  {chosenRight && (
                    <p className="text-sm font-extrabold text-emerald-700 mt-1">
                      ← {chosenRight}
                    </p>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        <div className="space-y-2.5">
          {rightOptions.map((r, idx) => (
            <button
              key={`${r}_${idx}`}
              type="button"
              disabled={answered || !activePairId}
              onClick={() => handleAssignRight(r)}
              className="w-full min-h-[72px] p-4 rounded-2xl border-3 border-amber-300 bg-amber-50/60 hover:bg-amber-100 hover:border-amber-500 disabled:opacity-60 font-extrabold text-lg text-slate-900 text-right cursor-pointer transition-colors"
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {!answered && (
        <button
          type="button"
          disabled={!allSelected}
          onClick={() =>
            onAnswer(question.pairs.every((p) => selections[p.id] === p.right))
          }
          className="btn-3d w-full sm:w-auto min-h-[56px] px-8 py-3.5 rounded-2xl bg-sky-600 hover:bg-sky-700 disabled:opacity-45 text-white font-extrabold text-xl cursor-pointer"
        >
          تأكيد التوصيل
        </button>
      )}
    </div>
  );
};
