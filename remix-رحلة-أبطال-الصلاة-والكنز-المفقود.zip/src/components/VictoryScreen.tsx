import React, { useEffect } from 'react';
import { Award, Star, RotateCcw, Map } from 'lucide-react';
import { GAME_IMAGES } from '../data/assets';
import { LEVELS } from '../data/gameContent';
import { PlayerProgress } from '../types/game';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { audioEngine } from '../utils/audioEngine';

interface VictoryScreenProps {
  progress: PlayerProgress;
  onRestartJourney: () => void;
  onBackToMap: () => void;
}

export const VictoryScreen: React.FC<VictoryScreenProps> = ({
  progress,
  onRestartJourney,
  onBackToMap,
}) => {
  useEffect(() => {
    audioEngine.playBadgeFanfare();
    audioEngine.prefetchTrack('victory_full');
    void audioEngine.playTrack('victory_full', 'adam', 'victory_full');
    return () => {
      audioEngine.stopSpeech();
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 via-[#FAF8F2] to-emerald-50 py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Open Treasure Chest Celebration */}
        <div className="rounded-3xl bg-white border-4 border-amber-400 p-5 md:p-7 shadow-xl space-y-5">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <CharacterAvatar character="adam" size="lg" />
              <CharacterAvatar character="noor" size="lg" />
            </div>
            <SpeakerButton
              trackId="victory_full"
              speaker="adam"
              label="اسمع"
              variant="amber"
            />
          </div>

          <div className="relative rounded-3xl overflow-hidden border-2 border-amber-300 h-64 sm:h-80">
            <img
              src={GAME_IMAGES.treasureCelebration}
              alt="صندوق الكنز المفتوح"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="rounded-2xl bg-amber-50 border-2 border-amber-300 p-5 text-center">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              برافو عليك يا بطل! الكنز هو نور الصلاة!
            </h1>
          </div>

          {/* Stars & Badges Count */}
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="rounded-2xl bg-amber-50 border-2 border-amber-200 p-4">
              <p className="text-sm font-bold text-slate-600">النجوم</p>
              <p className="text-3xl font-extrabold text-amber-600 tabular-nums flex items-center justify-center gap-2">
                <Star className="w-7 h-7 fill-amber-400" />
                <span>{progress.stars}</span>
              </p>
            </div>
            <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-200 p-4">
              <p className="text-sm font-bold text-slate-600">الشارات</p>
              <p className="text-3xl font-extrabold text-emerald-700 tabular-nums">
                {progress.earnedBadges.length} / 7
              </p>
            </div>
          </div>

          {/* All 7 Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {LEVELS.map((lvl) => (
              <div
                key={lvl.badge.id}
                className="rounded-2xl bg-amber-50 border-2 border-amber-300 p-3 text-center space-y-2"
              >
                <div
                  className={`w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br ${lvl.badge.colorClass} text-white flex items-center justify-center`}
                >
                  <Award className="w-7 h-7" />
                </div>
                <p className="text-xs font-extrabold text-slate-900">
                  {lvl.badge.title}
                </p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => {
                audioEngine.playClick();
                onBackToMap();
              }}
              className="btn-3d inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
            >
              <Map className="w-6 h-6" />
              <span>خريطة الرحلة</span>
            </button>

            <button
              type="button"
              onClick={() => {
                audioEngine.playClick();
                onRestartJourney();
              }}
              className="btn-3d inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xl shadow-[0_5px_0_#B45309] cursor-pointer"
            >
              <RotateCcw className="w-6 h-6" />
              <span>العب تاني</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
