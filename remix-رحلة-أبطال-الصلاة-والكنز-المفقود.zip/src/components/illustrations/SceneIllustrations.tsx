import React from 'react';
import { PrayerPoseId, TimeVisualId, WuduStepId } from '../../types/game';
import { WuduStepIllustration } from './WuduStepIllustration';
import { PrayerPostureIllustration } from './PrayerPostureIllustration';
import { GAME_IMAGES } from '../../data/assets';

export const TimeOfDayVisual: React.FC<{
  timeId: TimeVisualId;
  className?: string;
}> = ({ timeId, className = 'w-full h-36' }) => {
  const configs: Record<
    TimeVisualId,
    { sky: string; sunOrMoon: React.ReactNode; label: string }
  > = {
    fajr: {
      sky: 'from-indigo-900 via-sky-700 to-amber-300',
      label: 'بداية الفجر',
      sunOrMoon: (
        <>
          <circle cx="70" cy="84" r="18" fill="#FDE68A" opacity="0.95" />
          <path d="M25 22 A10 10 0 1 0 36 33 A8 8 0 1 1 25 22 Z" fill="#FEF3C7" />
        </>
      ),
    },
    dhuhr: {
      sky: 'from-sky-400 via-sky-300 to-cyan-100',
      label: 'وقت الظهر',
      sunOrMoon: (
        <g>
          <circle cx="70" cy="28" r="18" fill="#FACC15" />
          <circle cx="70" cy="28" r="25" fill="#FDE047" opacity="0.35" />
        </g>
      ),
    },
    asr: {
      sky: 'from-amber-400 via-orange-300 to-sky-300',
      label: 'وقت العصر',
      sunOrMoon: (
        <g>
          <circle cx="105" cy="44" r="16" fill="#F59E0B" />
          <circle cx="105" cy="44" r="23" fill="#FBBF24" opacity="0.3" />
        </g>
      ),
    },
    maghrib: {
      sky: 'from-violet-900 via-rose-500 to-amber-400',
      label: 'وقت الغروب',
      sunOrMoon: (
        <g>
          <path d="M52 88 A18 18 0 0 1 88 88 Z" fill="#FB923C" />
        </g>
      ),
    },
    isha: {
      sky: 'from-slate-950 via-indigo-950 to-violet-900',
      label: 'وقت الليل',
      sunOrMoon: (
        <g>
          <path d="M98 20 A14 14 0 1 0 112 36 A11 11 0 1 1 98 20 Z" fill="#FDE68A" />
          <circle cx="34" cy="26" r="2.5" fill="#FFFFFF" />
          <circle cx="58" cy="18" r="3" fill="#FEF08A" />
          <circle cx="118" cy="46" r="2" fill="#FFFFFF" />
        </g>
      ),
    },
  };

  const cfg = configs[timeId];

  return (
    <div
      className={`relative rounded-2xl bg-gradient-to-b ${cfg.sky} overflow-hidden border-2 border-white/50 shadow-inner ${className}`}
    >
      <svg viewBox="0 0 140 100" className="w-full h-full" aria-hidden="true">
        {cfg.sunOrMoon}
        <path
          d="M0 90 L30 90 L30 72 Q42 60 54 72 L54 90 L85 90 L85 68 Q100 50 115 68 L115 90 L140 90 L140 100 L0 100 Z"
          fill="#0F172A"
          fillOpacity="0.45"
        />
        <rect x="19" y="54" width="6" height="36" fill="#0F172A" fillOpacity="0.45" />
      </svg>
    </div>
  );
};

const WUDU_KEYS: WuduStepId[] = [
  'niyyah',
  'hands',
  'mouth',
  'nose',
  'face',
  'right_arm',
  'left_arm',
  'head',
  'ears',
  'right_foot',
  'left_foot',
];

const POSE_KEYS: PrayerPoseId[] = [
  'takbeer',
  'qiyam',
  'ruku',
  'itidal',
  'sujood',
  'juloos',
  'tashahhud',
  'tasleem',
];

export const ActivityThumbnail: React.FC<{
  visualKey: string;
  className?: string;
}> = ({ visualKey, className = 'w-full h-32' }) => {
  if (
    visualKey === 'fajr' ||
    visualKey === 'dhuhr' ||
    visualKey === 'asr' ||
    visualKey === 'maghrib' ||
    visualKey === 'isha'
  ) {
    return <TimeOfDayVisual timeId={visualKey} className={className} />;
  }

  if (visualKey.startsWith('wudu_')) {
    const step = visualKey.replace('wudu_', '') as WuduStepId;
    if (WUDU_KEYS.includes(step)) {
      return <WuduStepIllustration stepId={step} compact className={className} />;
    }
  }

  if (visualKey.startsWith('pose_')) {
    const pose = visualKey.replace('pose_', '') as PrayerPoseId;
    if (POSE_KEYS.includes(pose)) {
      return <PrayerPostureIllustration poseId={pose} compact className={className} />;
    }
  }

  if (visualKey === 'kaaba') {
    return (
      <div className={`rounded-2xl overflow-hidden border-2 border-amber-200 ${className}`}>
        <img
          src={GAME_IMAGES.lessonQiblahKaaba}
          alt="استقبال القبلة"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  if (visualKey === 'taharah') {
    return (
      <div className={`rounded-2xl overflow-hidden border-2 border-sky-200 ${className}`}>
        <img
          src={GAME_IMAGES.lessonWuduHands}
          alt="الطهارة والوضوء"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  if (visualKey === 'prayer_scene') {
    return (
      <div className={`rounded-2xl overflow-hidden border-2 border-emerald-200 ${className}`}>
        <img
          src={GAME_IMAGES.lessonPrayerMeaning}
          alt="الصلاة"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  const icons: Record<string, { bg: string; svg: React.ReactNode }> = {
    prayer_rug: {
      bg: 'from-emerald-100 to-teal-50 border-emerald-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <rect x="25" y="10" width="70" height="70" rx="10" fill="#059669" />
          <rect x="33" y="18" width="54" height="54" rx="5" fill="none" stroke="#FDE68A" strokeWidth="2.5" />
          <path d="M44 58 L44 36 Q60 22 76 36 L76 58 Z" fill="#10B981" stroke="#FDE68A" strokeWidth="2" />
        </svg>
      ),
    },
    soccer: {
      bg: 'from-sky-100 to-amber-50 border-sky-200',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="28" fill="#FFFFFF" stroke="#334155" strokeWidth="3" />
          <polygon points="60,30 72,39 67,54 53,54 48,39" fill="#1E293B" />
        </svg>
      ),
    },
    meal: {
      bg: 'from-amber-100 to-orange-50 border-amber-200',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="46" r="27" fill="#FFFFFF" stroke="#D97706" strokeWidth="3.5" />
          <circle cx="60" cy="46" r="15" fill="#FDE68A" />
        </svg>
      ),
    },
    sleep: {
      bg: 'from-indigo-100 to-violet-50 border-indigo-200',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <rect x="20" y="42" width="80" height="24" rx="7" fill="#6366F1" />
          <rect x="24" y="34" width="24" height="12" rx="5" fill="#FFFFFF" />
          <path d="M84 18 A10 10 0 1 0 94 28 A8 8 0 1 1 84 18 Z" fill="#F59E0B" />
        </svg>
      ),
    },
    clothes: {
      bg: 'from-emerald-50 to-sky-50 border-emerald-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <path d="M40 20 L24 32 L32 42 L42 35 L42 74 L78 74 L78 35 L88 42 L96 32 L80 20 L68 25 Q60 30 52 25 Z" fill="#FFFFFF" stroke="#059669" strokeWidth="3" />
          <circle cx="60" cy="48" r="7" fill="#F59E0B" opacity="0.25" />
        </svg>
      ),
    },
    five_count: {
      bg: 'from-emerald-100 to-amber-50 border-emerald-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="30" fill="#059669" />
          <text x="60" y="57" textAnchor="middle" fill="#FFFFFF" fontSize="34" fontWeight="800">٥</text>
        </svg>
      ),
    },
    count_1: {
      bg: 'from-sky-100 to-cyan-50 border-sky-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="28" fill="#0284C7" />
          <text x="60" y="56" textAnchor="middle" fill="#FFFFFF" fontSize="32" fontWeight="800">١</text>
        </svg>
      ),
    },
    count_2: {
      bg: 'from-sky-100 to-indigo-50 border-sky-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="28" fill="#4F46E5" />
          <text x="60" y="56" textAnchor="middle" fill="#FFFFFF" fontSize="32" fontWeight="800">٢</text>
        </svg>
      ),
    },
    count_3: {
      bg: 'from-violet-100 to-purple-50 border-violet-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="28" fill="#7C3AED" />
          <text x="60" y="56" textAnchor="middle" fill="#FFFFFF" fontSize="32" fontWeight="800">٣</text>
        </svg>
      ),
    },
    count_4: {
      bg: 'from-amber-100 to-orange-50 border-amber-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="28" fill="#D97706" />
          <text x="60" y="56" textAnchor="middle" fill="#FFFFFF" fontSize="32" fontWeight="800">٤</text>
        </svg>
      ),
    },
    fatiha_surah: {
      bg: 'from-emerald-100 to-amber-50 border-emerald-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <rect x="22" y="20" width="46" height="50" rx="6" fill="#FFFFFF" stroke="#059669" strokeWidth="3" />
          <line x1="45" y1="20" x2="45" y2="70" stroke="#059669" strokeWidth="2.5" />
          <polygon points="88,24 94,38 109,38 97,47 101,62 88,53 75,62 79,47 67,38 82,38" fill="#F59E0B" />
        </svg>
      ),
    },
    fatiha_only: {
      bg: 'from-sky-100 to-emerald-50 border-sky-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <rect x="36" y="20" width="48" height="50" rx="6" fill="#FFFFFF" stroke="#0284C7" strokeWidth="3" />
          <line x1="60" y1="20" x2="60" y2="70" stroke="#0284C7" strokeWidth="2.5" />
        </svg>
      ),
    },
    loud_voice: {
      bg: 'from-amber-100 to-yellow-50 border-amber-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <polygon points="32,36 48,36 68,20 68,70 48,54 32,54" fill="#D97706" />
          <path d="M78 34 Q88 45 78 56" fill="none" stroke="#D97706" strokeWidth="4" strokeLinecap="round" />
          <path d="M88 26 Q102 45 88 64" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
        </svg>
      ),
    },
    quiet_voice: {
      bg: 'from-sky-100 to-slate-50 border-sky-300',
      svg: (
        <svg viewBox="0 0 120 90" className="w-28 h-24">
          <circle cx="60" cy="45" r="26" fill="#0284C7" opacity="0.18" />
          <rect x="53" y="26" width="14" height="38" rx="7" fill="#0284C7" />
          <path d="M40 44 Q60 58 80 44" fill="none" stroke="#0284C7" strokeWidth="3" strokeLinecap="round" />
        </svg>
      ),
    },
  };

  const entry = icons[visualKey] || icons.prayer_rug;

  return (
    <div
      className={`flex items-center justify-center rounded-2xl bg-gradient-to-br border-2 ${entry.bg} ${className}`}
    >
      {entry.svg}
    </div>
  );
};
