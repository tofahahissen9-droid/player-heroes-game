import React from 'react';
import { PrayerPoseId } from '../../types/game';

interface PrayerPostureIllustrationProps {
  poseId: PrayerPoseId;
  className?: string;
  stepNumber?: number;
  dhikrPhrase?: string;
  compact?: boolean;
}

export const PrayerPostureIllustration: React.FC<
  PrayerPostureIllustrationProps
> = ({
  poseId,
  className = 'w-full h-72',
  stepNumber,
  dhikrPhrase,
  compact = false,
}) => {
  return (
    <div
      className={`relative flex flex-col items-center justify-center rounded-3xl bg-gradient-to-b from-amber-50 via-emerald-50/50 to-emerald-100/70 border-2 border-emerald-200 overflow-hidden shadow-inner ${
        compact ? 'p-2' : 'p-4'
      } ${className}`}
    >
      {/* Step Number Circle (Top Right in RTL) */}
      {!compact && stepNumber !== undefined && (
        <div className="absolute top-3 right-3 z-10 w-12 h-12 rounded-2xl bg-emerald-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-md border-2 border-white tabular-nums">
          {stepNumber}
        </div>
      )}

      {/* Optional Short Dhikr Speech Bubble */}
      {!compact && dhikrPhrase && (
        <div className="relative z-10 mb-1 rounded-2xl bg-white/95 border-2 border-amber-300 px-4 py-1.5 shadow-sm max-w-[92%] text-center">
          <p className="font-quran text-lg sm:text-xl font-bold text-emerald-900 leading-snug">
            «{dhikrPhrase}»
          </p>
        </div>
      )}

      <svg
        viewBox="0 0 280 220"
        className="w-full h-full max-w-[300px]"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="rugGrad3d" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#047857" />
            <stop offset="50%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="robeGrad3d" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="65%" stopColor="#F5EFE0" />
            <stop offset="100%" stopColor="#DDD3BA" />
          </linearGradient>
          <linearGradient id="poseSkin3d" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#F8D2B4" />
            <stop offset="100%" stopColor="#E1A376" />
          </linearGradient>
        </defs>

        {/* Prayer rug (Sajjadah) */}
        <polygon
          points="28,198 252,198 230,174 50,174"
          fill="url(#rugGrad3d)"
          stroke="#F59E0B"
          strokeWidth="2.5"
        />
        <polygon
          points="50,193 230,193 214,178 66,178"
          fill="none"
          stroke="#FDE68A"
          strokeWidth="1.4"
          strokeDasharray="5 3"
        />

        {/* TAKBEER */}
        {poseId === 'takbeer' && (
          <g>
            <rect x="122" y="136" width="12" height="46" rx="5" fill="#CBD5E1" />
            <rect x="146" y="136" width="12" height="46" rx="5" fill="#CBD5E1" />
            <path d="M112 78 Q140 72 168 78 L174 146 L106 146 Z" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <g className="animate-nudge-y">
              <path d="M112 82 L86 76 L86 52" fill="none" stroke="url(#robeGrad3d)" strokeWidth="15" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M168 82 L194 76 L194 52" fill="none" stroke="url(#robeGrad3d)" strokeWidth="15" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="86" cy="48" r="8.5" fill="url(#poseSkin3d)" />
              <circle cx="194" cy="48" r="8.5" fill="url(#poseSkin3d)" />
            </g>
            {/* Upward movement arrows */}
            <path d="M62 84 L62 46 M56 54 L62 44 L68 54" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
            <path d="M218 84 L218 46 M212 54 L218 44 L224 54" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />

            <circle cx="140" cy="52" r="21" fill="url(#poseSkin3d)" />
            <path d="M119 42 C119 24 161 24 161 42 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="133" cy="52" r="2.5" fill="#1E293B" />
            <circle cx="147" cy="52" r="2.5" fill="#1E293B" />
            <path d="M134 61 Q140 65 146 61" fill="none" stroke="#9A3412" strokeWidth="2" strokeLinecap="round" />
          </g>
        )}

        {/* QIYAM / ITIDAL */}
        {(poseId === 'qiyam' || poseId === 'itidal') && (
          <g>
            <rect x="122" y="136" width="12" height="46" rx="5" fill="#CBD5E1" />
            <rect x="146" y="136" width="12" height="46" rx="5" fill="#CBD5E1" />
            <path d="M112 78 Q140 72 168 78 L174 146 L106 146 Z" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            {poseId === 'qiyam' ? (
              <g>
                <path d="M112 84 L126 108 L154 106 L168 84" fill="none" stroke="url(#robeGrad3d)" strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" />
                <ellipse cx="140" cy="107" rx="15" ry="8" fill="url(#poseSkin3d)" />
                {/* Book icon indicating recitation */}
                <rect x="196" y="64" width="34" height="28" rx="5" fill="#FFFFFF" stroke="#059669" strokeWidth="2.5" />
                <line x1="213" y1="64" x2="213" y2="92" stroke="#059669" strokeWidth="2" />
              </g>
            ) : (
              <g>
                <path d="M110 82 L98 134" stroke="url(#robeGrad3d)" strokeWidth="14" strokeLinecap="round" />
                <path d="M170 82 L182 134" stroke="url(#robeGrad3d)" strokeWidth="14" strokeLinecap="round" />
                <circle cx="97" cy="138" r="7.5" fill="url(#poseSkin3d)" />
                <circle cx="183" cy="138" r="7.5" fill="url(#poseSkin3d)" />
                {/* Up arrow showing standing straight after Ruku */}
                <path d="M70 118 L70 62 M63 72 L70 60 L77 72" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
              </g>
            )}
            <circle cx="140" cy="52" r="21" fill="url(#poseSkin3d)" />
            <path d="M119 42 C119 24 161 24 161 42 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="133" cy="52" r="2.5" fill="#1E293B" />
            <circle cx="147" cy="52" r="2.5" fill="#1E293B" />
          </g>
        )}

        {/* RUKU */}
        {poseId === 'ruku' && (
          <g>
            <rect x="174" y="106" width="18" height="78" rx="7" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <rect x="102" y="88" width="88" height="34" rx="15" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <path d="M122 108 L158 140 L176 140" fill="none" stroke="url(#robeGrad3d)" strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="176" cy="140" r="7.5" fill="url(#poseSkin3d)" />
            <circle cx="86" cy="101" r="19" fill="url(#poseSkin3d)" />
            <path d="M68 96 C68 80 100 80 100 96 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="80" cy="102" r="2.4" fill="#1E293B" />
            {/* Straight back guide + downward bow arrow */}
            <line x1="82" y1="74" x2="190" y2="74" stroke="#F59E0B" strokeWidth="2.5" strokeDasharray="5 4" />
            <path d="M72 44 Q52 62 56 88 M50 80 L56 90 L63 82" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
          </g>
        )}

        {/* SUJOOD */}
        {poseId === 'sujood' && (
          <g>
            <ellipse cx="214" cy="180" rx="11" ry="6.5" fill="url(#poseSkin3d)" />
            <path d="M168 178 L212 180" stroke="url(#robeGrad3d)" strokeWidth="19" strokeLinecap="round" />
            <path d="M170 176 Q178 134 148 128 Q112 126 96 164 L118 178 Z" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <path d="M114 146 L94 176" stroke="url(#robeGrad3d)" strokeWidth="13" strokeLinecap="round" />
            <ellipse cx="88" cy="181" rx="12" ry="5.5" fill="url(#poseSkin3d)" />
            <circle cx="76" cy="166" r="18" fill="url(#poseSkin3d)" />
            <path d="M60 158 C66 144 92 146 92 162 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            {/* Contact glow + downward arrow */}
            <circle cx="67" cy="180" r="10" fill="#F59E0B" fillOpacity="0.45" className="animate-pulse-soft" />
            <path d="M76 106 L76 134 M70 126 L76 136 L82 126" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
          </g>
        )}

        {/* JULOOS / TASHAHHUD */}
        {(poseId === 'juloos' || poseId === 'tashahhud') && (
          <g>
            <path d="M132 178 L196 178" stroke="url(#robeGrad3d)" strokeWidth="21" strokeLinecap="round" />
            <path d="M124 84 Q146 78 168 86 L178 172 L118 172 Z" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <path d="M132 96 L118 138 L92 146" fill="none" stroke="url(#robeGrad3d)" strokeWidth="13" strokeLinecap="round" strokeLinejoin="round" />
            {poseId === 'tashahhud' ? (
              <g>
                <circle cx="90" cy="146" r="7.5" fill="url(#poseSkin3d)" />
                <line x1="88" y1="144" x2="70" y2="134" stroke="url(#poseSkin3d)" strokeWidth="5" strokeLinecap="round" />
                <circle cx="70" cy="134" r="9" fill="none" stroke="#F59E0B" strokeWidth="2.5" className="animate-pulse-soft" />
              </g>
            ) : (
              <circle cx="90" cy="146" r="7.5" fill="url(#poseSkin3d)" />
            )}
            <circle cx="146" cy="58" r="20" fill="url(#poseSkin3d)" />
            <path d="M126 48 C126 30 166 30 166 48 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="136" cy="58" r="2.4" fill="#1E293B" />
          </g>
        )}

        {/* TASLEEM */}
        {poseId === 'tasleem' && (
          <g>
            <path d="M108 176 L172 176" stroke="url(#robeGrad3d)" strokeWidth="21" strokeLinecap="round" />
            <path d="M112 86 Q140 80 168 86 L176 172 L104 172 Z" fill="url(#robeGrad3d)" stroke="#059669" strokeWidth="2.2" />
            <path d="M112 90 L100 140" stroke="url(#robeGrad3d)" strokeWidth="13" strokeLinecap="round" />
            <path d="M168 90 L180 140" stroke="url(#robeGrad3d)" strokeWidth="13" strokeLinecap="round" />
            <circle cx="100" cy="144" r="7.5" fill="url(#poseSkin3d)" />
            <circle cx="180" cy="144" r="7.5" fill="url(#poseSkin3d)" />
            <circle cx="140" cy="58" r="21" fill="url(#poseSkin3d)" />
            <path d="M119 48 C119 30 161 30 161 48 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="133" cy="58" r="2.4" fill="#1E293B" />
            <circle cx="147" cy="58" r="2.4" fill="#1E293B" />
            {/* Animated right & left turn arrows with numbers 1 and 2 */}
            <g className="animate-nudge-x">
              <path d="M214 58 L184 58 M206 50 L216 58 L206 66" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="228" cy="40" r="11" fill="#059669" />
              <text x="228" y="45" textAnchor="middle" fill="#FFFFFF" fontSize="13" fontWeight="800">١</text>
            </g>
            <g className="animate-nudge-x">
              <path d="M66 58 L96 58 M74 50 L64 58 L74 66" fill="none" stroke="#0284C7" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="52" cy="40" r="11" fill="#0284C7" />
              <text x="52" y="45" textAnchor="middle" fill="#FFFFFF" fontSize="13" fontWeight="800">٢</text>
            </g>
          </g>
        )}
      </svg>
    </div>
  );
};
