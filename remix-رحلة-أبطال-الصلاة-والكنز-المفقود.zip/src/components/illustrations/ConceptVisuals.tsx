import React from 'react';
import {
  Volume2,
  VolumeX,
  Star,
  Heart,
  Sparkles,
  BookOpen,
  ArrowLeft,
  CheckCircle2,
} from 'lucide-react';
import { LessonCard, TimeVisualId } from '../../types/game';
import { GAME_IMAGES } from '../../data/assets';
import { WuduStepIllustration } from './WuduStepIllustration';
import { PrayerPostureIllustration } from './PrayerPostureIllustration';
import { TimeOfDayVisual } from './SceneIllustrations';

const FIVE_PRAYERS_VISUAL: {
  id: TimeVisualId;
  num: string;
  name: string;
  rakaat: string;
}[] = [
  { id: 'fajr', num: '١', name: 'الفجر', rakaat: '٢ ركعة' },
  { id: 'dhuhr', num: '٢', name: 'الظهر', rakaat: '٤ ركعات' },
  { id: 'asr', num: '٣', name: 'العصر', rakaat: '٤ ركعات' },
  { id: 'maghrib', num: '٤', name: 'المغرب', rakaat: '٣ ركعات' },
  { id: 'isha', num: '٥', name: 'العشاء', rakaat: '٤ ركعات' },
];

export const LessonVisualStage: React.FC<{ lesson: LessonCard }> = ({
  lesson,
}) => {
  switch (lesson.visualType) {
    case 'prayer_meaning':
      return (
        <div className="relative rounded-3xl overflow-hidden border-4 border-emerald-200 shadow-lg bg-emerald-50 h-72 sm:h-88">
          <img
            src={GAME_IMAGES.lessonPrayerMeaning}
            alt="آدم يصلي بخشوع على السجادة"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 bg-white/95 rounded-2xl px-4 py-2 border-2 border-amber-300 shadow-md flex items-center gap-2 animate-float-slow">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
            <Sparkles className="w-6 h-6 text-amber-500" />
          </div>
        </div>
      );

    case 'five_prayers':
      return (
        <div className="rounded-3xl bg-gradient-to-br from-sky-50 via-white to-emerald-50 border-2 border-emerald-200 p-4 sm:p-5 shadow-inner">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {FIVE_PRAYERS_VISUAL.map((p, idx) => (
              <div
                key={p.id}
                className="relative rounded-2xl bg-white border-2 border-slate-200 p-2.5 flex flex-col items-center gap-2 shadow-xs"
              >
                <span className="w-8 h-8 rounded-full bg-emerald-600 text-white font-extrabold text-base flex items-center justify-center tabular-nums">
                  {p.num}
                </span>
                <TimeOfDayVisual timeId={p.id} className="w-full h-24" />
                <p className="font-extrabold text-slate-900 text-lg">{p.name}</p>
                <span className="text-sm font-extrabold text-emerald-700 bg-emerald-50 rounded-xl px-2.5 py-0.5 tabular-nums">
                  {p.rakaat}
                </span>
                {idx < 4 && (
                  <ArrowLeft className="hidden sm:block absolute -left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-500 z-10 bg-white rounded-full" />
                )}
              </div>
            ))}
          </div>
        </div>
      );

    case 'prayer_time_single': {
      const timeId = lesson.visualData?.timeId || 'fajr';
      return (
        <div className="relative rounded-3xl overflow-hidden border-4 border-sky-200 shadow-lg h-72 sm:h-88 bg-slate-900">
          <TimeOfDayVisual timeId={timeId} className="w-full h-full rounded-none border-0" />
          {lesson.stepNumber && (
            <div className="absolute top-4 right-4 w-14 h-14 rounded-2xl bg-amber-500 text-white font-extrabold text-2xl flex items-center justify-center border-2 border-white shadow-lg tabular-nums">
              {lesson.stepNumber}
            </div>
          )}
          <div className="absolute bottom-4 left-4 bg-white/95 rounded-2xl px-4 py-2 border-2 border-amber-300 shadow-md flex items-center gap-2">
            <img
              src={GAME_IMAGES.noorPortrait}
              alt="نور"
              className="w-10 h-10 rounded-full object-cover border-2 border-sky-400"
            />
            <span className="font-extrabold text-slate-900 text-lg">
              {lesson.visualData?.prayerName}
            </span>
          </div>
        </div>
      );
    }

    case 'prayer_prep_single': {
      const kind = lesson.visualData?.prepKind || 'taharah';
      if (kind === 'qiblah') {
        return (
          <div className="relative rounded-3xl overflow-hidden border-4 border-amber-200 shadow-lg h-72 sm:h-88">
            <img
              src={GAME_IMAGES.lessonQiblahKaaba}
              alt="آدم يتجه نحو الكعبة"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 left-4 bg-white/95 rounded-2xl px-4 py-2 border-2 border-amber-400 shadow-md flex items-center gap-2 animate-nudge-x">
              <ArrowLeft className="w-7 h-7 text-amber-600" />
              <span className="font-extrabold text-slate-900 text-base">نحو الكعبة</span>
            </div>
          </div>
        );
      }
      if (kind === 'awrah') {
        return (
          <div className="rounded-3xl bg-gradient-to-br from-emerald-50 to-sky-50 border-4 border-emerald-200 h-72 sm:h-88 flex items-center justify-center gap-8 p-6">
            <div className="text-center space-y-3">
              <img
                src={GAME_IMAGES.adamPortrait}
                alt="ملابس نظيفة ومحتشمة لآدم"
                className="w-40 h-40 sm:w-48 sm:h-48 rounded-3xl object-cover border-4 border-emerald-400 shadow-lg"
              />
              <span className="inline-flex items-center gap-1.5 text-emerald-800 font-extrabold text-lg">
                <CheckCircle2 className="w-5 h-5" />
                <span>ثوب نظيف</span>
              </span>
            </div>
            <div className="text-center space-y-3">
              <img
                src={GAME_IMAGES.noorPortrait}
                alt="ملابس نظيفة ومحتشمة لنور"
                className="w-40 h-40 sm:w-48 sm:h-48 rounded-3xl object-cover border-4 border-sky-400 shadow-lg"
              />
              <span className="inline-flex items-center gap-1.5 text-sky-800 font-extrabold text-lg">
                <CheckCircle2 className="w-5 h-5" />
                <span>حجاب ولبس محتشم</span>
              </span>
            </div>
          </div>
        );
      }
      return (
        <div className="relative rounded-3xl overflow-hidden border-4 border-sky-200 shadow-lg h-72 sm:h-88">
          <img
            src={GAME_IMAGES.lessonWuduHands}
            alt="الوضوء والطهارة بالماء"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    case 'wudu_intro':
      return (
        <div className="relative rounded-3xl overflow-hidden border-4 border-sky-200 shadow-lg h-72 sm:h-88">
          <img
            src={GAME_IMAGES.wuduOasisScene}
            alt="واحة الوضوء الجميلة"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-4 right-4 bg-white/95 rounded-2xl px-4 py-2 border-2 border-sky-300 shadow-md flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-sky-500" />
            <span className="font-extrabold text-sky-900 text-lg">ماء طهور</span>
          </div>
        </div>
      );

    case 'wudu_fard_sunnah':
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-3xl bg-emerald-50 border-3 border-emerald-400 p-5 flex flex-col items-center text-center gap-3 shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow">
              <Star className="w-9 h-9 fill-amber-300 text-amber-300" />
            </div>
            <h4 className="text-2xl font-extrabold text-emerald-950">الفروض (أساسية)</h4>
            <div className="grid grid-cols-3 gap-2 w-full pt-1">
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">النية</span>
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">الوجه</span>
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">اليدين للمرفق</span>
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">مسح الرأس</span>
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">الرجلين للكعب</span>
              <span className="rounded-xl bg-white border border-emerald-200 py-2 font-bold text-sm text-emerald-900">الترتيب</span>
            </div>
          </div>

          <div className="rounded-3xl bg-amber-50 border-3 border-amber-400 p-5 flex flex-col items-center text-center gap-3 shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow">
              <Heart className="w-9 h-9 fill-white" />
            </div>
            <h4 className="text-2xl font-extrabold text-amber-950">السنن (ثواب أكبر)</h4>
            <div className="grid grid-cols-3 gap-2 w-full pt-1">
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">بسم الله</span>
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">الكفين ٣×</span>
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">المضمضة</span>
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">الاستنشاق</span>
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">الأذنين</span>
              <span className="rounded-xl bg-white border border-amber-200 py-2 font-bold text-sm text-amber-900">اليمين أولًا</span>
            </div>
          </div>
        </div>
      );

    case 'wudu_step':
      return (
        <WuduStepIllustration
          stepId={lesson.visualData?.wuduStepId || 'hands'}
          stepNumber={lesson.stepNumber}
          repeatCount={lesson.repeatCount}
          rulingBadge={lesson.badgeTag}
          className="w-full h-72 sm:h-88"
        />
      );

    case 'wudu_order_summary':
      return (
        <div className="rounded-3xl bg-gradient-to-br from-sky-50 to-emerald-50 border-2 border-sky-200 p-5 space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 items-center">
            {[
              { n: '١', label: 'الوجه', step: 'face' as const },
              { n: '٢', label: 'اليدين', step: 'right_arm' as const },
              { n: '٣', label: 'الرأس', step: 'head' as const },
              { n: '٤', label: 'الرجلين', step: 'right_foot' as const },
            ].map((item, idx) => (
              <div key={item.n} className="relative flex flex-col items-center gap-2 bg-white rounded-2xl p-3 border-2 border-sky-200 shadow-xs">
                <span className="w-9 h-9 rounded-full bg-sky-600 text-white font-extrabold text-lg flex items-center justify-center tabular-nums">
                  {item.n}
                </span>
                <WuduStepIllustration stepId={item.step} compact className="w-full h-28" />
                <span className="font-extrabold text-slate-900 text-base">{item.label}</span>
                {idx < 3 && (
                  <ArrowLeft className="hidden sm:block absolute -left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-500 z-10 bg-white rounded-full" />
                )}
              </div>
            ))}
          </div>
          {lesson.dhikrPhrase && (
            <div className="rounded-2xl bg-white border-2 border-emerald-300 p-3 text-center">
              <p className="font-quran text-xl font-bold text-emerald-900">
                «{lesson.dhikrPhrase}»
              </p>
            </div>
          )}
        </div>
      );

    case 'prayer_pose':
      return (
        <PrayerPostureIllustration
          poseId={lesson.visualData?.poseId || 'qiyam'}
          stepNumber={lesson.stepNumber}
          dhikrPhrase={lesson.dhikrPhrase}
          className="w-full h-72 sm:h-88"
        />
      );

    case 'rakaat_summary': {
      const timeId = lesson.visualData?.timeId || 'fajr';
      const rakaatCount = lesson.visualData?.rakaatCount || 2;
      const sajdahCount = lesson.visualData?.sajdahCount || 4;
      const mode = lesson.visualData?.recitationMode || 'جهرية';
      const isLoud = mode !== 'سرية';

      return (
        <div className="rounded-3xl overflow-hidden border-2 border-slate-200 bg-white shadow-sm">
          <div className="relative h-40">
            <TimeOfDayVisual timeId={timeId} className="w-full h-full rounded-none border-0" />
            <div className="absolute bottom-3 right-4 bg-white/95 rounded-2xl px-4 py-1.5 font-extrabold text-slate-900 text-xl shadow">
              {lesson.visualData?.prayerName}
            </div>
          </div>

          <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            {/* Numbered Rakaat Visual Blocks */}
            <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-200 p-4 flex flex-col items-center justify-center gap-2">
              <div className="flex items-center gap-1.5">
                {Array.from({ length: rakaatCount }).map((_, idx) => (
                  <span
                    key={idx}
                    className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-extrabold text-xl flex items-center justify-center shadow-xs tabular-nums"
                  >
                    {idx + 1}
                  </span>
                ))}
              </div>
              <span className="font-extrabold text-emerald-950 text-lg">
                {rakaatCount === 2 ? 'ركعتان' : `${rakaatCount} ركعات`}
              </span>
            </div>

            {/* Sajdah Count */}
            <div className="rounded-2xl bg-sky-50 border-2 border-sky-200 p-4 flex flex-col items-center justify-center gap-2">
              <span className="w-14 h-14 rounded-2xl bg-sky-600 text-white font-extrabold text-3xl flex items-center justify-center shadow-xs tabular-nums">
                {sajdahCount}
              </span>
              <span className="font-extrabold text-sky-950 text-lg">
                {sajdahCount} سجدات
              </span>
            </div>

            {/* Loud vs Quiet */}
            <div className="rounded-2xl bg-amber-50 border-2 border-amber-200 p-4 flex flex-col items-center justify-center gap-2">
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-xs ${
                  isLoud ? 'bg-amber-500 text-white' : 'bg-slate-700 text-white'
                }`}
              >
                {isLoud ? <Volume2 className="w-8 h-8" /> : <VolumeX className="w-8 h-8" />}
              </div>
              <span className="font-extrabold text-amber-950 text-lg">{mode}</span>
            </div>
          </div>
        </div>
      );
    }

    case 'rakaat_detail': {
      const kind = lesson.visualData?.detailKind || 'first_two_surah';
      if (kind === 'first_two_surah') {
        return (
          <div className="rounded-3xl bg-gradient-to-br from-emerald-50 to-amber-50 border-2 border-emerald-200 p-6 flex flex-col sm:flex-row items-center justify-center gap-6">
            {[1, 2].map((num) => (
              <div
                key={num}
                className="flex flex-col items-center gap-3 bg-white rounded-3xl border-2 border-emerald-300 p-5 w-48 shadow-sm"
              >
                <span className="w-12 h-12 rounded-2xl bg-emerald-600 text-white font-extrabold text-2xl flex items-center justify-center tabular-nums">
                  {num}
                </span>
                <div className="flex items-center gap-2 text-emerald-700">
                  <BookOpen className="w-9 h-9" />
                  <span className="text-2xl font-extrabold">+</span>
                  <Star className="w-9 h-9 text-amber-500 fill-amber-400" />
                </div>
                <span className="font-extrabold text-slate-900 text-base">
                  الفاتحة + سورة
                </span>
              </div>
            ))}
          </div>
        );
      }

      if (kind === 'first_tashahhud') {
        return (
          <div className="rounded-3xl bg-gradient-to-br from-violet-50 to-amber-50 border-2 border-violet-200 p-6 flex flex-wrap items-center justify-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white font-extrabold text-2xl flex items-center justify-center">١</div>
            <ArrowLeft className="w-7 h-7 text-amber-500" />
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white font-extrabold text-2xl flex items-center justify-center">٢</div>
            <ArrowLeft className="w-7 h-7 text-amber-500" />
            <div className="w-48">
              <PrayerPostureIllustration poseId="tashahhud" compact className="h-44" />
            </div>
          </div>
        );
      }

      if (kind === 'last_two_fatiha' || kind === 'third_fatiha') {
        const nums = kind === 'third_fatiha' ? [3] : [3, 4];
        return (
          <div className="rounded-3xl bg-gradient-to-br from-sky-50 to-indigo-50 border-2 border-sky-200 p-6 flex flex-wrap items-center justify-center gap-6">
            {nums.map((num) => (
              <div
                key={num}
                className="flex flex-col items-center gap-3 bg-white rounded-3xl border-2 border-sky-300 p-5 w-48 shadow-sm"
              >
                <span className="w-12 h-12 rounded-2xl bg-sky-600 text-white font-extrabold text-2xl flex items-center justify-center tabular-nums">
                  {num}
                </span>
                <BookOpen className="w-10 h-10 text-sky-600" />
                <span className="font-extrabold text-slate-900 text-base">
                  الفاتحة فقط
                </span>
              </div>
            ))}
          </div>
        );
      }

      if (kind === 'isha_flow') {
        return (
          <div className="rounded-3xl bg-gradient-to-br from-indigo-50 to-violet-50 border-2 border-violet-200 p-5 flex flex-wrap items-center justify-center gap-3">
            <div className="rounded-2xl bg-white border-2 border-amber-300 px-4 py-3 text-center">
              <span className="block font-extrabold text-amber-700 text-xl">١ و ٢</span>
              <Volume2 className="w-7 h-7 text-amber-500 mx-auto my-1" />
              <span className="text-sm font-bold text-slate-800">جهرية</span>
            </div>
            <ArrowLeft className="w-6 h-6 text-slate-400" />
            <div className="rounded-2xl bg-white border-2 border-violet-300 px-4 py-3 text-center">
              <span className="block font-extrabold text-violet-700 text-xl">تشهد ١</span>
              <span className="text-sm font-bold text-slate-800">بعد ٢</span>
            </div>
            <ArrowLeft className="w-6 h-6 text-slate-400" />
            <div className="rounded-2xl bg-white border-2 border-sky-300 px-4 py-3 text-center">
              <span className="block font-extrabold text-sky-700 text-xl">٣ و ٤</span>
              <VolumeX className="w-7 h-7 text-sky-600 mx-auto my-1" />
              <span className="text-sm font-bold text-slate-800">الفاتحة فقط</span>
            </div>
            <ArrowLeft className="w-6 h-6 text-slate-400" />
            <div className="rounded-2xl bg-white border-2 border-emerald-300 px-4 py-3 text-center">
              <span className="block font-extrabold text-emerald-700 text-xl">تسليم</span>
              <span className="text-sm font-bold text-slate-800">يمين ويسار</span>
            </div>
          </div>
        );
      }

      return (
        <div className="rounded-3xl bg-gradient-to-br from-emerald-50 to-amber-50 border-2 border-emerald-200 p-5 flex flex-wrap items-center justify-center gap-4">
          <div className="w-44">
            <PrayerPostureIllustration poseId="tashahhud" compact className="h-44" />
          </div>
          <ArrowLeft className="w-8 h-8 text-amber-500" />
          <div className="w-44">
            <PrayerPostureIllustration poseId="tasleem" compact className="h-44" />
          </div>
        </div>
      );
    }

    case 'prayer_compare':
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-3xl bg-sky-50 border-3 border-sky-300 p-5 text-center space-y-3">
            <TimeOfDayVisual timeId="fajr" className="w-full h-28" />
            <p className="text-2xl font-extrabold text-sky-950">الفجر: ٢ ركعة</p>
            <div className="inline-flex items-center gap-2 bg-white rounded-xl px-4 py-2 font-extrabold text-amber-700 border border-amber-200">
              <Volume2 className="w-5 h-5" />
              <span>صوت مسموع</span>
            </div>
          </div>
          <div className="rounded-3xl bg-amber-50 border-3 border-amber-300 p-5 text-center space-y-3">
            <TimeOfDayVisual timeId="asr" className="w-full h-28" />
            <p className="text-2xl font-extrabold text-amber-950">العصر: ٤ ركعات</p>
            <div className="inline-flex items-center gap-2 bg-white rounded-xl px-4 py-2 font-extrabold text-slate-700 border border-slate-200">
              <VolumeX className="w-5 h-5" />
              <span>سرية في القلب</span>
            </div>
          </div>
        </div>
      );

    default:
      return (
        <div className="relative rounded-3xl overflow-hidden border-4 border-emerald-200 shadow-lg h-72 sm:h-88">
          <img
            src={GAME_IMAGES.lessonNoorTeaching}
            alt="نور تشرح الدرس"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
      );
  }
};
