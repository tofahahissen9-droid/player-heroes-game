import React from 'react';
import { WuduStepId } from '../../types/game';
import { GAME_IMAGES } from '../../data/assets';

interface WuduStepIllustrationProps {
  stepId: WuduStepId;
  className?: string;
  stepNumber?: number;
  repeatCount?: number;
  rulingBadge?: 'فرض' | 'سنة' | 'شرط' | 'مهم';
  compact?: boolean;
}

const REPEAT_MAP: Record<WuduStepId, number> = {
  niyyah: 1,
  hands: 3,
  mouth: 3,
  nose: 3,
  face: 3,
  right_arm: 3,
  left_arm: 3,
  head: 1,
  ears: 1,
  right_foot: 3,
  left_foot: 3,
};

export const WuduStepIllustration: React.FC<WuduStepIllustrationProps> = ({
  stepId,
  className = 'w-full h-72',
  stepNumber,
  repeatCount,
  rulingBadge,
  compact = false,
}) => {
  const repeats = repeatCount ?? REPEAT_MAP[stepId];

  // For washing hands in full lesson view, pair the gorgeous 3D hands image or detailed animated SVG
  const showHandsPhoto = !compact && stepId === 'hands';

  return (
    <div
      className={`relative flex items-center justify-center rounded-3xl bg-gradient-to-b from-sky-100/80 via-cyan-50 to-emerald-50 border-2 border-sky-200 overflow-hidden shadow-inner ${
        compact ? 'p-2' : 'p-4'
      } ${className}`}
    >
      {/* Step Number Circle (Top Right in RTL) */}
      {!compact && stepNumber !== undefined && (
        <div className="absolute top-3 right-3 z-10 w-12 h-12 rounded-2xl bg-sky-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-md border-2 border-white tabular-nums">
          {stepNumber}
        </div>
      )}

      {/* Repeat Count Visual Pill (Top Left in RTL) */}
      {!compact && (
        <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 rounded-2xl bg-white/95 border-2 border-sky-300 px-3.5 py-1.5 shadow-sm">
          <div className="flex items-center gap-0.5">
            {Array.from({ length: repeats }).map((_, idx) => (
              <span
                key={idx}
                className="inline-block w-3 h-4 rounded-full bg-sky-500 animate-pulse-soft"
                style={{
                  clipPath: 'polygon(50% 0%, 100% 62%, 82% 100%, 18% 100%, 0% 62%)',
                  animationDelay: `${idx * 250}ms`,
                }}
              />
            ))}
          </div>
          <span className="font-extrabold text-sky-900 text-base tabular-nums">
            {repeats === 1 ? 'مرة ١' : `${repeats} مرات`}
          </span>
        </div>
      )}

      {/* Ruling Indicator at bottom right */}
      {!compact && rulingBadge && (
        <div
          className={`absolute bottom-3 right-3 z-10 rounded-xl px-3.5 py-1 text-sm font-extrabold border-2 shadow-xs ${
            rulingBadge === 'فرض'
              ? 'bg-emerald-600 text-white border-emerald-200'
              : 'bg-amber-500 text-white border-amber-200'
          }`}
        >
          {rulingBadge === 'فرض' ? '★ فرض أساسي' : '♥ سنة جميلة'}
        </div>
      )}

      {showHandsPhoto ? (
        <div className="relative w-full h-full flex items-center justify-center">
          <img
            src={GAME_IMAGES.lessonWuduHands}
            alt="آدم يغسل يديه بالماء"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover rounded-2xl"
          />
          <div className="absolute bottom-3 left-3 bg-white/95 rounded-2xl px-4 py-2 border-2 border-sky-300 shadow-md flex items-center gap-2 animate-float-slow">
            <span className="text-sky-600 font-extrabold text-lg">١ · ٢ · ٣</span>
          </div>
        </div>
      ) : (
        <svg
          viewBox="0 0 280 230"
          className="w-full h-full max-w-[300px]"
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="wGlow3d" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.75" />
              <stop offset="100%" stopColor="#0284C7" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="thobe3d" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="65%" stopColor="#F5EFE0" />
              <stop offset="100%" stopColor="#DFD5BC" />
            </linearGradient>
            <linearGradient id="skin3d" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F8D2B4" />
              <stop offset="100%" stopColor="#E1A376" />
            </linearGradient>
            <linearGradient id="water3d" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7DD3FC" />
              <stop offset="100%" stopColor="#0284C7" />
            </linearGradient>
          </defs>

          {/* Soft 3D ground shadow */}
          <ellipse cx="140" cy="212" rx="92" ry="12" fill="#7DD3FC" opacity="0.45" />

          {/* Kufi Cap with soft 3D shading */}
          <path
            d="M112 46 C112 24, 168 24, 168 46 Z"
            fill="#FFFFFF"
            stroke="#CBD5E1"
            strokeWidth="2"
          />
          {/* Head */}
          <circle cx="140" cy="60" r="28" fill="url(#skin3d)" />
          {/* Hair */}
          <path
            d="M114 48 Q140 38 166 48"
            fill="none"
            stroke="#292524"
            strokeWidth="6"
            strokeLinecap="round"
          />
          {/* Expressive friendly 3D eyes */}
          <circle cx="130" cy="59" r="3.4" fill="#1E293B" />
          <circle cx="129" cy="58" r="1.1" fill="#FFFFFF" />
          <circle cx="150" cy="59" r="3.4" fill="#1E293B" />
          <circle cx="149" cy="58" r="1.1" fill="#FFFFFF" />
          {/* Rosy cheeks */}
          <ellipse cx="122" cy="66" rx="4" ry="2.2" fill="#FB7185" opacity="0.35" />
          <ellipse cx="158" cy="66" rx="4" ry="2.2" fill="#FB7185" opacity="0.35" />
          {/* Happy smile */}
          <path
            d="M131 71 Q140 78 149 71"
            fill="none"
            stroke="#9A3412"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Ears */}
          <circle cx="110" cy="61" r="6" fill="url(#skin3d)" />
          <circle cx="170" cy="61" r="6" fill="url(#skin3d)" />

          {/* Thobe torso */}
          <path
            d="M104 92 Q140 85 176 92 L186 174 Q140 180 94 174 Z"
            fill="url(#thobe3d)"
            stroke="#059669"
            strokeWidth="2.5"
          />
          <path
            d="M126 90 L140 114 L154 90"
            fill="none"
            stroke="#059669"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Right Arm (viewer's left) */}
          <path
            d="M104 95 L76 138 L90 146 L112 112"
            fill="url(#skin3d)"
            stroke="#C2885C"
            strokeWidth="1.5"
          />
          {/* Left Arm (viewer's right) */}
          <path
            d="M176 95 L204 138 L190 146 L168 112"
            fill="url(#skin3d)"
            stroke="#C2885C"
            strokeWidth="1.5"
          />

          {/* Hands */}
          <circle cx="81" cy="144" r="9.5" fill="url(#skin3d)" />
          <circle cx="199" cy="144" r="9.5" fill="url(#skin3d)" />

          {/* Ankles & Feet */}
          <rect x="114" y="175" width="14" height="24" rx="5" fill="url(#skin3d)" />
          <rect x="152" y="175" width="14" height="24" rx="5" fill="url(#skin3d)" />
          <ellipse cx="121" cy="202" rx="16" ry="9" fill="url(#skin3d)" />
          <ellipse cx="159" cy="202" rx="16" ry="9" fill="url(#skin3d)" />

          {/* ACTIVE STEP VISUALS, ANIMATIONS & DIRECTIONAL ARROWS */}
          {stepId === 'niyyah' && (
            <g className="animate-pulse-soft">
              <circle cx="140" cy="126" r="28" fill="url(#wGlow3d)" />
              <path
                d="M140 140 C125 129 120 116 128 109 C133 105 138 109 140 113 C142 109 147 105 152 109 C160 116 155 129 140 140 Z"
                fill="#F59E0B"
                stroke="#FFFFFF"
                strokeWidth="2.5"
              />
              {/* Speech bubble saying بسم الله */}
              <rect x="166" y="18" width="84" height="32" rx="14" fill="#FFFFFF" stroke="#059669" strokeWidth="2.5" />
              <text x="208" y="39" textAnchor="middle" fill="#065F46" fontSize="14" fontWeight="800">
                بِسْمِ اللَّهِ
              </text>
            </g>
          )}

          {stepId === 'hands' && (
            <g>
              <circle cx="81" cy="144" r="22" fill="url(#wGlow3d)" />
              <circle cx="199" cy="144" r="22" fill="url(#wGlow3d)" />
              <circle cx="81" cy="144" r="13" fill="#38BDF8" fillOpacity="0.45" stroke="#0284C7" strokeWidth="3" />
              <circle cx="199" cy="144" r="13" fill="#38BDF8" fillOpacity="0.45" stroke="#0284C7" strokeWidth="3" />
              {/* Animated droplets */}
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M81 112 C76 120 76 126 81 126 C86 126 86 120 81 112 Z" />
                <path d="M199 112 C194 120 194 126 199 126 C204 126 204 120 199 112 Z" />
              </g>
            </g>
          )}

          {stepId === 'mouth' && (
            <g>
              <circle cx="140" cy="72" r="22" fill="url(#wGlow3d)" />
              <ellipse cx="140" cy="72" rx="13" ry="8" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3" />
              <path d="M168 72 L192 72 M176 66 L166 72 L176 78" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-x" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M140 84 C136 91 136 96 140 96 C144 96 144 91 140 84 Z" />
              </g>
            </g>
          )}

          {stepId === 'nose' && (
            <g>
              <circle cx="140" cy="63" r="18" fill="url(#wGlow3d)" />
              <circle cx="140" cy="63" r="9" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3" />
              <path d="M166 63 L192 63 M174 57 L164 63 L174 69" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-x" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M140 42 C136 48 136 53 140 53 C144 53 144 48 140 42 Z" />
              </g>
            </g>
          )}

          {stepId === 'face' && (
            <g>
              <circle cx="140" cy="60" r="40" fill="url(#wGlow3d)" />
              <circle cx="140" cy="60" r="29" fill="#38BDF8" fillOpacity="0.3" stroke="#0284C7" strokeWidth="3.5" strokeDasharray="6 3" />
              {/* Up-down circular wash arrows */}
              <path d="M98 44 L98 76 M92 68 L98 78 L104 68" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
              <path d="M182 44 L182 76 M176 68 L182 78 L188 68" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
            </g>
          )}

          {stepId === 'right_arm' && (
            <g>
              <circle cx="94" cy="118" r="34" fill="url(#wGlow3d)" />
              <path d="M104 95 L76 138 L90 146 L112 112 Z" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3.5" />
              {/* Arrow from fingertips up to elbow */}
              <path d="M62 146 L88 102 M78 106 L89 100 L90 112" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M74 96 C70 103 70 108 74 108 C78 108 78 103 74 96 Z" />
              </g>
            </g>
          )}

          {stepId === 'left_arm' && (
            <g>
              <circle cx="186" cy="118" r="34" fill="url(#wGlow3d)" />
              <path d="M176 95 L204 138 L190 146 L168 112 Z" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3.5" />
              {/* Arrow from fingertips up to elbow */}
              <path d="M218 146 L192 102 M190 112 L191 100 L202 106" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-y" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M206 96 C202 103 202 108 206 108 C210 108 210 103 206 96 Z" />
              </g>
            </g>
          )}

          {stepId === 'head' && (
            <g>
              <circle cx="140" cy="36" r="36" fill="url(#wGlow3d)" />
              <path d="M106 46 C106 20, 174 20, 174 46" fill="none" stroke="#0284C7" strokeWidth="7" strokeLinecap="round" />
              {/* Swipe arrow across head */}
              <path d="M112 18 L168 18 M158 12 L170 18 L158 24" fill="none" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="animate-nudge-x" />
            </g>
          )}

          {stepId === 'ears' && (
            <g>
              <circle cx="109" cy="61" r="16" fill="url(#wGlow3d)" />
              <circle cx="171" cy="61" r="16" fill="url(#wGlow3d)" />
              <circle cx="109" cy="61" r="9" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3" />
              <circle cx="171" cy="61" r="9" fill="#38BDF8" fillOpacity="0.55" stroke="#0284C7" strokeWidth="3" />
              <path d="M84 61 L96 61 M90 56 L97 61 L90 66" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M196 61 L184 61 M190 56 L183 61 L190 66" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
            </g>
          )}

          {stepId === 'right_foot' && (
            <g>
              <circle cx="121" cy="196" r="28" fill="url(#wGlow3d)" />
              <ellipse cx="121" cy="196" rx="22" ry="16" fill="#38BDF8" fillOpacity="0.45" stroke="#0284C7" strokeWidth="3" />
              <path d="M84 196 L98 196 M91 190 L99 196 L91 202" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M121 158 C117 165 117 170 121 170 C125 170 125 165 121 158 Z" />
              </g>
            </g>
          )}

          {stepId === 'left_foot' && (
            <g>
              <circle cx="159" cy="196" r="28" fill="url(#wGlow3d)" />
              <ellipse cx="159" cy="196" rx="22" ry="16" fill="#38BDF8" fillOpacity="0.45" stroke="#0284C7" strokeWidth="3" />
              <path d="M196 196 L182 196 M189 190 L181 196 L189 202" fill="none" stroke="#F59E0B" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              <g className="animate-water-fall" fill="url(#water3d)">
                <path d="M159 158 C155 165 155 170 159 170 C163 170 163 165 159 158 Z" />
              </g>
            </g>
          )}
        </svg>
      )}
    </div>
  );
};
