import React, { useState, useEffect } from 'react';
import {
  Map,
  Volume2,
  VolumeX,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Star,
  BookOpen,
  Gamepad2,
  ClipboardCheck,
  Play,
} from 'lucide-react';
import { LevelDefinition, SpeakerId } from '../types/game';
import { STATION_IMAGES } from '../data/assets';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { LessonStage } from './LessonStage';
import { ActivityArena } from './activities/ActivityArena';
import { QuizArena } from './quiz/QuizArena';
import { audioEngine } from '../utils/audioEngine';

interface LevelWorkspaceProps {
  level: LevelDefinition;
  soundEnabled: boolean;
  points: number;
  stars: number;
  onToggleSound: () => void;
  onBackToMap: () => void;
  onAwardActivity: () => void;
  onPassLevel: (quizScore: number) => void;
}

type StagePhase = 'INTRO' | 'LESSONS' | 'ACTIVITIES' | 'QUIZ';

export const LevelWorkspace: React.FC<LevelWorkspaceProps> = ({
  level,
  soundEnabled,
  stars,
  onToggleSound,
  onBackToMap,
  onAwardActivity,
  onPassLevel,
}) => {
  const [phase, setPhase] = useState<StagePhase>('INTRO');
  const [lessonIdx, setLessonIdx] = useState(0);
  const [activityIdx, setActivityIdx] = useState(0);
  const [activityResetKey, setActivityResetKey] = useState(0);
  const [completedActivities, setCompletedActivities] = useState<string[]>([]);
  const [speakingWho, setSpeakingWho] = useState<SpeakerId | null>(null);

  useEffect(() => {
    const unsub = audioEngine.subscribeSpeaking(setSpeakingWho);
    return () => {
      unsub();
      audioEngine.stopSpeech();
    };
  }, []);

  useEffect(() => {
    setPhase('INTRO');
    setLessonIdx(0);
    setActivityIdx(0);
    setCompletedActivities([]);
    setActivityResetKey(0);
  }, [level.id]);

  useEffect(() => {
    audioEngine.stopSpeech();
  }, [phase, lessonIdx, activityIdx, activityResetKey]);

  const currentLesson = level.lessons[lessonIdx];
  const currentActivity = level.activities[activityIdx];

  const introTrackId = `level_${level.id}_intro`;

  // Preload static MP3s for current & next screens so pressing Speaker plays immediately
  useEffect(() => {
    if (phase === 'INTRO') {
      audioEngine.prefetchTrack(introTrackId);
      if (level.lessons[0]) {
        audioEngine.prefetchTrack(`lesson_${level.lessons[0].id}`);
      }
    } else if (phase === 'LESSONS') {
      const nextLesson = level.lessons[lessonIdx + 1];
      if (nextLesson) {
        audioEngine.prefetchTrack(`lesson_${nextLesson.id}`);
      }
    } else if (phase === 'ACTIVITIES') {
      const nextAct = level.activities[activityIdx + 1];
      if (nextAct) {
        audioEngine.prefetchTrack(`act_${nextAct.id}`);
      }
    }
  }, [activityIdx, introTrackId, lessonIdx, level, phase]);

  const handleActivitySuccess = (actId: string) => {
    if (!completedActivities.includes(actId)) {
      setCompletedActivities((prev) => [...prev, actId]);
      onAwardActivity();
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F2] bg-islamic-pattern flex flex-col">
      {/* Clean Top Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b-2 border-slate-200 px-4 md:px-8 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => {
                audioEngine.stopSpeech();
                audioEngine.playClick();
                onBackToMap();
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-base whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Map className="w-5 h-5 text-emerald-700" />
              <span>الخريطة</span>
            </button>
            <h2 className="text-lg md:text-xl font-extrabold text-slate-900 truncate">
              {level.id}. {level.title}
            </h2>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="flex items-center gap-1 text-base font-extrabold text-amber-600 tabular-nums">
              <Star className="w-5 h-5 fill-amber-400" />
              {stars}
            </span>

            <button
              type="button"
              onClick={onToggleSound}
              aria-label={soundEnabled ? 'إيقاف الصوت' : 'تشغيل الصوت'}
              className="w-11 h-11 rounded-2xl border-2 border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center text-slate-700 cursor-pointer"
            >
              {soundEnabled ? (
                <Volume2 className="w-6 h-6 text-emerald-600" />
              ) : (
                <VolumeX className="w-6 h-6 text-slate-400" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Large 3-Tab Phase Switcher */}
      <div className="max-w-4xl w-full mx-auto px-4 pt-5">
        <div className="grid grid-cols-3 gap-2.5 p-2 rounded-3xl bg-white border-2 border-slate-200 shadow-xs">
          <button
            type="button"
            onClick={() => {
              audioEngine.playClick();
              setPhase('LESSONS');
            }}
            className={`min-h-[52px] py-2.5 px-3 rounded-2xl font-extrabold text-base flex items-center justify-center gap-2 transition-colors cursor-pointer ${
              phase === 'LESSONS' || phase === 'INTRO'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span>اتعلم ({lessonIdx + 1}/{level.lessons.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioEngine.playClick();
              setPhase('ACTIVITIES');
            }}
            className={`min-h-[52px] py-2.5 px-3 rounded-2xl font-extrabold text-base flex items-center justify-center gap-2 transition-colors cursor-pointer ${
              phase === 'ACTIVITIES'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Gamepad2 className="w-5 h-5" />
            <span>العب ({activityIdx + 1}/{level.activities.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioEngine.playClick();
              setPhase('QUIZ');
            }}
            className={`min-h-[52px] py-2.5 px-3 rounded-2xl font-extrabold text-base flex items-center justify-center gap-2 transition-colors cursor-pointer ${
              phase === 'QUIZ'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ClipboardCheck className="w-5 h-5" />
            <span>اختبر نفسك</span>
          </button>
        </div>
      </div>

      {/* Main Content Stage */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-6 space-y-6">
        {phase === 'INTRO' && (
          <div className="rounded-3xl bg-white border-3 border-emerald-200 overflow-hidden shadow-md p-5 md:p-7 space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <CharacterAvatar character="adam" size="lg" isSpeaking={speakingWho !== null} />
                <CharacterAvatar character="noor" size="lg" isSpeaking={speakingWho !== null} />
              </div>
              <SpeakerButton
                trackId={introTrackId}
                speaker="adam"
                label="اسمع"
                variant="amber"
              />
            </div>

            <div className="relative h-64 sm:h-80 w-full rounded-3xl overflow-hidden border-2 border-slate-200 bg-slate-900">
              <img
                src={STATION_IMAGES[level.id]}
                alt={level.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-amber-500 text-white font-extrabold text-lg px-4 py-1.5 rounded-2xl shadow border-2 border-white">
                المحطة {level.id} من ٧
              </div>
            </div>

            <div className="rounded-2xl bg-[#FAF8F2] border-2 border-emerald-200 p-5 text-center">
              <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
                {level.shortIntro}
              </p>
            </div>

            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => {
                  audioEngine.playClick();
                  setPhase('LESSONS');
                }}
                className="btn-3d inline-flex items-center gap-3 px-10 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-2xl shadow-[0_5px_0_#047857] cursor-pointer"
              >
                <Play className="w-7 h-7 fill-white" />
                <span>يلا نبدأ!</span>
              </button>
            </div>
          </div>
        )}

        {phase === 'LESSONS' && currentLesson && (
          <div className="space-y-5">
            <LessonStage
              lesson={currentLesson}
              lessonIndex={lessonIdx}
              totalLessons={level.lessons.length}
              speakingWho={speakingWho}
            />

            <div className="flex items-center justify-between gap-4">
              <button
                type="button"
                disabled={lessonIdx === 0}
                onClick={() => {
                  audioEngine.playClick();
                  setLessonIdx((p) => Math.max(0, p - 1));
                }}
                className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl border-2 border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 font-extrabold text-lg text-slate-700 cursor-pointer"
              >
                <ArrowRight className="w-6 h-6" />
                <span>السابق</span>
              </button>

              {lessonIdx + 1 < level.lessons.length ? (
                <button
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setLessonIdx((p) => p + 1);
                  }}
                  className="btn-3d inline-flex items-center gap-3 px-9 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
                >
                  <span>التالي</span>
                  <ArrowLeft className="w-6 h-6" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setPhase('ACTIVITIES');
                  }}
                  className="btn-3d inline-flex items-center gap-3 px-9 py-4 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xl shadow-[0_5px_0_#0369A1] cursor-pointer"
                >
                  <span>يلا نلعب!</span>
                  <ArrowLeft className="w-6 h-6" />
                </button>
              )}
            </div>
          </div>
        )}

        {phase === 'ACTIVITIES' && currentActivity && (
          <div className="space-y-5">
            <div className="rounded-3xl bg-white border-3 border-sky-200 p-5 md:p-7 shadow-sm space-y-5">
              <ActivityArena
                key={`${currentActivity.id}_${activityResetKey}`}
                activity={currentActivity}
                onSuccess={() => handleActivitySuccess(currentActivity.id)}
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  disabled={activityIdx === 0}
                  onClick={() => {
                    audioEngine.playClick();
                    setActivityIdx((p) => Math.max(0, p - 1));
                  }}
                  className="inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl border-2 border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 font-extrabold text-base text-slate-700 cursor-pointer"
                >
                  <ArrowRight className="w-5 h-5" />
                  <span>السابق</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setActivityResetKey((k) => k + 1);
                  }}
                  className="inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl border-2 border-slate-300 bg-white hover:bg-slate-50 font-extrabold text-base text-slate-700 cursor-pointer"
                >
                  <RotateCcw className="w-5 h-5" />
                  <span>إعادة</span>
                </button>
              </div>

              {activityIdx + 1 < level.activities.length ? (
                <button
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setActivityIdx((p) => p + 1);
                  }}
                  className="btn-3d inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xl shadow-[0_5px_0_#0369A1] cursor-pointer"
                >
                  <span>اللعبة الجاية</span>
                  <ArrowLeft className="w-6 h-6" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    audioEngine.playClick();
                    setPhase('QUIZ');
                  }}
                  className="btn-3d inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xl shadow-[0_5px_0_#B45309] cursor-pointer"
                >
                  <span>يلا للاختبار!</span>
                  <ArrowLeft className="w-6 h-6" />
                </button>
              )}
            </div>
          </div>
        )}

        {phase === 'QUIZ' && (
          <QuizArena
            questions={level.quiz}
            badge={level.badge}
            onPassLevel={onPassLevel}
            onBackToMap={onBackToMap}
          />
        )}
      </main>
    </div>
  );
};
