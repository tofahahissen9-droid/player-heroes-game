import React, { useEffect, useState } from 'react';
import { Volume2, Square, Loader2, RotateCcw } from 'lucide-react';
import { SpeakerId } from '../types/game';
import { audioEngine } from '../utils/audioEngine';

interface SpeakerButtonProps {
  trackId: string;
  speaker?: SpeakerId;
  playId?: string;
  label?: string;
  variant?: 'emerald' | 'sky' | 'amber' | 'slate';
  className?: string;
}

const VARIANT_CLASSES: Record<
  NonNullable<SpeakerButtonProps['variant']>,
  string
> = {
  emerald:
    'bg-emerald-600 hover:bg-emerald-700 text-white shadow-[0_4px_0_#047857]',
  sky: 'bg-sky-600 hover:bg-sky-700 text-white shadow-[0_4px_0_#0369A1]',
  amber: 'bg-amber-500 hover:bg-amber-600 text-white shadow-[0_4px_0_#B45309]',
  slate:
    'bg-white hover:bg-slate-100 text-slate-800 border-2 border-slate-300 shadow-[0_3px_0_#CBD5E1]',
};

export const SpeakerButton: React.FC<SpeakerButtonProps> = ({
  trackId,
  speaker = 'adam',
  playId,
  label = 'اسمع',
  variant = 'sky',
  className = '',
}) => {
  const resolvedId = playId || trackId;

  const [isActive, setIsActive] = useState(
    () => audioEngine.getActivePlayId() === resolvedId
  );
  const [isLoading, setIsLoading] = useState(
    () => audioEngine.getLoadingPlayId() === resolvedId
  );
  const [hasPlayed, setHasPlayed] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    audioEngine.prefetchTrack(trackId);
    setIsActive(audioEngine.getActivePlayId() === resolvedId);
    setIsLoading(audioEngine.getLoadingPlayId() === resolvedId);
    setHasPlayed(false);
    setErrorMsg(null);

    const unsubSpeaking = audioEngine.subscribeSpeaking(
      (_speaker, activeId, loadingId) => {
        const activeNow = activeId === resolvedId;
        setIsActive(activeNow);
        setIsLoading(loadingId === resolvedId);
        if (activeNow) {
          setHasPlayed(true);
          setErrorMsg(null);
        }
      }
    );
    const unsubError = audioEngine.subscribeError((err) => {
      if (!err) {
        setErrorMsg(null);
      } else if (err.playId === resolvedId) {
        setErrorMsg(err.message);
      }
    });
    return () => {
      unsubSpeaking();
      unsubError();
    };
  }, [resolvedId, trackId]);

  const handlePrimaryClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    audioEngine.playClick();
    if (isActive || isLoading) {
      audioEngine.stopSpeech();
    } else {
      setErrorMsg(null);
      setHasPlayed(true);
      void audioEngine.playTrack(trackId, speaker, resolvedId);
    }
  };

  const handleReplayClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    audioEngine.playClick();
    setErrorMsg(null);
    setHasPlayed(true);
    void audioEngine.replayTrack(trackId, speaker, resolvedId);
  };

  return (
    <div className={`inline-flex flex-col items-end gap-1.5 shrink-0 ${className}`}>
      <div className="inline-flex items-center gap-2">
        <button
          type="button"
          onClick={handlePrimaryClick}
          aria-label={isActive ? 'إيقاف الصوت' : label}
          className={`btn-3d inline-flex items-center justify-center gap-2.5 min-h-[52px] px-6 py-3 rounded-2xl font-extrabold text-base md:text-lg whitespace-nowrap shrink-0 cursor-pointer ${
            isActive
              ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-[0_4px_0_#BE123C] ring-4 ring-rose-200'
              : isLoading
              ? 'bg-sky-500 text-white shadow-[0_4px_0_#0369A1]'
              : VARIANT_CLASSES[variant]
          }`}
        >
          {isLoading ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              <span>ثانية...</span>
            </>
          ) : isActive ? (
            <>
              <Square className="w-5 h-5 fill-current" />
              <span>إيقاف</span>
            </>
          ) : (
            <>
              <Volume2 className="w-6 h-6" />
              <span>{label}</span>
            </>
          )}
        </button>

        {(isActive || hasPlayed) && (
          <button
            type="button"
            onClick={handleReplayClick}
            aria-label="إعادة الصوت"
            title="إعادة الصوت من الأول"
            className="btn-3d inline-flex items-center justify-center gap-1.5 min-h-[52px] px-4 py-3 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 border-2 border-slate-300 shadow-[0_3px_0_#CBD5E1] font-extrabold text-sm md:text-base whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 text-sky-700" />
            <span>إعادة</span>
          </button>
        )}
      </div>

      {errorMsg && (
        <span
          role="status"
          className="text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-1 max-w-[260px] text-right leading-snug"
        >
          {errorMsg}
        </span>
      )}
    </div>
  );
};
