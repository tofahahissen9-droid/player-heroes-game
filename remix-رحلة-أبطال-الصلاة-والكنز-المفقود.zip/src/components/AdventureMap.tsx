import React, { useEffect } from 'react';
import {
  Lock,
  CheckCircle2,
  Star,
  Award,
  Volume2,
  VolumeX,
  Home,
  Play,
  Trophy,
} from 'lucide-react';
import { LEVELS } from '../data/gameContent';
import { GAME_IMAGES, STATION_IMAGES } from '../data/assets';
import { PlayerProgress } from '../types/game';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { audioEngine } from '../utils/audioEngine';

interface AdventureMapProps {
  progress: PlayerProgress;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onSelectLevel: (levelId: number) => void;
  onOpenVictory: () => void;
  onBackHome: () => void;
}

export const AdventureMap: React.FC<AdventureMapProps> = ({
  progress,
  soundEnabled,
  onToggleSound,
  onSelectLevel,
  onOpenVictory,
  onBackHome,
}) => {
  const allCompleted = progress.completedLevels.length === LEVELS.length;

  const mapTrackId = allCompleted
    ? 'map_state_all_done'
    : `map_state_${progress.unlockedLevel}`;

  useEffect(() => {
    audioEngine.prefetchTrack(mapTrackId);
  }, [mapTrackId]);

  useEffect(() => {
    return () => {
      audioEngine.stopSpeech();
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-[#FAF8F2] to-emerald-50 flex flex-col">
      {/* Clean Top Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b-2 border-slate-200 px-4 md:px-8 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                audioEngine.playClick();
                onBackHome();
              }}
              className="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 cursor-pointer"
              aria-label="الشاشة الرئيسية"
            >
              <Home className="w-6 h-6" />
            </button>
            <h1 className="text-xl md:text-2xl font-extrabold text-slate-900 whitespace-nowrap">
              خريطة الرحلة
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-3 text-base font-extrabold tabular-nums">
              <span className="flex items-center gap-1 text-amber-600">
                <Star className="w-5 h-5 fill-amber-400" />
                {progress.stars}
              </span>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <span className="hidden sm:inline text-emerald-700">
                {progress.earnedBadges.length}/7 شارات
              </span>
            </div>

            <SpeakerButton
              trackId={mapTrackId}
              speaker="adam"
              label="اسمع"
              variant="emerald"
            />

            <button
              type="button"
              onClick={onToggleSound}
              aria-label={soundEnabled ? 'إيقاف الصوت' : 'تشغيل الصوت'}
              className="w-12 h-12 rounded-2xl border-2 border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center cursor-pointer"
            >
              {soundEnabled ? (
                <Volume2 className="w-6 h-6 text-emerald-600" />
              ) : (
                <VolumeX className="w-6 h-6 text-slate-400" />
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 md:px-8 py-6 space-y-6">
        {/* Friendly Adam & Noor Guide Strip */}
        <div className="rounded-3xl bg-white border-2 border-emerald-200 p-4 md:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 shrink-0">
              <CharacterAvatar character="adam" size="md" />
              <CharacterAvatar character="noor" size="md" />
            </div>
            <p className="font-extrabold text-slate-900 text-lg md:text-xl">
              {allCompleted
                ? 'برافو عليك! خلصت كل المحطات! افتح الكنز!'
                : `المحطة الجاية: ${LEVELS[progress.unlockedLevel - 1]?.title}`}
            </p>
          </div>

          <div className="w-full sm:w-56">
            <div className="h-4 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
              <div
                className="h-full bg-gradient-to-l from-emerald-500 to-amber-400 transition-all duration-500"
                style={{
                  width: `${(progress.completedLevels.length / LEVELS.length) * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        {/* 7 Visual Stations + Treasure Chest */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {LEVELS.map((lvl) => {
            const isCompleted = progress.completedLevels.includes(lvl.id);
            const isUnlocked = lvl.id <= progress.unlockedLevel;
            const isCurrent = lvl.id === progress.unlockedLevel && !isCompleted;
            const stationImage = STATION_IMAGES[lvl.id];

            return (
              <button
                key={lvl.id}
                type="button"
                disabled={!isUnlocked}
                onClick={() => {
                  if (!isUnlocked) return;
                  audioEngine.playClick();
                  onSelectLevel(lvl.id);
                }}
                className={`group relative text-right rounded-3xl border-3 overflow-hidden transition-all flex flex-col bg-white ${
                  isCompleted
                    ? 'border-emerald-500 shadow-md hover:-translate-y-1 cursor-pointer'
                    : isCurrent
                    ? 'border-amber-500 shadow-xl ring-4 ring-amber-200 hover:-translate-y-1 cursor-pointer'
                    : isUnlocked
                    ? 'border-sky-400 shadow-sm hover:-translate-y-1 cursor-pointer'
                    : 'border-slate-200 opacity-65 cursor-not-allowed'
                }`}
              >
                <div className="relative w-full aspect-[4/3] overflow-hidden bg-slate-200">
                  <img
                    src={stationImage}
                    alt={lvl.title}
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover transition-transform duration-300 ${
                      isUnlocked ? 'group-hover:scale-105' : 'grayscale-[60%] brightness-75'
                    }`}
                  />

                  {/* Big Station Number */}
                  <span
                    className={`absolute top-3 right-3 w-12 h-12 rounded-2xl font-extrabold text-2xl flex items-center justify-center shadow-lg border-2 border-white tabular-nums ${
                      isCompleted
                        ? 'bg-emerald-600 text-white'
                        : isUnlocked
                        ? 'bg-amber-500 text-white'
                        : 'bg-slate-700 text-slate-200'
                    }`}
                  >
                    {lvl.id}
                  </span>

                  {/* Status Icon */}
                  <div className="absolute top-3 left-3">
                    {isCompleted ? (
                      <span className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow border-2 border-white">
                        <CheckCircle2 className="w-6 h-6" />
                      </span>
                    ) : !isUnlocked ? (
                      <span className="w-11 h-11 rounded-2xl bg-slate-900/85 text-white flex items-center justify-center shadow">
                        <Lock className="w-5 h-5" />
                      </span>
                    ) : (
                      <span className="w-11 h-11 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow border-2 border-white animate-pulse-soft">
                        <Play className="w-6 h-6 fill-white" />
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-4 w-full flex items-center justify-between gap-2">
                  <h2 className="text-xl font-extrabold text-slate-900">
                    {lvl.title}
                  </h2>
                  {isUnlocked && (
                    <span className="text-sm font-extrabold text-emerald-700">
                      {isCompleted ? 'مراجعة' : 'ابدأ ←'}
                    </span>
                  )}
                </div>
              </button>
            );
          })}

          {/* 8th Card: Lost Treasure Chest */}
          <button
            type="button"
            disabled={!allCompleted}
            onClick={() => {
              if (!allCompleted) return;
              audioEngine.playBadgeFanfare();
              onOpenVictory();
            }}
            className={`group relative text-right rounded-3xl border-3 overflow-hidden transition-all flex flex-col ${
              allCompleted
                ? 'border-amber-500 bg-amber-50 shadow-xl ring-4 ring-amber-200 hover:-translate-y-1 cursor-pointer'
                : 'border-dashed border-slate-300 bg-slate-100 opacity-75 cursor-not-allowed'
            }`}
          >
            <div className="relative w-full aspect-[4/3] overflow-hidden bg-slate-900">
              <img
                src={
                  allCompleted
                    ? GAME_IMAGES.treasureOpen
                    : GAME_IMAGES.heroMosqueStart
                }
                alt="صندوق الكنز"
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover ${
                  allCompleted ? 'group-hover:scale-105' : 'grayscale-[50%] brightness-75'
                }`}
              />
              <span
                className={`absolute top-3 right-3 w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg border-2 border-white ${
                  allCompleted
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-800 text-slate-200'
                }`}
              >
                <Trophy className="w-6 h-6" />
              </span>

              {!allCompleted && (
                <span className="absolute top-3 left-3 w-11 h-11 rounded-2xl bg-slate-900/85 text-white flex items-center justify-center shadow">
                  <Lock className="w-5 h-5" />
                </span>
              )}
            </div>

            <div className="p-4 w-full flex items-center justify-between">
              <h2 className="text-xl font-extrabold text-slate-900">
                صندوق الكنز
              </h2>
              <span className="text-sm font-extrabold text-amber-700">
                {allCompleted ? 'افتح الكنز!' : 'بعد ٧ محطات'}
              </span>
            </div>
          </button>
        </div>

        {/* Simple 7 Badges Strip */}
        <section className="rounded-3xl bg-white border-2 border-slate-200 p-5 space-y-3">
          <h3 className="text-lg font-extrabold text-slate-900">
            شارات الأبطال
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {LEVELS.map((lvl) => {
              const earned = progress.earnedBadges.includes(lvl.badge.id);
              return (
                <div
                  key={lvl.badge.id}
                  className={`rounded-2xl border-2 p-3 text-center space-y-2 ${
                    earned
                      ? 'border-amber-300 bg-amber-50'
                      : 'border-slate-200 bg-slate-50 opacity-50'
                  }`}
                >
                  <div
                    className={`w-12 h-12 mx-auto rounded-2xl flex items-center justify-center text-white ${
                      earned
                        ? `bg-gradient-to-br ${lvl.badge.colorClass}`
                        : 'bg-slate-300'
                    }`}
                  >
                    <Award className="w-7 h-7" />
                  </div>
                  <p className="text-sm font-extrabold text-slate-900">
                    {lvl.badge.title}
                  </p>
                </div>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
};
