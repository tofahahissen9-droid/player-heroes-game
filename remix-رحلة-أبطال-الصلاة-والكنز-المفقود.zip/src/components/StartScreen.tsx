import React, { useEffect, useState } from 'react';
import {
  Play,
  HelpCircle,
  Volume2,
  VolumeX,
  BookOpen,
  Gamepad2,
  Trophy,
  X,
} from 'lucide-react';
import { GAME_IMAGES } from '../data/assets';
import { CharacterAvatar } from './CharacterAvatar';
import { SpeakerButton } from './SpeakerButton';
import { audioEngine } from '../utils/audioEngine';

interface StartScreenProps {
  soundEnabled: boolean;
  hasSavedProgress: boolean;
  onToggleSound: () => void;
  onStartJourney: () => void;
  onContinueMap: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  soundEnabled,
  hasSavedProgress,
  onToggleSound,
  onStartJourney,
  onContinueMap,
}) => {
  const [showInstructions, setShowInstructions] = useState(false);

  const mainTrackId = hasSavedProgress ? 'start_main_continue' : 'start_main';

  useEffect(() => {
    audioEngine.warmUpShortFeedback();
    audioEngine.prefetchTracks([mainTrackId, 'start_instructions']);
  }, [mainTrackId]);

  useEffect(() => {
    return () => {
      audioEngine.stopSpeech();
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#FAF8F2] bg-islamic-pattern flex flex-col">
      {/* Calm uncluttered top bar */}
      <header className="w-full max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
        <span className="text-xl md:text-2xl font-extrabold text-emerald-900 whitespace-nowrap">
          أبطال الصلاة
        </span>

        <div className="flex items-center gap-3 shrink-0">
          {!showInstructions && (
            <SpeakerButton
              trackId={mainTrackId}
              speaker="adam"
              label="اسمع"
              variant="emerald"
            />
          )}

          <button
            type="button"
            onClick={() => {
              audioEngine.stopSpeech();
              audioEngine.playClick();
              setShowInstructions(true);
            }}
            aria-label="التعليمات"
            className="w-13 h-13 rounded-2xl bg-white border-2 border-slate-200 hover:bg-slate-50 flex items-center justify-center text-sky-600 shadow-xs cursor-pointer"
          >
            <HelpCircle className="w-7 h-7" />
          </button>

          <button
            type="button"
            onClick={onToggleSound}
            aria-label={soundEnabled ? 'إيقاف الصوت' : 'تشغيل الصوت'}
            className="w-13 h-13 rounded-2xl bg-white border-2 border-slate-200 hover:bg-slate-50 flex items-center justify-center shadow-xs cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-7 h-7 text-emerald-600" />
            ) : (
              <VolumeX className="w-7 h-7 text-slate-400" />
            )}
          </button>
        </div>
      </header>

      {/* Main Visual Hero Stage */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 md:px-8 py-4 flex flex-col items-center justify-center gap-6">
        {/* Giant 3D Cartoon Illustration */}
        <div className="relative w-full rounded-3xl overflow-hidden border-4 border-amber-300 shadow-2xl bg-slate-900">
          <img
            src={GAME_IMAGES.heroMosqueStart}
            alt="مسجد جميل وصندوق الكنز الذهبي مع آدم ونور"
            referrerPolicy="no-referrer"
            className="w-full h-[300px] sm:h-[400px] object-cover"
          />

          {/* Large Adam & Noor Portraits at bottom corner */}
          <div className="absolute bottom-4 right-4 flex items-center gap-3 bg-white/95 backdrop-blur rounded-3xl p-2.5 border-2 border-emerald-200 shadow-lg">
            <CharacterAvatar character="adam" size="lg" />
            <CharacterAvatar character="noor" size="lg" />
          </div>
        </div>

        {/* ONE Short Simple Sentence Under Picture */}
        <div className="text-center space-y-2 max-w-2xl">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
            أبطال الصلاة والكنز
          </h1>
          <p className="text-xl sm:text-2xl font-bold text-emerald-800">
            يلا نتعلم الوضوء والصلاة مع آدم ونور!
          </p>
        </div>

        {/* Large Friendly Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pb-4">
          <button
            type="button"
            onClick={() => {
              audioEngine.playClick();
              onStartJourney();
            }}
            className="btn-3d inline-flex items-center justify-center gap-3 px-10 py-5 rounded-3xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-2xl shadow-[0_6px_0_#047857] cursor-pointer"
          >
            <Play className="w-8 h-8 fill-white" />
            <span>ابدأ الرحلة</span>
          </button>

          {hasSavedProgress && (
            <button
              type="button"
              onClick={() => {
                audioEngine.playClick();
                onContinueMap();
              }}
              className="btn-3d inline-flex items-center justify-center gap-3 px-8 py-5 rounded-3xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-2xl shadow-[0_6px_0_#B45309] cursor-pointer"
            >
              <span>كمل المغامرة</span>
            </button>
          )}
        </div>
      </main>

      {/* Simple Visual Instructions Modal */}
      {showInstructions && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="instructions-title"
        >
          <div className="bg-white rounded-3xl border-4 border-sky-200 max-w-lg w-full p-6 md:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between gap-2">
              <h2
                id="instructions-title"
                className="text-2xl font-extrabold text-slate-900"
              >
                إزاي نلعب؟
              </h2>
              <div className="flex items-center gap-2">
                <SpeakerButton
                  trackId="start_instructions"
                  speaker="adam"
                  label="اسمع"
                  variant="sky"
                />
                <button
                  type="button"
                  onClick={() => {
                    audioEngine.stopSpeech();
                    setShowInstructions(false);
                  }}
                  className="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
                  aria-label="إغلاق"
                >
                  <X className="w-6 h-6 text-slate-700" />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-4 rounded-2xl bg-emerald-50 border-2 border-emerald-200 p-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <BookOpen className="w-7 h-7" />
                </div>
                <p className="text-lg font-extrabold text-slate-900">
                  ١. اتفرج على الصورة واسمع الشرح
                </p>
              </div>

              <div className="flex items-center gap-4 rounded-2xl bg-sky-50 border-2 border-sky-200 p-4">
                <div className="w-14 h-14 rounded-2xl bg-sky-600 text-white flex items-center justify-center shrink-0">
                  <Gamepad2 className="w-7 h-7" />
                </div>
                <p className="text-lg font-extrabold text-slate-900">
                  ٢. العب ألعاب سهلة بالصور
                </p>
              </div>

              <div className="flex items-center gap-4 rounded-2xl bg-amber-50 border-2 border-amber-200 p-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0">
                  <Trophy className="w-7 h-7" />
                </div>
                <p className="text-lg font-extrabold text-slate-900">
                  ٣. اجمع الشارات وافتح الكنز!
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                audioEngine.stopSpeech();
                setShowInstructions(false);
              }}
              className="btn-3d w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xl shadow-[0_5px_0_#047857] cursor-pointer"
            >
              فهمت! يلا نبدأ
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
