import { SpeakerId } from '../types/game';
import { getAudioSrc } from '../data/audioManifest';

class AudioEngine {
  private soundEnabled = true;
  private audioCtx: AudioContext | null = null;
  private currentAudio: HTMLAudioElement | null = null;
  private sequenceToken = 0;
  private activePlayId: string | null = null;
  private loadingPlayId: string | null = null;

  // Preloaded static MP3 Blob URLs for instant zero-latency playback (no external AI calls)
  private readyBlobUrls = new Map<string, string>();
  private inFlightLoads = new Map<string, Promise<string | null>>();

  private speakingListeners = new Set<
    (state: {
      speaker: SpeakerId | null;
      playId: string | null;
      loadingPlayId: string | null;
    }) => void
  >();
  private errorListeners = new Set<
    (err: { playId: string | null; code: string; message: string } | null) => void
  >();

  // Calm ambient background music nodes
  private musicMasterGain: GainNode | null = null;
  private musicIntervalId: number | null = null;
  private musicRunning = false;
  private musicStep = 0;

  private readonly MUSIC_NORMAL_GAIN = 0.022;
  private readonly MUSIC_DUCKED_GAIN = 0.005;

  public isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  public setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
    if (!enabled) {
      this.stopSpeech();
      this.stopBackgroundMusic();
    } else {
      this.ensureBackgroundMusic();
    }
  }

  public subscribeSpeaking(
    cb: (
      speaker: SpeakerId | null,
      playId?: string | null,
      loadingPlayId?: string | null
    ) => void
  ): () => void {
    const wrapped = (state: {
      speaker: SpeakerId | null;
      playId: string | null;
      loadingPlayId: string | null;
    }) => cb(state.speaker, state.playId, state.loadingPlayId);
    this.speakingListeners.add(wrapped);
    return () => {
      this.speakingListeners.delete(wrapped);
    };
  }

  public subscribeError(
    cb: (err: { playId: string | null; code: string; message: string } | null) => void
  ): () => void {
    this.errorListeners.add(cb);
    return () => {
      this.errorListeners.delete(cb);
    };
  }

  private notifyError(
    err: { playId: string | null; code: string; message: string } | null
  ): void {
    this.errorListeners.forEach((cb) => cb(err));
  }

  private notifySpeaking(
    speaker: SpeakerId | null,
    playId: string | null = null,
    loadingPlayId: string | null = null
  ): void {
    this.activePlayId = playId;
    this.loadingPlayId = loadingPlayId;
    this.speakingListeners.forEach((cb) =>
      cb({ speaker, playId, loadingPlayId })
    );
    this.setMusicDucked(speaker !== null || loadingPlayId !== null);
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (Ctx) {
        this.audioCtx = new Ctx();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  private setMusicDucked(ducked: boolean): void {
    if (!this.audioCtx || !this.musicMasterGain) return;
    const now = this.audioCtx.currentTime;
    const target = !this.soundEnabled
      ? 0.0001
      : ducked
      ? this.MUSIC_DUCKED_GAIN
      : this.MUSIC_NORMAL_GAIN;
    this.musicMasterGain.gain.cancelScheduledValues(now);
    this.musicMasterGain.gain.setTargetAtTime(target, now, ducked ? 0.1 : 0.45);
  }

  public ensureBackgroundMusic(): void {
    if (!this.soundEnabled || this.musicRunning) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    this.musicRunning = true;
    const master = ctx.createGain();
    master.gain.setValueAtTime(this.MUSIC_NORMAL_GAIN, ctx.currentTime);

    const warmFilter = ctx.createBiquadFilter();
    warmFilter.type = 'lowpass';
    warmFilter.frequency.setValueAtTime(620, ctx.currentTime);
    warmFilter.Q.setValueAtTime(0.7, ctx.currentTime);

    master.connect(warmFilter);
    warmFilter.connect(ctx.destination);
    this.musicMasterGain = master;

    const melodyHz = [
      293.66, 349.23, 392.0, 440.0, 392.0, 349.23,
      293.66, 329.63, 349.23, 440.0, 523.25, 440.0,
    ];
    const bassHz = [146.83, 146.83, 174.61, 174.61, 196.0, 146.83];

    const scheduleBeat = () => {
      if (!this.soundEnabled || !this.audioCtx || !this.musicMasterGain) return;
      const now = this.audioCtx.currentTime;

      const noteFreq = melodyHz[this.musicStep % melodyHz.length];
      const osc = this.audioCtx.createOscillator();
      const noteGain = this.audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(noteFreq, now);

      noteGain.gain.setValueAtTime(0.0001, now);
      noteGain.gain.linearRampToValueAtTime(0.45, now + 0.08);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);

      osc.connect(noteGain);
      noteGain.connect(this.musicMasterGain);
      osc.start(now);
      osc.stop(now + 2.3);

      if (this.musicStep % 2 === 0) {
        const bFreq = bassHz[Math.floor(this.musicStep / 2) % bassHz.length];
        const padOsc = this.audioCtx.createOscillator();
        const padGain = this.audioCtx.createGain();
        padOsc.type = 'triangle';
        padOsc.frequency.setValueAtTime(bFreq, now);

        padGain.gain.setValueAtTime(0.0001, now);
        padGain.gain.linearRampToValueAtTime(0.28, now + 0.6);
        padGain.gain.exponentialRampToValueAtTime(0.0001, now + 3.6);

        padOsc.connect(padGain);
        padGain.connect(this.musicMasterGain);
        padOsc.start(now);
        padOsc.stop(now + 3.7);
      }

      this.musicStep += 1;
    };

    scheduleBeat();
    this.musicIntervalId = window.setInterval(scheduleBeat, 1450);
  }

  public stopBackgroundMusic(): void {
    if (this.musicIntervalId !== null) {
      window.clearInterval(this.musicIntervalId);
      this.musicIntervalId = null;
    }
    if (this.musicMasterGain && this.audioCtx) {
      try {
        this.musicMasterGain.gain.setTargetAtTime(
          0.0001,
          this.audioCtx.currentTime,
          0.08
        );
      } catch {
        // Ignore cleanup errors
      }
    }
    this.musicMasterGain = null;
    this.musicRunning = false;
  }

  private playGentleTone(
    freq: number,
    durationSec: number,
    delaySec = 0,
    gainPeak = 0.08,
    cutoffHz = 1400
  ): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime + delaySec;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoffHz, now);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + durationSec + 0.03);
  }

  public playClick(): void {
    this.ensureBackgroundMusic();
    this.playGentleTone(480, 0.08, 0, 0.045, 950);
  }

  public playCorrect(): void {
    this.ensureBackgroundMusic();
    this.playGentleTone(523.25, 0.24, 0, 0.075, 1600);
    this.playGentleTone(659.25, 0.26, 0.09, 0.075, 1700);
    this.playGentleTone(783.99, 0.34, 0.18, 0.08, 1800);
  }

  public playTryAgain(): void {
    this.ensureBackgroundMusic();
    this.playGentleTone(349.23, 0.18, 0, 0.05, 800);
    this.playGentleTone(329.63, 0.24, 0.12, 0.045, 750);
  }

  public playWaterDrop(): void {
    this.ensureBackgroundMusic();
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(760, now + 0.11);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.065, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playBadgeFanfare(): void {
    this.ensureBackgroundMusic();
    const notes = [523.25, 659.25, 783.99, 987.77, 1046.5];
    notes.forEach((n, idx) => {
      this.playGentleTone(n, 0.48, idx * 0.11, 0.07, 1800);
    });
  }

  private loadStaticAudioUrl(trackId: string): Promise<string | null> {
    if (typeof window === 'undefined') return Promise.resolve(null);
    const cached = this.readyBlobUrls.get(trackId);
    if (cached) return Promise.resolve(cached);

    const existing = this.inFlightLoads.get(trackId);
    if (existing) return existing;

    const src = getAudioSrc(trackId);
    const promise = fetch(src)
      .then(async (res) => {
        if (!res.ok) return null;
        const ctype = (res.headers.get('content-type') || '').toLowerCase();
        if (ctype && !ctype.startsWith('audio/') && !ctype.includes('octet-stream')) {
          return null;
        }
        const blob = await res.blob();
        if (blob.size < 400) return null;
        const url = URL.createObjectURL(blob);
        this.readyBlobUrls.set(trackId, url);
        return url;
      })
      .catch(() => null)
      .finally(() => {
        this.inFlightLoads.delete(trackId);
      });

    this.inFlightLoads.set(trackId, promise);
    return promise;
  }

  public prefetchTrack(trackId: string): void {
    if (!trackId) return;
    void this.loadStaticAudioUrl(trackId);
  }

  public prefetchTracks(trackIds: string[]): void {
    for (const id of trackIds) {
      if (id) void this.loadStaticAudioUrl(id);
    }
  }

  public warmUpShortFeedback(): void {
    this.prefetchTracks(['feedback_bravo', 'feedback_retry']);
  }

  public speakShortFeedback(kind: 'bravo' | 'retry'): void {
    if (!this.soundEnabled) return;
    const trackId = kind === 'bravo' ? 'feedback_bravo' : 'feedback_retry';
    void this.playTrack(trackId, 'adam', trackId);
  }

  public stopSpeech(): void {
    this.sequenceToken += 1;
    if (this.currentAudio) {
      const prev = this.currentAudio;
      this.currentAudio = null;
      prev.onended = null;
      prev.onerror = null;
      try {
        prev.pause();
        prev.currentTime = 0;
        prev.removeAttribute('src');
      } catch {
        // Ignore cleanup errors
      }
    }
    this.notifySpeaking(null, null, null);
  }

  public getActivePlayId(): string | null {
    return this.activePlayId;
  }

  public getLoadingPlayId(): string | null {
    return this.loadingPlayId;
  }

  public async playTrack(
    trackId: string,
    speaker: SpeakerId = 'adam',
    playId?: string
  ): Promise<void> {
    const resolvedId = playId || trackId;
    if (!this.soundEnabled) {
      this.notifyError({
        playId: resolvedId,
        code: 'sound_muted',
        message: 'الصوت مقفول دلوقتي، افتح الصوت عشان تسمع.',
      });
      return;
    }

    this.ensureBackgroundMusic();
    this.stopSpeech();
    this.notifyError(null);

    const myToken = ++this.sequenceToken;

    let playUrl = this.readyBlobUrls.get(trackId) || null;
    if (!playUrl) {
      // Fall back to direct static MP3 URL immediately while caching Blob in background
      void this.loadStaticAudioUrl(trackId);
      playUrl = getAudioSrc(trackId);
    }

    if (myToken !== this.sequenceToken || !this.soundEnabled) return;

    this.notifySpeaking(speaker, resolvedId, null);
    const ok = await this.playAudioUrl(playUrl, myToken);

    if (!ok && myToken === this.sequenceToken) {
      this.notifyError({
        playId: resolvedId,
        code: 'audio_load_failed',
        message: 'تعذر تشغيل ملف الصوت، حاول مرة أخرى.',
      });
    }

    if (myToken === this.sequenceToken) {
      this.notifySpeaking(null, null, null);
    }
  }

  public async replayTrack(
    trackId: string,
    speaker: SpeakerId = 'adam',
    playId?: string
  ): Promise<void> {
    await this.playTrack(trackId, speaker, playId);
  }

  private playAudioUrl(url: string, token: number): Promise<boolean> {
    return new Promise((resolve) => {
      if (token !== this.sequenceToken || !this.soundEnabled) {
        resolve(true);
        return;
      }

      const audio = new Audio(url);
      audio.volume = 1.0;
      audio.preload = 'auto';
      this.currentAudio = audio;

      let settled = false;
      const finish = (ok: boolean) => {
        if (settled) return;
        settled = true;
        audio.onended = null;
        audio.onerror = null;
        if (this.currentAudio === audio) {
          this.currentAudio = null;
        }
        resolve(ok);
      };

      audio.onended = () => finish(true);
      audio.onerror = () => finish(false);
      audio.play().catch(() => finish(false));
    });
  }
}

export const audioEngine = new AudioEngine();
