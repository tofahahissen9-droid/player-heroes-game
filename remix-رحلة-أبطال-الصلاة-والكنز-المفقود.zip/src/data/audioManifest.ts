import { LEVELS } from './gameContent';
import { LessonCard, QuizQuestion, ActivityConfig } from '../types/game';

export interface AudioTrackEntry {
  id: string;
  src: string;
  text: string;
}

const WUDU_SIM_SCRIPTS = [
  { id: 'niyyah', title: 'النية وبسم الله', shortNote: 'انْوِ في قلبك وقول: بِسْمِ اللَّهِ.', ruling: 'فرض' },
  { id: 'hands', title: 'غسل الكفين', shortNote: 'اغسل إيديك ٣ مرات.', ruling: 'سنة' },
  { id: 'mouth', title: 'المضمضة', shortNote: 'تمضمض بالمية ٣ مرات.', ruling: 'سنة' },
  { id: 'nose', title: 'الاستنشاق', shortNote: 'اغسل أنفك بالمية براحة ٣ مرات.', ruling: 'سنة' },
  { id: 'face', title: 'غسل الوجه', shortNote: 'اغسل وشك كله ٣ مرات.', ruling: 'فرض' },
  { id: 'right_arm', title: 'اليد اليمنى للمرفق', shortNote: 'اغسل إيدك اليمين للمرفق ٣ مرات.', ruling: 'فرض' },
  { id: 'left_arm', title: 'اليد اليسرى للمرفق', shortNote: 'اغسل إيدك الشمال للمرفق ٣ مرات.', ruling: 'فرض' },
  { id: 'head', title: 'مسح الرأس', shortNote: 'امسح رأسك بالمية مرة واحدة.', ruling: 'فرض' },
  { id: 'ears', title: 'مسح الأذنين', shortNote: 'امسح ودانك مرة واحدة.', ruling: 'سنة' },
  { id: 'right_foot', title: 'الرجل اليمنى للكعبين', shortNote: 'اغسل رجلك اليمين للكعبين ٣ مرات.', ruling: 'فرض' },
  { id: 'left_foot', title: 'الرجل اليسرى للكعبين', shortNote: 'اغسل رجلك الشمال للكعبين ٣ مرات.', ruling: 'فرض' },
];

const PRAYER_MOVES_SCRIPTS = [
  {
    title: 'الركوع',
    dhikr: 'سُبْحَانَ رَبِّيَ الْعَظِيمِ',
    shortNote: 'ننحني بظهر مفرود ونقول: سبحان ربي العظيم.',
  },
  {
    title: 'الاعتدال من الركوع',
    dhikr: 'سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ، رَبَّنَا وَلَكَ الْحَمْدُ',
    shortNote: 'نقف معتدلين ونقول: سمع الله لمن حمده.',
  },
  {
    title: 'السجدة الأولى',
    dhikr: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
    shortNote: 'نسجد على الأرض ونقول: سبحان ربي الأعلى.',
  },
  {
    title: 'الجلوس بين السجدتين',
    dhikr: 'رَبِّ اغْفِرْ لِي',
    shortNote: 'نجلس بهدوء ونقول: رب اغفر لي.',
  },
  {
    title: 'السجدة الثانية',
    dhikr: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
    shortNote: 'نسجد السجدة التانية ونقول: سبحان ربي الأعلى.',
  },
];

function getLessonVisualWrittenText(lesson: LessonCard): string {
  switch (lesson.visualType) {
    case 'five_prayers':
      return '١ الفجر ٢ ركعة. ٢ الظهر ٤ ركعات. ٣ العصر ٤ ركعات. ٤ المغرب ٣ ركعات. ٥ العشاء ٤ ركعات.';
    case 'prayer_time_single':
      return lesson.visualData?.prayerName ? `${lesson.visualData.prayerName}.` : '';
    case 'prayer_prep_single':
      if (lesson.visualData?.prepKind === 'awrah') {
        return 'ثوب نظيف. حجاب ولبس محتشم.';
      }
      if (lesson.visualData?.prepKind === 'qiblah') {
        return 'نحو الكعبة.';
      }
      return '';
    case 'wudu_intro':
      return 'ماء طهور.';
    case 'wudu_fard_sunnah':
      return 'الفروض أساسية: النية، الوجه، اليدين للمرفق، مسح الرأس، الرجلين للكعب، الترتيب. والسنن ثواب أكبر: بسم الله، الكفين ٣ مرات، المضمضة، الاستنشاق، الأذنين، اليمين أولًا.';
    case 'wudu_step': {
      const parts: string[] = [];
      if (lesson.badgeTag) parts.push(`${lesson.badgeTag}.`);
      if (lesson.repeatCount) {
        parts.push(
          lesson.repeatCount === 1 ? 'مرة واحدة.' : `${lesson.repeatCount} مرات.`
        );
      }
      return parts.join(' ');
    }
    case 'wudu_order_summary':
      return `١ الوجه. ٢ اليدين. ٣ الرأس. ٤ الرجلين.${
        lesson.dhikrPhrase ? ` ${lesson.dhikrPhrase}.` : ''
      }`;
    case 'prayer_pose':
      return lesson.dhikrPhrase ? `${lesson.dhikrPhrase}.` : '';
    case 'rakaat_summary': {
      const vd = lesson.visualData;
      if (!vd) return '';
      const rText = vd.rakaatCount === 2 ? 'ركعتان' : `${vd.rakaatCount} ركعات`;
      return `${vd.prayerName}. ${rText}. ${vd.sajdahCount} سجدات. ${vd.recitationMode}.`;
    }
    case 'rakaat_detail': {
      const dk = lesson.visualData?.detailKind;
      if (dk === 'first_two_surah') return '١: الفاتحة وسورة. ٢: الفاتحة وسورة.';
      if (dk === 'first_tashahhud') return '١، ٢، ثم التشهد.';
      if (dk === 'last_two_fatiha') return '٣: الفاتحة فقط. ٤: الفاتحة فقط.';
      if (dk === 'third_fatiha') return '٣: الفاتحة فقط.';
      if (dk === 'isha_flow')
        return '١ و٢ جهرية. تشهد ١ بعد ٢. ٣ و٤ الفاتحة فقط. تسليم يمين ويسار.';
      return '';
    }
    case 'prayer_compare':
      return 'الفجر ٢ ركعة، صوت مسموع. العصر ٤ ركعات، سرية في القلب.';
    default:
      return '';
  }
}

function buildLessonText(
  lesson: LessonCard,
  index: number,
  total: number,
  isLast: boolean
): string {
  const parts = [
    `${index + 1} من ${total}.`,
    `${lesson.title}.`,
    getLessonVisualWrittenText(lesson),
    lesson.shortSentence,
    lesson.narration,
    isLast ? 'يلا نلعب!' : 'التالي.',
  ];
  return parts.filter(Boolean).join(' ');
}

function buildQuizAskText(q: QuizQuestion, idx: number, total: number): string {
  const parts = [`سؤال ${idx + 1} من ${total}.`, q.prompt];
  if (q.kind === 'mcq') {
    parts.push(q.options.join(' ... '));
  } else if (q.kind === 'true_false') {
    parts.push('صح ... غلط.');
  } else if (q.kind === 'image_choice') {
    parts.push(q.options.map((o) => o.label).join(' ... '));
  } else if (q.kind === 'order_mini') {
    parts.push(`${q.items.map((i) => i.label).join(' ... ')}. تأكيد الإجابة.`);
  } else if (q.kind === 'match_mini') {
    const rightOptions = [...q.pairs]
      .map((p) => p.right)
      .sort((a, b) => a.localeCompare(b, 'ar'));
    parts.push(
      `الصور: ${q.pairs.map((p) => p.left).join('، ')}. الاختيارات: ${rightOptions.join('، ')}. تأكيد التوصيل.`
    );
  }
  return parts.join(' ');
}

function addActivityTracks(act: ActivityConfig, tracks: AudioTrackEntry[]): void {
  const add = (id: string, text: string) => {
    tracks.push({ id, src: `/audio/${id}.mp3`, text });
  };

  if (act.type === 'image_select') {
    const opts = act.options.map((o) => o.label).join(' ... ');
    add(`act_${act.id}`, `${act.title}. ${act.instruction} الاختيارات: ${opts}.`);
  } else if (act.type === 'matching') {
    const shuffledRight = [...act.pairs]
      .sort((a, b) => a.rightLabel.localeCompare(b.rightLabel, 'ar'))
      .map((p) => p.rightLabel)
      .join('، ');
    const lefts = act.pairs.map((p) => p.leftLabel).join('، ');
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} على اليمين: ${lefts}. على الشمال: ${shuffledRight}.`
    );
  } else if (act.type === 'ordering') {
    const labels = [...act.items]
      .reverse()
      .map((i) => i.label)
      .join(' ... ');
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} ${labels}. تأكيد الترتيب.`
    );
  } else if (act.type === 'hotspot_discovery') {
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} اضغط على الدوائر المرقمة على الصورة!`
    );
    for (const spot of act.hotspots) {
      add(
        `act_${act.id}_${spot.id}`,
        `${act.title}. ${act.instruction} ${spot.title}${
          spot.rulingTag ? ` (${spot.rulingTag})` : ''
        }. ${spot.description}`
      );
    }
  } else if (act.type === 'true_false_multi') {
    act.statements.forEach((stmt, idx) => {
      add(
        `act_${act.id}_s${idx}`,
        `${act.title}. ${act.instruction} ${idx + 1} من ${
          act.statements.length
        }. ${stmt.text}. صح أم غلط؟`
      );
    });
  } else if (act.type === 'wudu_simulator') {
    WUDU_SIM_SCRIPTS.forEach((step, stepIdx) => {
      const others = WUDU_SIM_SCRIPTS.filter((s) => s.id !== step.id);
      const distractors = [
        others[(stepIdx + 2) % others.length],
        others[(stepIdx + 5) % others.length],
      ];
      const combined = [step, ...distractors].sort(
        (a, b) =>
          ((a.id.charCodeAt(0) + stepIdx * 7) % 11) -
          ((b.id.charCodeAt(0) + stepIdx * 7) % 11)
      );
      const choiceText = combined
        .map((c) => `${c.title} (${c.ruling})`)
        .join(' ... ');
      add(
        `wudu_sim_pick_${stepIdx}`,
        `${act.title}. ${act.instruction} الخطوة ${stepIdx + 1} من ${
          WUDU_SIM_SCRIPTS.length
        }. آدم هيعمل إيه دلوقتي؟ اختار الصورة الصح: ${choiceText}.`
      );
      const actionLabel =
        step.id === 'niyyah'
          ? 'قول بسم الله.'
          : step.id === 'head' || step.id === 'ears'
          ? 'اضغط للمسح.'
          : 'اضغط للغسل بالمية.';
      add(
        `wudu_sim_wash_${stepIdx}`,
        `${act.title}. ${act.instruction} الخطوة ${stepIdx + 1} من ${
          WUDU_SIM_SCRIPTS.length
        }. ${step.title}. ${step.shortNote} ${actionLabel}`
      );
    });
    add(
      'wudu_sim_done',
      `برافو عليك! أتممت الوضوء مع آدم! أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. ${act.successMessage}`
    );
  } else if (act.type === 'spot_error') {
    const stepsText = act.steps.map((s) => s.label).join(' ... ');
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} ${act.scenarioTitle}. ${stepsText}.`
    );
  } else if (act.type === 'memory_cards') {
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} اقلب الكروت وطابق كل اتنين زي بعض.`
    );
  } else if (act.type === 'prayer_builder') {
    add(
      `pb_${act.prayerId}_takbeer`,
      `${act.title}. ${act.instruction} يلا نبدأ ${act.prayerName}! ارفع إيديك وقول: اللَّهُ أَكْبَرُ. الله أكبر، ابدأ الصلاة.`
    );
    for (let r = 1; r <= act.targetRakaat; r++) {
      add(
        `pb_${act.prayerId}_recite_r${r}`,
        `${act.prayerName}. الركعة ${r} من ${act.targetRakaat}: نقرأ إيه وبأنهي صوت؟ الفاتحة وسورة بصوت مسموع جهرًا. الفاتحة وسورة بصوت هادي سرًا. الفاتحة فقط بصوت هادي سرًا.`
      );
    }
    PRAYER_MOVES_SCRIPTS.forEach((m, mIdx) => {
      add(
        `pb_${act.prayerId}_move_${mIdx}`,
        `${act.prayerName}. ${m.title}. ${m.dhikr}. ${m.shortNote} الحركة التالية.`
      );
    });
    const tashahhudRakaats =
      act.targetRakaat > 2 ? [2, act.targetRakaat] : [act.targetRakaat];
    for (const r of tashahhudRakaats) {
      add(
        `pb_${act.prayerId}_tashahhud_r${r}`,
        `${act.prayerName}. خلصنا الركعة ${r}! نعمل إيه دلوقتي؟ التشهد الأول بس، ونقوم للركعة اللي بعدها. التشهد الأخير والصلاة الإبراهيمية والتسليم.`
      );
    }
    add(
      `pb_${act.prayerId}_done`,
      `برافو عليك! تقبل الله ${act.prayerName}! السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ يمين وشمال. ${act.successMessage}`
    );
  } else if (act.type === 'treasure_lock') {
    const dialsText = act.dials
      .map((d) => `${d.label}: ${d.options.join('، ')}`)
      .join('. ');
    add(
      `act_${act.id}`,
      `${act.title}. ${act.instruction} أقفال الكنز الذهبية. اختار الإجابة الصح لكل قفل. ${dialsText}. افتح القفل الذهبي.`
    );
  }

  // Activity completed track (used after non-simulator/non-pb activities succeed)
  if (act.type !== 'wudu_simulator' && act.type !== 'prayer_builder') {
    add(`act_${act.id}_done`, `${act.title}. ${act.successMessage}`);
  }
}

export function buildAllAudioTracks(): AudioTrackEntry[] {
  const tracks: AudioTrackEntry[] = [];
  const add = (id: string, text: string) => {
    tracks.push({ id, src: `/audio/${id}.mp3`, text });
  };

  // 1. Start Screen + Instructions Modal
  add(
    'start_main',
    'أبطال الصلاة. أبطال الصلاة والكنز. يلا نتعلم الوضوء والصلاة مع آدم ونور! ابدأ الرحلة.'
  );
  add(
    'start_main_continue',
    'أبطال الصلاة. أبطال الصلاة والكنز. يلا نتعلم الوضوء والصلاة مع آدم ونور! ابدأ الرحلة. كمل المغامرة.'
  );
  add(
    'start_instructions',
    'إزاي نلعب؟ ١. اتفرج على الصورة واسمع الشرح. ٢. العب ألعاب سهلة بالصور. ٣. اجمع الشارات وافتح الكنز! فهمت! يلا نبدأ.'
  );

  // 2. Intro Dialogue Slides
  add(
    'intro_step_0',
    'آدم. أهلًا بيكم! يلا نبدأ رحلة جميلة مع بعض. التالي.'
  );
  add(
    'intro_step_1',
    'نور. هنتعلم الوضوء والصلاة خطوة بخطوة عشان نفتح الكنز! افتح الخريطة.'
  );

  // 3. Adventure Map States (unlocked 1..7 + all_done)
  const allBadgeTitles = LEVELS.map((l) => l.badge.title).join('، ');
  for (let unlocked = 1; unlocked <= 7; unlocked++) {
    const nextTitle = LEVELS[unlocked - 1]?.title || '';
    const stations = LEVELS.map((lvl) => {
      const state =
        lvl.id < unlocked ? 'خلصت' : lvl.id === unlocked ? 'مفتوحة' : 'مقفولة';
      return `${lvl.id}. ${lvl.title} (${state})`;
    }).join('. ');
    add(
      `map_state_${unlocked}`,
      `خريطة الرحلة. المحطة الجاية: ${nextTitle}. اضغط على الصورة عشان نبدأ! ${stations}. صندوق الكنز، بعد ٧ محطات. شارات الأبطال: ${allBadgeTitles}.`
    );
  }
  const allDoneStations = LEVELS.map(
    (lvl) => `${lvl.id}. ${lvl.title} (خلصت)`
  ).join('. ');
  add(
    'map_state_all_done',
    `خريطة الرحلة. برافو عليك! خلصت كل المحطات! افتح الكنز! ${allDoneStations}. صندوق الكنز، افتح الكنز! شارات الأبطال: ${allBadgeTitles}.`
  );

  // 4. All 7 Levels: Intro, Lessons, Activities, Quiz
  for (const level of LEVELS) {
    const introDialogueText = level.introDialogue.map((d) => d.text).join(' ');
    add(
      `level_${level.id}_intro`,
      `${level.id}. ${level.title}. المحطة ${level.id} من ٧. ${level.shortIntro} ${introDialogueText} يلا نبدأ!`
    );

    // Lessons
    level.lessons.forEach((lesson, idx) => {
      const isLast = idx === level.lessons.length - 1;
      add(
        `lesson_${lesson.id}`,
        buildLessonText(lesson, idx, level.lessons.length, isLast)
      );
    });

    // Activities
    for (const act of level.activities) {
      addActivityTracks(act, tracks);
    }

    // Quiz questions
    level.quiz.forEach((q, qIdx) => {
      const nextBtn =
        qIdx + 1 < level.quiz.length ? 'السؤال اللي بعده.' : 'شوف النتيجة.';
      add(
        `quiz_${q.id}_ask`,
        buildQuizAskText(q, qIdx, level.quiz.length)
      );
      add(
        `quiz_${q.id}_correct`,
        `برافو عليك! ${q.explanation} ${nextBtn}`
      );
      add(
        `quiz_${q.id}_wrong`,
        `قربت يا بطل! ${q.explanation} ${nextBtn}`
      );
    });

    // Quiz Pass & Retry
    add(
      `quiz_pass_${level.id}`,
      `برافو عليك! كسبت شارة ${level.badge.title}. ${level.badge.subtitle}. رجوع للخريطة.`
    );
    add(
      `quiz_retry_${level.id}`,
      'محاولة جميلة! يلا نحاول تاني! محتاجين ٣ صح على الأقل عشان نكسب الشارة. حاول تاني.'
    );
  }

  // 5. Victory Screen
  add(
    'victory_full',
    `برافو عليك يا بطل! الكنز هو نور الصلاة! اتعلمت الوضوء والصلوات الخمس كلها، وكسبت السبع شارات الذهبية: ${allBadgeTitles}. خريطة الرحلة. العب تاني.`
  );

  // 6. Short Instant Encouragement Feedback
  add('feedback_bravo', 'برافو عليك!');
  add('feedback_retry', 'يلا نحاول تاني!');

  return tracks;
}

export function getAudioSrc(trackId: string): string {
  return `/audio/${trackId}.mp3`;
}
