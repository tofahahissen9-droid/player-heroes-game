export const GAME_IMAGES = {
  heroMosqueStart: '/src/assets/images/hero_mosque_start_1794857336751.jpg',
  adamPortrait: '/src/assets/images/char_adam_3d_1794857336511.jpg',
  noorPortrait: '/src/assets/images/char_noor_3d_1794857337938.jpg',
  wuduOasis: '/src/assets/images/station_2_wudu_oasis_1794858126685.jpg',
  wuduOasisScene: '/src/assets/images/wudu_oasis_scene_1794857338038.jpg',
  treasureOpen: '/src/assets/images/treasure_chest_open_clean_1794857355891.jpg',
  treasureCelebration: '/src/assets/images/treasure_open_celebration_1794857338537.jpg',
  lessonPrayerMeaning: '/src/assets/images/lesson_prayer_meaning_1794863541793.jpg',
  lessonWuduHands: '/src/assets/images/lesson_wudu_hands_1794863542578.jpg',
  lessonQiblahKaaba: '/src/assets/images/lesson_qiblah_kaaba_1794863543597.jpg',
  lessonNoorTeaching: '/src/assets/images/lesson_noor_teaching_1794863544380.jpg',
} as const;

export const STATION_IMAGES: Record<number, string> = {
  1: '/src/assets/images/station_1_prayer_gate_1794858126145.jpg',
  2: '/src/assets/images/station_2_wudu_oasis_1794858126685.jpg',
  3: '/src/assets/images/station_3_fajr_dawn_1794858127907.jpg',
  4: '/src/assets/images/station_4_dhuhr_palace_1794858128036.jpg',
  5: '/src/assets/images/station_5_asr_valley_1794858129236.jpg',
  6: '/src/assets/images/station_6_maghrib_garden_1794858129026.jpg',
  7: '/src/assets/images/station_7_isha_castle_1794858129324.jpg',
};
