import { spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { buildAllAudioTracks, AudioTrackEntry } from '../src/data/audioManifest.ts';

export const GEMINI_TTS_MODEL = 'gemini-3.8-flash-lite-tts';
export const GEMINI_TTS_VOICE = 'Zephyr';
export const GEMINI_TTS_STYLE_PROMPT =
  'Voice persona: A very calm, gentle, warm, patient Egyptian Arabic kindergarten teacher speaking slowly and clearly to children with learning needs. Natural human speech with soft, clear Egyptian Arabic pronunciation, relaxed unhurried pace, encouraging warmth, and smooth pauses at punctuation. Read every word accurately without skipping anything, and pronounce Quranic verses, Takbeer, Tasbeeh, and Islamic supplications clearly and respectfully. Never robotic, never rushed, never loud.';

export const AUDIO_DIR = path.resolve(process.cwd(), 'public', 'audio');
export const PROGRESS_FILE = path.resolve(process.cwd(), 'scripts', 'audio-progress.json');

export type BatchStopReason =
  | 'ready'
  | 'completed'
  | 'quota_exhausted'
  | 'batch_limit_reached'
  | 'missing_api_key'
  | 'error';

export interface AudioProgressState {
  model: string;
  voiceName: string;
  totalTracks: number;
  validCount: number;
  missingCount: number;
  invalidRemoved: string[];
  nextTrackId: string | null;
  nextTrackIndex: number | null;
  lastCompletedTrackId: string | null;
  generatedInLastRun: string[];
  stoppedReason: BatchStopReason;
  retryDelay: string | null;
  errorMessage: string | null;
  lastUpdatedAt: string;
}

export interface LibraryInspectionResult {
  allTracks: AudioTrackEntry[];
  validIds: string[];
  missingTracks: AudioTrackEntry[];
  invalidRemoved: string[];
  nextTrackIndex: number | null;
}

export function prepareSpokenText(rawText: string): string {
  return rawText
    .replace(/\s+/g, ' ')
    .replace(/([.!؟])\s+/g, '$1 ... ')
    .replace(/([،؛])\s+/g, '$1 ')
    .trim();
}

let cachedFfprobeAvailable: boolean | null = null;
function hasFfprobe(): boolean {
  if (cachedFfprobeAvailable !== null) return cachedFfprobeAvailable;
  const check = spawnSync('which', ['ffprobe'], { stdio: 'ignore' });
  cachedFfprobeAvailable = check.status === 0;
  return cachedFfprobeAvailable;
}

export function verifyMp3File(filePath: string): { valid: boolean; reason?: string } {
  if (!fs.existsSync(filePath)) {
    return { valid: false, reason: 'missing' };
  }
  const stat = fs.statSync(filePath);
  if (stat.size < 800) {
    return { valid: false, reason: `too_small_${stat.size}` };
  }
  const fd = fs.openSync(filePath, 'r');
  const head = Buffer.alloc(3);
  try {
    fs.readSync(fd, head, 0, 3, 0);
  } finally {
    fs.closeSync(fd);
  }
  const isId3 = head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33;
  const isMpegSync = head[0] === 0xff && (head[1] & 0xe0) === 0xe0;
  if (!isId3 && !isMpegSync) {
    return { valid: false, reason: 'invalid_mp3_header' };
  }

  if (hasFfprobe()) {
    const probe = spawnSync(
      'ffprobe',
      [
        '-v',
        'error',
        '-show_entries',
        'format=duration',
        '-of',
        'default=nw=1:nk=1',
        filePath,
      ],
      { encoding: 'utf8' }
    );
    if (probe.status !== 0) {
      return { valid: false, reason: 'ffprobe_error' };
    }
    const dur = parseFloat((probe.stdout || '').trim());
    if (!Number.isFinite(dur) || dur <= 0.2) {
      return { valid: false, reason: 'invalid_duration' };
    }
  }

  return { valid: true };
}

export function inspectAudioLibrary(cleanInvalid = true): LibraryInspectionResult {
  fs.mkdirSync(AUDIO_DIR, { recursive: true });
  const allTracks = buildAllAudioTracks();
  const validIds: string[] = [];
  const missingTracks: AudioTrackEntry[] = [];
  const invalidRemoved: string[] = [];

  // Clean up any leftover temp files from an interrupted run
  for (const entry of fs.readdirSync(AUDIO_DIR)) {
    if (entry.endsWith('.tmp.mp3')) {
      try {
        fs.unlinkSync(path.join(AUDIO_DIR, entry));
      } catch {
        // Ignore cleanup failure
      }
    }
  }

  let firstMissingIndex: number | null = null;
  allTracks.forEach((track, idx) => {
    const filePath = path.join(AUDIO_DIR, `${track.id}.mp3`);
    if (!fs.existsSync(filePath)) {
      missingTracks.push(track);
      if (firstMissingIndex === null) firstMissingIndex = idx + 1;
      return;
    }
    const check = verifyMp3File(filePath);
    if (check.valid) {
      validIds.push(track.id);
    } else {
      if (cleanInvalid) {
        try {
          fs.unlinkSync(filePath);
          invalidRemoved.push(`${track.id} (${check.reason})`);
        } catch {
          // Ignore delete failure
        }
      }
      missingTracks.push(track);
      if (firstMissingIndex === null) firstMissingIndex = idx + 1;
    }
  });

  return {
    allTracks,
    validIds,
    missingTracks,
    invalidRemoved,
    nextTrackIndex: firstMissingIndex,
  };
}

function saveProgress(state: AudioProgressState): void {
  fs.mkdirSync(path.dirname(PROGRESS_FILE), { recursive: true });
  fs.writeFileSync(PROGRESS_FILE, JSON.stringify(state, null, 2), 'utf8');
}

function parseQuotaDetails(message: string): {
  isQuota: boolean;
  isDailyLimit: boolean;
  retryDelay: string | null;
} {
  const isQuota =
    message.includes('429') || message.includes('RESOURCE_EXHAUSTED');
  const isDailyLimit =
    message.includes('GenerateRequestsPerDay') ||
    message.includes('requests per day') ||
    message.includes('free_tier_requests');
  const match =
    message.match(/Please retry in ([^."\\]+)/i) ||
    message.match(/"retryDelay"\s*:\s*"([^"]+)"/i);
  return {
    isQuota,
    isDailyLimit,
    retryDelay: match ? match[1].trim() : null,
  };
}

async function synthesizeAndSaveTrack(
  ai: GoogleGenAI,
  track: AudioTrackEntry
): Promise<{ ok: true; bytes: number } | { ok: false; message: string }> {
  const speechText = prepareSpokenText(track.text);
  const response = await ai.models.generateContent({
    model: GEMINI_TTS_MODEL,
    contents: [
      {
        role: 'user',
        parts: [
          {
            text: speechText,
            speechMetadata: {
              style: GEMINI_TTS_STYLE_PROMPT,
            },
          },
        ],
      },
    ],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: GEMINI_TTS_VOICE },
        },
      },
    },
  });

  const base64Audio =
    response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    return { ok: false, message: 'Empty audio payload returned by Gemini TTS' };
  }

  const wavBuffer = Buffer.from(base64Audio, 'base64');
  const finalPath = path.join(AUDIO_DIR, `${track.id}.mp3`);
  const tmpPath = path.join(AUDIO_DIR, `${track.id}.tmp.mp3`);

  const ff = spawnSync(
    'ffmpeg',
    [
      '-y',
      '-loglevel',
      'error',
      '-f',
      'wav',
      '-i',
      'pipe:0',
      '-codec:a',
      'libmp3lame',
      '-q:a',
      '3',
      tmpPath,
    ],
    { input: wavBuffer }
  );

  if (ff.status !== 0) {
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {
      // Ignore cleanup
    }
    return {
      ok: false,
      message: `ffmpeg conversion failed: ${ff.stderr?.toString() || 'unknown error'}`,
    };
  }

  const verified = verifyMp3File(tmpPath);
  if (!verified.valid) {
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {
      // Ignore cleanup
    }
    return {
      ok: false,
      message: `Generated MP3 failed integrity check (${verified.reason})`,
    };
  }

  fs.renameSync(tmpPath, finalPath);
  return { ok: true, bytes: fs.statSync(finalPath).size };
}

export function getSavedProgressOrScan(): AudioProgressState {
  const scan = inspectAudioLibrary(true);
  let previous: Partial<AudioProgressState> = {};
  if (fs.existsSync(PROGRESS_FILE)) {
    try {
      previous = JSON.parse(fs.readFileSync(PROGRESS_FILE, 'utf8'));
    } catch {
      previous = {};
    }
  }

  const state: AudioProgressState = {
    model: GEMINI_TTS_MODEL,
    voiceName: GEMINI_TTS_VOICE,
    totalTracks: scan.allTracks.length,
    validCount: scan.validIds.length,
    missingCount: scan.missingTracks.length,
    invalidRemoved: scan.invalidRemoved,
    nextTrackId: scan.missingTracks[0]?.id ?? null,
    nextTrackIndex: scan.nextTrackIndex,
    lastCompletedTrackId: previous.lastCompletedTrackId ?? scan.validIds.at(-1) ?? null,
    generatedInLastRun: previous.generatedInLastRun ?? [],
    stoppedReason: scan.missingTracks.length === 0 ? 'completed' : 'ready',
    retryDelay: null,
    errorMessage: null,
    lastUpdatedAt: new Date().toISOString(),
  };
  saveProgress(state);
  return state;
}

export async function runAudioBatch(options?: {
  apiKey?: string;
  limit?: number;
  delayMs?: number;
  onLog?: (line: string) => void;
}): Promise<AudioProgressState> {
  const log = options?.onLog ?? ((line: string) => console.log(line));
  const limit = options?.limit && options.limit > 0 ? options.limit : Infinity;
  const delayMs = options?.delayMs ?? 1200;

  const scan = inspectAudioLibrary(true);
  if (scan.invalidRemoved.length > 0) {
    log(`Removed ${scan.invalidRemoved.length} invalid audio file(s) so they can be regenerated cleanly.`);
  }

  const state: AudioProgressState = {
    model: GEMINI_TTS_MODEL,
    voiceName: GEMINI_TTS_VOICE,
    totalTracks: scan.allTracks.length,
    validCount: scan.validIds.length,
    missingCount: scan.missingTracks.length,
    invalidRemoved: scan.invalidRemoved,
    nextTrackId: scan.missingTracks[0]?.id ?? null,
    nextTrackIndex: scan.nextTrackIndex,
    lastCompletedTrackId: scan.validIds.at(-1) ?? null,
    generatedInLastRun: [],
    stoppedReason: scan.missingTracks.length === 0 ? 'completed' : 'ready',
    retryDelay: null,
    errorMessage: null,
    lastUpdatedAt: new Date().toISOString(),
  };

  if (scan.missingTracks.length === 0) {
    log(`All ${scan.allTracks.length} Zephyr MP3 files already exist and are valid.`);
    saveProgress(state);
    return state;
  }

  const apiKey = options?.apiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    state.stoppedReason = 'missing_api_key';
    state.errorMessage = 'GEMINI_API_KEY is not configured.';
    saveProgress(state);
    return state;
  }

  const ai = new GoogleGenAI({
    apiKey,
    apiVersion: 'v1beta',
    httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
  });

  log(
    `Found ${scan.validIds.length}/${scan.allTracks.length} valid files. Missing: ${scan.missingTracks.length}. Resuming from: ${scan.missingTracks[0].id} (#${scan.nextTrackIndex})`
  );

  for (let i = 0; i < scan.missingTracks.length; i++) {
    if (state.generatedInLastRun.length >= limit) {
      state.stoppedReason = 'batch_limit_reached';
      break;
    }

    const track = scan.missingTracks[i];
    const trackPosition =
      scan.allTracks.findIndex((t) => t.id === track.id) + 1;

    let attemptsForRpm = 0;
    while (true) {
      try {
        const res = await synthesizeAndSaveTrack(ai, track);
        if (!res.ok) {
          state.stoppedReason = 'error';
          state.errorMessage = res.message;
          saveProgress(state);
          return state;
        }

        state.generatedInLastRun.push(track.id);
        state.lastCompletedTrackId = track.id;
        state.validCount += 1;
        state.missingCount -= 1;

        const nextTrack = scan.missingTracks[i + 1] ?? null;
        state.nextTrackId = nextTrack ? nextTrack.id : null;
        state.nextTrackIndex = nextTrack
          ? scan.allTracks.findIndex((t) => t.id === nextTrack.id) + 1
          : null;
        state.stoppedReason =
          state.missingCount === 0 ? 'completed' : 'ready';
        state.lastUpdatedAt = new Date().toISOString();
        saveProgress(state);

        log(
          `[${state.validCount}/${state.totalTracks}] Saved ${track.id}.mp3 (${res.bytes} bytes, track #${trackPosition})`
        );
        break;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        const quota = parseQuotaDetails(msg);

        if (quota.isQuota && quota.isDailyLimit) {
          state.stoppedReason = 'quota_exhausted';
          state.retryDelay = quota.retryDelay;
          state.errorMessage =
            'Daily Free Tier quota exhausted (429 RESOURCE_EXHAUSTED). Saved progress safely.';
          state.lastUpdatedAt = new Date().toISOString();
          saveProgress(state);
          log(
            `Quota reached (429 RESOURCE_EXHAUSTED). Safely saved ${state.validCount}/${state.totalTracks}. Next track to resume: ${state.nextTrackId}. Retry delay: ${quota.retryDelay || 'daily reset'}`
          );
          return state;
        }

        if (quota.isQuota && attemptsForRpm < 2) {
          attemptsForRpm += 1;
          log(`Per-minute rate limit on ${track.id}, pausing 15s before retry...`);
          await new Promise((r) => setTimeout(r, 15000));
          continue;
        }

        state.stoppedReason = quota.isQuota ? 'quota_exhausted' : 'error';
        state.retryDelay = quota.retryDelay;
        state.errorMessage = msg.slice(0, 500);
        state.lastUpdatedAt = new Date().toISOString();
        saveProgress(state);
        return state;
      }
    }

    if (delayMs > 0 && i + 1 < scan.missingTracks.length) {
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }

  state.lastUpdatedAt = new Date().toISOString();
  saveProgress(state);
  return state;
}
