import 'dotenv/config';
import {
  getSavedProgressOrScan,
  runAudioBatch,
  AudioProgressState,
} from './audioBatchRunner.ts';

function parseArgs(): { statusOnly: boolean; limit?: number } {
  const args = process.argv.slice(2);
  let statusOnly = false;
  let limit: number | undefined;

  for (const arg of args) {
    if (arg === '--status' || arg === '-s') {
      statusOnly = true;
    } else if (arg.startsWith('--limit=')) {
      const parsed = parseInt(arg.split('=')[1] || '', 10);
      if (Number.isFinite(parsed) && parsed > 0) limit = parsed;
    }
  }
  return { statusOnly, limit };
}

function printSummary(state: AudioProgressState): void {
  console.log('\n=== Gemini Zephyr Audio Batch Status ===');
  console.log(`Model / Voice  : ${state.model} / ${state.voiceName}`);
  console.log(`Saved & Valid  : ${state.validCount} / ${state.totalTracks}`);
  console.log(`Remaining      : ${state.missingCount}`);
  console.log(`Next Track     : ${state.nextTrackId ?? 'ALL DONE'} (#${state.nextTrackIndex ?? '-'})`);
  console.log(`Stopped Reason : ${state.stoppedReason}`);
  if (state.generatedInLastRun.length > 0) {
    console.log(
      `Generated Now  : ${state.generatedInLastRun.length} (${state.generatedInLastRun.join(', ')})`
    );
  }
  if (state.retryDelay) {
    console.log(`Retry After    : ${state.retryDelay}`);
  }
  if (state.errorMessage && state.stoppedReason === 'error') {
    console.log(`Error          : ${state.errorMessage}`);
  }
  console.log('Resume Command : npm run audio:generate\n');
}

async function main() {
  const { statusOnly, limit } = parseArgs();

  if (statusOnly) {
    const state = getSavedProgressOrScan();
    printSummary(state);
    return;
  }

  // If GEMINI_API_KEY is available directly in environment/.env, run directly.
  if (process.env.GEMINI_API_KEY) {
    const state = await runAudioBatch({ limit });
    printSummary(state);
    if (state.stoppedReason === 'error') {
      process.exit(1);
    }
    return;
  }

  // Otherwise delegate to running local dev server (which receives AI Studio Secrets in process.env)
  const port = Number(process.env.PORT) || 3000;
  try {
    const res = await fetch(`http://127.0.0.1:${port}/api/_dev/audio-batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ limit }),
    });
    if (!res.ok) {
      throw new Error(`Dev endpoint returned HTTP ${res.status}: ${await res.text()}`);
    }
    const state = (await res.json()) as AudioProgressState;
    printSummary(state);
    if (state.stoppedReason === 'error' || state.stoppedReason === 'missing_api_key') {
      process.exit(1);
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(
      `Could not run directly (no GEMINI_API_KEY in shell) and dev server batch route was unreachable: ${msg}`
    );
    process.exit(1);
  }
}

main();
