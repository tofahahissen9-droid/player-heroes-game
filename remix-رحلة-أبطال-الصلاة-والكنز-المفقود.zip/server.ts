import "dotenv/config";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === "production";

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  const publicAudioDir = path.resolve(__dirname, "public", "audio");
  fs.mkdirSync(publicAudioDir, { recursive: true });

  // Serve pre-generated static audio files directly; return 404 (never index.html) if missing
  app.use(
    "/audio",
    express.static(publicAudioDir, {
      maxAge: isProduction ? "30d" : "0",
      immutable: isProduction,
      fallthrough: false,
    })
  );
  app.use(
    "/audio",
    (
      _err: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      res.status(404).end();
    }
  );

  if (!isProduction) {
    let batchRunning = false;

    app.get("/api/_dev/audio-status", async (_req, res) => {
      try {
        const { getSavedProgressOrScan } = await import(
          "./scripts/audioBatchRunner.ts"
        );
        res.json(getSavedProgressOrScan());
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        res.status(500).json({ error: msg });
      }
    });

    app.post("/api/_dev/audio-batch", async (req, res) => {
      if (batchRunning) {
        res.status(409).json({ error: "Batch generation already in progress" });
        return;
      }
      batchRunning = true;
      try {
        const limitRaw = Number(req.body?.limit);
        const limit =
          Number.isFinite(limitRaw) && limitRaw > 0 ? limitRaw : undefined;
        const { runAudioBatch } = await import("./scripts/audioBatchRunner.ts");
        const result = await runAudioBatch({ limit });
        res.json(result);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        res.status(500).json({ error: msg });
      } finally {
        batchRunning = false;
      }
    });

    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
